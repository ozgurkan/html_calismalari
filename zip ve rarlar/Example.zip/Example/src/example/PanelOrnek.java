/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
public class PanelOrnek extends JFrame {
    public PanelOrnek()
    {
    JPanel yerlesim=new JPanel();
    yerlesim.setLayout(new GridLayout(2,2));
    
    yerlesim.add(new JButton("Gönder"));
    yerlesim.add(new JButton("Hesapla"));
    yerlesim.add(new JButton("Tamam"));
    yerlesim.add(new JButton("OK"));
    
    
    JPanel yerlesim2=new JPanel();
    yerlesim2.setLayout(new BorderLayout());
    yerlesim2.add(yerlesim, BorderLayout.CENTER);
    yerlesim2.add(new JButton("Sol Buton"),BorderLayout.WEST);
    
    add(yerlesim2);
    }
}
