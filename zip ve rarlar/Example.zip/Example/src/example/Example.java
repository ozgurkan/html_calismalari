/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

import javax.swing.JFrame;

/**
 *
 * @author Administrator
 */
public class Example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PanelOrnek pencere= new PanelOrnek();
        pencere.setSize(400,250);
        pencere.setLocationRelativeTo(null);
        pencere.setDefaultCloseOperation((JFrame.EXIT_ON_CLOSE));
        pencere.setVisible(true);
    }
}
