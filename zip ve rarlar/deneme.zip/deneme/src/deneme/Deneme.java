/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package deneme;

import javax.swing.*;
public class Deneme {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LayoutPenceresi pencere=new LayoutPenceresi();
        
        pencere.setSize(500,500);
        pencere.setLocationRelativeTo(null);
        pencere.setDefaultCloseOperation((JFrame.EXIT_ON_CLOSE));
        pencere.setVisible(true);
    }
}
