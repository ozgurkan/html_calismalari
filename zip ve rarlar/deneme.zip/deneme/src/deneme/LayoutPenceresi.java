/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package deneme;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;
public class LayoutPenceresi extends JFrame {
    public LayoutPenceresi()
            {
                
                BorderLayout yerlesim=new BorderLayout(10,15);
                setLayout(yerlesim);
                
                
                JButton b1=new JButton("Renkler");
                
                b1.setBackground(Color.magenta);
                add(b1,BorderLayout.CENTER);
               
                 
                 
                /*GridLayout yerlesim=new GridLayout(3,2,5,5);
                setLayout(yerlesim);
                add(new JLabel("Ad"));
                add(new JTextField(20));
                
                add(new JLabel("Soyad"));
                add(new JTextField(20));
                
                add(new JLabel("Yaş"));
                add(new JTextField(4));
                */ 
            }
   
}
