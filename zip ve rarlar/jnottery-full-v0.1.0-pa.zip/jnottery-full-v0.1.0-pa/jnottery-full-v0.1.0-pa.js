// jNottery Full Release 
// Parts of this code are written, and maintained by diffrent authors, see copyright notes below. 
// Copyright (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org> 
// @see http://jnottery.com/ 
// The library itself and all of its dependencies are released under the MIT license. 
// Requires jQuery, other dependencies included. 
        
(function() { 
// 0xJQ Project 
// Copyright (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

// @see http://www.w3.org/TR/html5/index.html#attributes-1
// huffman codes generated from frequencies of html attributes
// in top 2000 websites of Majestic Million

var Dict = Dict || {};

Dict.attrs = {
    'for': '001111011',
    'formtarget': '00000001000101100110',
    'accept-charset': '001110100101',
    'seamless': '0011101001110100',
    'autofocus': '00000010011010',
    'srclang': '00000001000101100111',
    'border': '0011100',
    'href': '01',
    'form': '001110100100100',
    'charset': '0011110011',
    'cite': '0011101001000010110',
    'content': '000001',
    'start': '000000010001011110',
    'novalidate': '00000010011011',
    'poster': '000000010001010',
    'contenteditable': '00000001000101101',
    'spellcheck': '00000001000100',
    'data': '001111100001',
    'crossorigin': '00000010011000',
    'accesskey': '00111110001',
    'manifest': '0011101001000010111',
    'http-equiv': '001111101',
    'kind': '00111010011101010000',
    'title': '0010',
    'defer': '00111010011110',
    'src': '0001',
    'enctype': '00111010011111',
    'loop': '00000001000110',
    'max': '00000010011001101',
    'formnovalidate': '0011101001110101001',
    'datetime': '0000001011',
    'min': '00000010011001100',
    'muted': '000000010001011111',
    'placeholder': '0011110010',
    'method': '001111010',
    'rel': '101110',
    'pattern': '001110100100101',
    'translate': '001110100111011',
    'headers': '001110100100110',
    'draggable': '001110100111010101',
    'readonly': '001110100100000',
    'checked': '00000001001',
    'type': '10110',
    'cols': '001110100100111',
    'sizes': '0000000101',
    'value': '10001',
    'maxlength': '0011101000',
    'height': '101111',
    'hreflang': '00000000',
    'scoped': '000000100110010',
    'required': '00000010010',
    'action': '001111111',
    'abbr': '0011101001000011',
    'class': '11',
    'label': '00000010101',
    'minlength': '00111010011101010001',
    'colspan': '0011101010',
    'width': '00001',
    'size': '0011111001',
    'default': '001110100100001000',
    'media': '001111110',
    'rowspan': '001110100110',
    'shape': '001111000',
    'autoplay': '0000001001100111',
    'rows': '00000001000111',
    'controls': '00000001000101110',
    'id': '1010',
    'selected': '00000010100',
    'scope': '00111010011100',
    'lang': '00111011',
    'usemap': '000000100111',
    'formaction': '000000010001011000',
    'multiple': '00111010011101011',
    'formmethod': '001110100100001001',
    'tabindex': '00000011',
    'dir': '000000011',
    'style': '10000',
    'name': '00110',
    'alt': '10010',
    'target': '10011',
    'hidden': '0000000100010110010',
    'preload': '00111010010001',
    'async': '001111100000',
    'coords': '0011101011',
    'list': '001110100100001010',
    'autocomplete': '0000001000',
    'disabled': '000000010000'
};;// 0xJQ Project 
// Copyright (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

// @see http://www.w3.org/TR/html5/index.html#elements-1
// huffman codes generated from frequencies of html tags
// in top 2000 websites of Majestic Million

var Dict = Dict || {};

Dict.elements = {
    'summary': '01001011111000001111',
    'colgroup': '010010111111111',
    'noscript': '111010010',
    'time': '0110001010',
    'button': '011011111',
    'ol': '11101011100',
    'h1': '01000100',
    'h2': '01000101',
    'h3': '01000110',
    'h4': '01000111',
    'h5': '01001000',
    'h6': '01001001',
    'video': '01001011111001',
    'template': '0100101111100000100',
    'option': '111011',
    'table': '111010000',
    'form': '011111011',
    'cite': '010010110111',
    'header': '011000111',
    'wbr': '0100101101101',
    'textarea': '010010110101',
    'dt': '011000100',
    'small': '0110111001',
    'optgroup': '01101110101110',
    'link': '0111111',
    'param': '0110111100',
    'aside': '011111010101',
    'dd': '111010011',
    'title': '1110101111',
    'meta': '010011',
    'bdi': '011111010010',
    'dl': '1110101001',
    'del': '11101011101000110',
    'figure': '0110111011',
    'map': '0111110101001',
    'b': '01111100',
    'fieldset': '01111101000',
    'ul': '01011',
    'caption': '0100101111111001',
    'i': '0110110',
    'a': '10',
    'blockquote': '011011101001',
    's': '010010110100',
    'article': '01100001',
    'u': '1110101110101',
    'footer': '0100101100',
    'base': '11101011101001',
    'p': '01110',
    'q': '010010111110001',
    'legend': '0111110101000',
    'body': '1110101000',
    'dfn': '01001011111000001010',
    'em': '01100000',
    'td': '011110',
    'img': '11100',
    'tr': '0110100',
    'col': '0110111010101',
    'select': '01111101011',
    'ins': '0100101111110',
    'abbr': '011111010011',
    'canvas': '111010111010000',
    'br': '011001',
    'th': '01001011110',
    'samp': '0100101111111000',
    'head': '1110101100',
    'script': '01010',
    'tfoot': '0100101111111011',
    'embed': '010010111111110',
    'li': '110',
    'label': '01001010',
    'mark': '01001011111000001011',
    'code': '01101110101111',
    'span': '1111',
    'output': '0100101111100000110',
    'hr': '0110111101',
    'iframe': '0110111000',
    'input': '010000',
    'strong': '0110101',
    'object': '0100101111101',
    'figcaption': '111010111011',
    'sup': '011011101000',
    'sub': '01001011111000000',
    'div': '00',
    'var': '11101011101000111',
    'track': '01001011111000001110',
    'section': '111010101',
    'thead': '0100101101100',
    'audio': '0100101111111010',
    'style': '011000110',
    'area': '0110001011',
    'html': '1110101101',
    'pre': '0100101111100001',
    'nav': '0100101110',
    'tbody': '111010001',
    'address': '0110111010110',
    'main': '1110101110100010',
    'source': '0110111010100'
};
;// 0xJQ Project 
// Copyright (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

var Dict = Dict || {},
    KEYWORD_DESCENDANT = 0,
    KEYWORD_CHILD = 1,
    KEYWORD_NUM = 2,
    KEYWORD_CLASS = 3,
    KEYWORD_ID = 4,
    KEYWORD_TAG = 5,
    KEYWORD_EQUALS = 6,
    KEYWORD_HAS = 7,
    KEYWORD_STOP = 8;

Dict.keywords = [
    /* KEYWORD_DESCENDANT */ '00',
    /* KEYWORD_CHILD */ '111',
    /* KEYWORD_NUM */ '110',
    /* KEYWORD_CLASS */ '100',
    /* KEYWORD_ID */ '011',
    /* KEYWORD_TAG */ '010',
    /* KEYWORD_EQUALS */ '1010',
    /* KEYWORD_HAS */ '10111',
    /* KEYWORD_STOP */ '10110'
];;// 0xJQ Project 
// Copyright (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function($) {
    
    var SelectorCollection,
        Selector,
        ElementContent,
        SearchTree,
        encoder_defaults = {
            compressRatio: 0.5,
            root: 'body',
           
            // internal modifiers, sum should be equal to 4.0
            cuttingRatioModifier: 2.5,
            nearbyRatioModifier: 0.5,
            partUniqueModifier: 0.5,
            fullUniqueModifier: 0.5,

            contentShinglesNum: 8,

            classBlacklist: []
        },
        decoder_defaults = {
            root: 'body',
            
            // when decoder is unable to get encoded element directly by
            // selector it goes up the DOM tree `generalLevels` times (from element 
            // referenced by selector), than calculates the similarity of all 
            // encountered elements and chooses best one globally, the next step 
            // is to traverse deeper into the choosen element, up to `approxLevels`
            // times, only if similarity of succeeding children is increasing
            generalLevels: 1, // generalizing phase, goes up 
            approxLevels: 3, // approximating phase, goes down

            // when encoded selector doesn't match any element, it could be trimmed
            // from right `trimSelectorParts` times to get some more general selectors
            // probably containing the wanted one
            trimSelectorParts: 1,

            // when calculated similarity is lower than threshold two elements 
            // are treated as identical
            similarityThreshold: 1.0
        };

    function getBytesFromBits(bitstring) {
        if(bitstring === '')
            return [];

        var bytes = bitstring.match(/.{1,8}/g),
            last_shift = 8 - bytes[bytes.length - 1].length,
            result = [];

        result = bytes.map(function(byte) {
            return parseInt(byte, 2);
        });

        // pad to full byte
        result[result.length - 1] = result[result.length - 1] << last_shift;

        return result;
    }

    function alignTo(bits, size) {
        var zeros = size - bits.length,
            result = '';
        
        if(zeros > 0) {
            for(var i = 0; i < zeros; i++) 
                result += '0';     
        }

        return result + bits;
    }

    function escapeSelectorValue(val) {
        return val.replace(/([!"#$%&'()*+,./:;<=>?@[\]^`{|}~])/g, '\\\\$1'); 
    }

    function escapeQuotes(val) {
        return val.replace(/(["])/g, '\\$1');
    }
    
    SelectorCollection = (function() {
        var node = {
            NULL: 1,
            PARENT: 2,
            ANCESTOR: 3
        };

        function getGlue(node_type) {
            switch(node_type) {
                case node.PARENT: {
                    return ' > ';                            
                }
                case node.ANCESTOR: {
                    return ' ';
                }
                default:
                    return '';
            }
        }

        function getBitsetGlue(node_type) {
            switch(node_type) {
                case node.PARENT: {
                    return Dict.keywords[KEYWORD_CHILD];
                }
                case node.ANCESTOR: {
                    return Dict.keywords[KEYWORD_DESCENDANT];        
                }
                default:
                    return '';
            }
        }

        function SelectorCollection() {
            this.selectors = []; 
        } 

        SelectorCollection.node = node;   

        SelectorCollection.prototype = {
            addSelector: function(node, selector) {
                this.selectors.push({ type: node, obj: selector });            
            },
            getBestSelector: function($elem, current_collection, cutting_ratio, nearby_ratio) {
                // normalize size
                var max_size = 0;
                for(var s in this.selectors)
                    this.selectors[s].obj.getSize() > max_size && (max_size = this.selectors[s].obj.getSize());    
                
                var min_rating,
                    min_selector,
                    min_unique_rating,
                    min_unique_selector,
                    selector_until = current_collection.getReversedCssSelector(),
                    rating;
            
                for(var s in this.selectors) {
                    rating = this.selectors[s].obj.calcRating(
                        this.selectors[s].obj.getSize() / max_size,
                        getGlue(this.selectors[s].type) + selector_until,
                        cutting_ratio,
                        nearby_ratio
                    );
            
                    if(typeof min_rating === 'undefined' || rating < min_rating) {
                        min_rating = rating;
                        min_selector = this.selectors[s].obj;
                    }

                    if($elem.parent().children(this.selectors[s].obj.getCssSelector()).length === 1 
                            && (
                                typeof min_unique_rating === 'undefined'
                                || rating < min_unique_rating
                            ) 
                    ) {
                        min_unique_rating = rating;
                        min_unique_selector = this.selectors[s].obj;
                    }
                }
                
                if(typeof min_unique_selector !== 'undefined')
                    return min_unique_selector;
                
                // :nth-of-type() starts at 1
                min_selector.setPosition($elem.parent().children(min_selector.getCssSelector()).index($elem) + 1);

                return min_selector;
            },
            last: function() {
                if(this.selectors.length > 0)
                    return this.selectors[this.selectors.length - 1].obj;        

                return null;
            },
            getReversedCssSelector: function() {
                var result = '',
                    s;
                
                for(s = this.selectors.length - 1; s >= 0; s--) {
                    result += this.selectors[s].obj.getCssSelector() + getGlue(this.selectors[s].type);
                } 
                
                return result;
            },
            getCssSelector: function() {
                var result = '',
                    s;
                
                for(s = 0; s < this.selectors.length; s++) {
                    result += getGlue(this.selectors[s].type) + this.selectors[s].obj.getCssSelector();
                } 
                
                return result;
            }, 
            getBinarySelector: function() {
                var selector = '',
                    vals = [],
                    current,
                    s;
                
                for(s = this.selectors.length - 1; s >= 0; s--) {
                    current = this.selectors[s];
                    selector += current.obj.getBitsetSelector() + getBitsetGlue(current.type);
                    vals = vals.concat(current.obj.getBinaryValue()); 
                }
                
                selector += Dict.keywords[KEYWORD_STOP];
                
                return getBytesFromBits(selector).concat(vals);
            },
            clear: function() {
                this.selectors = [];
            },
            each: function(callback) {
                for(s = 0; s < this.selectors.length; s++) {
                    var result = callback(this.selectors[s].obj, this.selectors[s].type);
                    
                    if(typeof result !== 'undefined' && typeof result.type !== 'undefined')
                        this.selectors[s].type = result.type;
                } 
            },
            splice: function(i, size) {
                return this.selectors.splice(i, size);
            },
            size: function() {
                return this.selectors.length;        
            }
        };

        return SelectorCollection;
    })();


    Selector = (function() {

        var types = {
            ID: 1.0,
            CLASS: 0.8,
            ATTR_EQUALS: 0.6, 
            ATTR_HAS: 0.4,
            ELEMENT: 0.2
        };

        var root_instance, 
            root_length,
            settings; 

        function valueSize(value) {
            if(typeof value === 'undefined')
                return 0;
            
            return (value.length + 1) * 8;
        }

        function getSelector(type, attr, value) {
            var selector = '';
            
            switch(type) {
                case types.ID:
                    selector = Dict.keywords[KEYWORD_ID];
                    return { 
                        text: '#' + escapeSelectorValue(value), 
                        binary: selector, 
                        size: selector.length + valueSize(value)
                    };
                    
                case types.CLASS:
                    selector = Dict.keywords[KEYWORD_CLASS];
                    return { 
                        text: '.' + escapeSelectorValue(value), 
                        binary: selector,
                        size: selector.length + valueSize(value)
                    };

                 case types.ATTR_EQUALS:
                     selector = Dict.keywords[KEYWORD_EQUALS] + Dict.attrs[attr];
                     return { 
                        text: '[' + escapeSelectorValue(attr) + '^="' + escapeQuotes(value) + '"]',
                        binary: selector,
                        size: selector.length + valueSize(value)
                     };

                 case types.ATTR_HAS:
                     selector = Dict.keywords[KEYWORD_HAS] + Dict.attrs[value];
                     return { 
                        text: '[' + escapeSelectorValue(value) + ']', 
                        binary: selector,
                        size: selector.length
                     };

                 case types.ELEMENT:
                     selector = Dict.keywords[KEYWORD_TAG] + Dict.elements[value];
                     return { 
                        text: value,
                        binary: selector,
                        size: selector.length
                     };
             }
        }

        function getUnique(selector) {
            return 1.0 - $(root_instance).find(selector).length / root_length;
        }
        
        function Selector(type, attr, value) {
            this.type = type;
            this.attr = attr;
            this.value = value;

            if(typeof this.value !== 'undefined')
                this.selector = getSelector(type, attr, value);
            
            this.position = undefined;
            this.rating = undefined;
        }

        Selector.setSettingsProvider = function(provider) {
            settings = provider; 
            root_instance = $(provider.root);
            root_length = root_instance.find('*').length;
        };

        Selector.types = types;
        
        Selector.prototype = {
            types: types,
            getType: function() {
                return this.type;
            },
            getRating: function() {
                return this.rating;  
            },
            calcRating: function(normalized_size, until_selector, cutting_ratio, nearby_ratio) {
                var part_unique, 
                    full_unique,
                    quality = 0.0;
                    
                part_unique = full_unique = 1.0;
                
                if(this.type !== types.ID) {
                    part_unique = getUnique(this.selector.text);
                    full_unique = getUnique(this.selector.text + ' ' + until_selector);
                } 
                
                cutting_ratio *= settings.cuttingRatioModifier;
                nearby_ratio *= settings.nearbyRatioModifier;
                part_unique *= settings.partUniqueModifier;
                full_unique *= settings.fullUniqueModifier;
                
                quality = this.type * (cutting_ratio + nearby_ratio + part_unique + full_unique) / 4.0; // more = better
                
                return (this.rating = settings.compressRatio * normalized_size + (1.0 - settings.compressRatio) * (1.0 - quality));
            },
            getSize: function() {
                return this.selector.size;
            },
            getCssSelector: function() {
                var suffix = '';
                
                if(typeof this.position !== 'undefined')
                    suffix = ':nth-of-type(' + (this.position % 256) + ')';
                
                return this.selector.text + suffix;        
            },
            getBitsetSelector: function() {
                var suffix = '';

                if(typeof this.position !== 'undefined')
                    suffix = Dict.keywords[KEYWORD_NUM] + alignTo((this.position % 256).toString(2), 8);
                
                return this.selector.binary + suffix;
            },
            getBinaryValue: function() {
                switch(this.type) {
                    case types.ID:
                    case types.CLASS:
                    case types.ATTR_EQUALS: {
                        
                        var chars = this.value.split(''),
                            result = chars.map(function(ch) {
                                return ch.charCodeAt(0);        
                            });
                            
                        result.unshift(chars.length % 256);
                        return result;
                    }
                    default: 
                        return [];
                }
            },
            setPosition: function(position) {
                if(position >= 0 || (typeof position === 'undefined'))
                    this.position = position;
            },
            setValue: function(value) {
                this.value = value; 
                this.selector = getSelector(this.type, this.attr, value);
            },
            requiresParent: function() {
                return typeof position !== 'undefined';
            },
            toString: function() {
                return this.attr + ', ' + this.value;
            }
        };

        return Selector;
    })();

    ElementContent = (function() {

        var settings,
            MAX_SHINGLE_FREQ_POW = 6,
            MAX_DESCENDANT_FREQ_POW = 6,
            MAX_SHINGLE_FREQ = Math.pow(2, MAX_SHINGLE_FREQ_POW),
            MAX_DESCENDANT_FREQ = Math.pow(2, MAX_DESCENDANT_FREQ_POW),
            types = {
                TEXT: 0,
                TAGS: 1
            };

        function get5BitCode(char) {
            char = char.charCodeAt(0);
            
            if(97 /* a */ <= char && char <= /* v */ 118)
                return char - 87;

            if(48 /* 0 */ <= char && char <= /* 9 */ 57)
                return char - 48;

            return 0;
        }

        function get5BitChar(code) {
            if(0 <= code && code <= 9) 
                code += 48;

            if(10 <= code && code <= 31)
                code += 87;
            
            return String.fromCharCode(code);
        }

        function getTopFreqs(freq, limit, max_value) {
            var freq_keys,
                result = []; 

            freq_keys = Object.keys(freq).sort(function(a, b) {
                return freq[b] - freq[a];
            });
            
            for(var i = 0, j = 0; j < limit && i < freq_keys.length; i++) {
                if(freq[freq_keys[i]] <= max_value) {
                    result.push({ value: freq_keys[i], freq: freq[freq_keys[i]] });
                    j++;
                }
            }
            
            return result;
        }

        function getAllShingleFreqs($element) {
            var txt = $element.text().toLowerCase().replace(/([^a-v0-9])+/g, ''),
                stats = [],
                shingle;
            
            for(var i = 0; i < txt.length - 1; i++) {
                shingle = txt[i] + '' + txt[i + 1];
                
                if(typeof stats[shingle] === 'undefined')
                    stats[shingle] = 0;

                stats[shingle]++;
            }
            
            return stats;
        }

        function getAllDescendantFreqs($element) {
            var stats = [],
                tagName = '';
            
            $element.find('*').each(function() {
                tagName = $(this).prop('tagName').toLowerCase(); 

                if(typeof Dict.elements[tagName] !== 'undefined') {
                    
                    if(typeof stats[tagName] === 'undefined')
                        stats[tagName] = 0;

                    stats[tagName]++;
                }
            });
            
            return stats;
        }

        function encodeShingles(shingles) {
            var result = [];
            
            for(var i = 0; i < shingles.length; i++) {
                var first_char = get5BitCode(shingles[i].value.charAt(0)),
                    second_char = get5BitCode(shingles[i].value.charAt(1)),
                    freq = (shingles[i].freq - 1) % MAX_SHINGLE_FREQ;
                
                result.push((first_char << 3) | (second_char >>> 2));
                result.push(((second_char << 6) & 0xFF) | freq);
            }         
            
            return result;
        }

        function decodeShingles(bytearr) {
            var shingles = {};
            
            for(var i = 0; i < bytearr.length; i += 2) {
                var first_char = get5BitChar(bytearr[i] >>> 3),
                    second_char = get5BitChar((bytearr[i] & 0x07) << 2 | (bytearr[i + 1] & 0xC0) >>> 6),
                    freq = bytearr[i + 1] & 0x3F;
               
                shingles[first_char + '' + second_char] = freq + 1;
            }    

            return shingles;
        }

        function encodeDescendants(desc) {
            var result = '',
                freq;
            
            for(var i = 0; i < desc.length; i++) {
                freq = ((desc[i].freq - 1) % MAX_DESCENDANT_FREQ).toString(2);
                result += Dict.elements[desc[i].value] + alignTo(freq, 6); 
            }
            
            return result ? getBytesFromBits(result) : [];
        }

        function decodeDescendants(bytearr, desc_len, st_elements) {
            var i = 0,
                bit = null,
                element = true,
                element_pos = st_elements,
                last_element = null,
                freq = 0x00,
                freq_cnter = 0,
                result = {},
                stopped = false;
            
            for(; i < bytearr.length && !stopped; i++) {
                for(var b = 0x80; b > 0x00; b = b >>> 1) {
                    bit = +((bytearr[i] & b) === b);

                    if(element) {
                        element_pos = element_pos[bit]; 
                        
                        if({}.toString.call(element_pos) !== '[object Array]') {
                            last_element = element_pos;
                            element_pos = st_elements;
                            element = false;
                        }
                    } else {
                        freq |= bit << (MAX_DESCENDANT_FREQ_POW - (++freq_cnter));

                        if(freq_cnter === MAX_DESCENDANT_FREQ_POW) {
                            result[last_element] = freq + 1; 
                            
                            freq = 0x00;
                            element = true;
                            freq_cnter = 0;
                            
                            if(result.length === desc_len) {
                                stopped = true;
                                break;
                            }
                        }
                    }
                }
            }

            return result;
        }

        function ElementContent($element) {
            this.element = $element;
        }

        ElementContent.types = types;

        ElementContent.setSettingsProvider = function(provider) {
            settings = provider;
        };

        ElementContent.fromEncodedFreqs = function(bytearr, st_elements) {
            var content_len = (bytearr[0] & 0x7F),
                content = bytearr.slice(1, content_len + 1);
                result = new ElementContent;
            
            result.shingles = [];
            result.descs = [];
            
            if((bytearr[0] & 0x80) === 0x80) {
                result.shingles = decodeShingles(content);
                result.type = types.TEXT; 
            } else {
                result.descs = decodeDescendants(content, content_len, st_elements);
                result.type = types.TAGS;
            }       

            return result;
        };

        ElementContent.prototype = {
            getType: function() {
                return this.type;        
            },
            // returns [val] = freq
            getAllShingleFreqs: function() {
                if(typeof this.shingles === 'undefined')
                    this.shingles = getAllShingleFreqs(this.element);
                
                return this.shingles;    
            },
            // returns [val] = freq
            getAllDescendantFreqs: function() {
                if(typeof this.descs === 'undefined')
                    this.descs = getAllDescendantFreqs(this.element);

                return this.descs;
            },
            // returns { value: val, freq: freq }
            getShingleFreqs: function() {
                return getTopFreqs(this.getAllShingleFreqs(), 
                                   settings.contentShinglesNum, 
                                   MAX_SHINGLE_FREQ);
            },
            // returns { value: val, freq: freq }
            getDescendantFreqs: function() {
                return getTopFreqs(this.getAllDescendantFreqs(), 
                                   settings.contentShinglesNum, 
                                   MAX_DESCENDANT_FREQ);
            },
            getAllFreqs: function() {
                if(this.getType() === types.TEXT)
                    return this.getAllShingleFreqs();
                if(this.getType() === types.TAGS)
                    return this.getAllDescendantFreqs();
            }, 
            getOptimalFreqsEncoded: function() {
                var shingles = this.getShingleFreqs(),
                    descendants = this.getDescendantFreqs(),
                    shingles_total = 0,
                    descendants_total = 0,
                    result = [],
                    control_byte = 0x00,
                    i;
                
                for(i = 0; i < shingles.length; i++)
                    shingles_total += shingles[i].freq;    
                
                for(i = 0; i < descendants.length; i++)
                    descendants_total += descendants[i].freq;   

                if(shingles_total > descendants_total) {
                    result = encodeShingles(shingles);
                    control_byte = (result.length % 128) | 0x80;
                    
                    this.type = types.TEXT;
                } else {
                    result = encodeDescendants(descendants);
                    control_byte = (result.length % 128);

                    this.type = types.TAGS;
                }
                
                result.unshift(control_byte);
                return result;
            },
            distance: function(content) {
                var dest_freqs = [],
                    src_freqs = this.getAllFreqs(),
                    result = 0,
                    freq = 0;

                if(this.getType() === types.TEXT)
                    dest_freqs = content.getAllShingleFreqs();
                else if(this.getType() === types.TAGS)
                    dest_freqs = content.getAllDescendantFreqs();
                
                for(var val in src_freqs) {
                    freq = 0;
                    if(typeof dest_freqs[val] !== 'undefined')
                        freq = dest_freqs[val];
                    
                    result += Math.pow(src_freqs[val] - freq, 2);
                }
                    
                return Math.sqrt(result);
            },
            // gets minimal distance from elements specified in collection
            minDistance: function(collection, callback) {
                var min_elem_dist,
                    distance,
                    that = this;
                
                $(collection).each(function() {
                    distance = that.distance(new ElementContent($(this)));
                    
                    if({}.toString.call(callback) === '[object Function]')
                        callback($(this), distance);
                    
                    if(typeof min_elem_dist === 'undefined' || (distance < min_elem_dist.dist))
                        min_elem_dist = { dist: distance, elem: $(this) };  
                });

                return min_elem_dist;
            }
        };

        return ElementContent;
    })();

    SearchTree = {
        getArray: function(huffman_codes) {
            var tree = [],
                bit_code = [],
                tree_pos,
                bit,
                sorted_keys = Object.keys(huffman_codes).sort(function(a, b) {
                    return huffman_codes[a].length - huffman_codes[b].length;
                });
            
            for(var c = 0; c < sorted_keys.length; c++) {
                bit_code = huffman_codes[sorted_keys[c]];
                
                tree_pos = tree;
                for(var s = 0; s < bit_code.length - 1; s++) {
                    bit = parseInt(bit_code.charAt(s));
                    
                    if(typeof tree_pos[bit] === 'undefined')
                        tree_pos[bit] = [];
                    
                    tree_pos = tree_pos[bit];
                }
                tree_pos[parseInt(bit_code.charAt(bit_code.length - 1))] = sorted_keys[c];
            } 

            return tree;
        }
    };

    $.fn.xJQ = function(options) {
        
        var settings = $.extend({}, encoder_defaults, options); 
        
        Selector.setSettingsProvider(settings);
        ElementContent.setSettingsProvider(settings);
        
        var current = $(this).first(),
            parent,
            cutting_ratio,
            nearby_ratio,
            root = $(settings.root),
            parents = $(this).parentsUntil(settings.root),
            pos = 0,
            element = new SelectorCollection,
            result = new SelectorCollection,
            last_added_pos,
            last_added,
            relation,
            current_tagname,
            best;

        if(current.length === 0) {
            throw new Error('xJQ: Cannot find selector of empty collection');
        }
        
        do {
            last_added = result.last();
            parent = current.parent();

            relation = SelectorCollection.node.NULL;    
            
            if(Math.abs(last_added_pos - pos) === 1)
                relation = SelectorCollection.node.PARENT; 
            else if(pos !== 0)
                relation = SelectorCollection.node.ANCESTOR;

            // current is empty only in $(this), where cutting_ratio should be high (1.0)
            cutting_ratio = 1.0 - (current.find('*').length / parent.find('*').length);
            nearby_ratio = 1.0 - (pos / parents.length) * 0.5;

            current_tagname = current.prop('tagName').toLowerCase(); 
           
            if(typeof Dict.elements[current_tagname] !== 'undefined')
                element.addSelector(relation, new Selector(Selector.types.ELEMENT, 'tagName', current_tagname));
            
            $.each(current[0].attributes, function(index, attr) {
                if(typeof Dict.attrs[attr.name] !== 'undefined') {
                    var all_blacklisted = true;

                    // attributes are selected by ^=, which doesn't support empty strings
                    if(/\S/.test(attr.value)) {
                        if(attr.name === 'id') {
                            element.addSelector(relation, new Selector(Selector.types.ID, attr.name, attr.value));
                        } else if(attr.name === 'class') {
                            $.each(attr.value.trim().split(/\s+/), function(index, clas) {
                                if($.inArray(clas, settings.classBlacklist) < 0) {
                                    all_blacklisted = false;
                                    element.addSelector(relation, new Selector(Selector.types.CLASS, attr.name, clas));
                                }
                            });
                        } else {
                            element.addSelector(relation, new Selector(Selector.types.ATTR_EQUALS, attr.name, attr.value));
                        }
                    }
                   
                    if(!(attr.name === 'class' && all_blacklisted))
                        element.addSelector(relation, new Selector(Selector.types.ATTR_HAS, attr.name, attr.name));
                }
            });
          
            best = element.getBestSelector(current, result, cutting_ratio, nearby_ratio);
            
                // when $(this) element currently selected
            if(pos === 0 
                // or have better rating than the last one added
                || best.getRating() < last_added.getRating()
                // or can't unambiguously resolve current selector
                || parent.find(result.getReversedCssSelector()).length > 1
                // was last added selector :nth-of-type()
                || last_added.requiresParent()
            ) {
                result.addSelector(relation, best);
                last_added_pos = pos;
            }
                
            element.clear();
            current = parent;
            pos++;
            
        } while(current[0] !== document && current[0] !== root[0]);
     
        var content = new ElementContent($(this));
        
        return result.getBinarySelector().concat(content.getOptimalFreqsEncoded());
    };
  
    $.xJQ = function(selector, options) {

        var settings = $.extend({}, decoder_defaults, options); 
        ElementContent.setSettingsProvider(settings);

        var st_elements = SearchTree.getArray(Dict.elements),
            st_attrs = SearchTree.getArray(Dict.attrs),
            st_keywords = SearchTree.getArray(Dict.keywords); 
        
        var MODE_KEYWORD = 0,
            MODE_GET_ELEMENT = 1,
            MODE_GET_ATTR = 2;

        var found = null,
            last_relation = SelectorCollection.node.NULL,
            last_keyword = null,
            st_pos = st_keywords,
            mode = MODE_KEYWORD,
            result_selector = new SelectorCollection,
            stopped = false,
            buffer = 0,
            bits_to_buffer = 0,
            bit_read = 0,
            byte_idx = 0;
        
        for(; byte_idx < selector.length && !stopped; byte_idx++) {
            for(var b = 0x80; b > 0x00 && !stopped; b = b >>> 1) {
                bit_read = +((selector[byte_idx] & b) === b);

                if(bits_to_buffer > 0) {
                    buffer |= bit_read << (--bits_to_buffer);
                    
                    if(bits_to_buffer === 0 && last_keyword === KEYWORD_NUM) {
                        result_selector.last().setPosition(buffer); 
                        bits_to_buffer = 0;
                        st_pos = st_keywords; 
                    }
                } else {
                    found = st_pos[bit_read];

                    if({}.toString.call(found) !== '[object Array]') {
                        switch(mode) {
                            case MODE_KEYWORD: {
                                last_keyword = +found;
                                
                                switch(+found) {
                                    case KEYWORD_NUM: {
                                        bits_to_buffer = 8;
                                        buffer = 0x00;
                                        break;
                                    }
                                    case KEYWORD_ID: {
                                        result_selector.addSelector(last_relation, new Selector(Selector.types.ID, 'id', found));
                                        st_pos = st_keywords; 
                                        break;
                                    }
                                    case KEYWORD_CLASS: {
                                        result_selector.addSelector(last_relation, new Selector(Selector.types.CLASS, 'class', found));
                                        st_pos = st_keywords; 
                                        break;
                                    }
                                    case KEYWORD_TAG: {
                                        mode = MODE_GET_ELEMENT; 
                                        st_pos = st_elements;
                                        break;        
                                    }
                                    case KEYWORD_HAS:
                                    case KEYWORD_EQUALS: {
                                        mode = MODE_GET_ATTR; 
                                        st_pos = st_attrs;
                                        break;
                                    }
                                    case KEYWORD_STOP: {
                                        stopped = true;
                                        break;
                                    }
                                    case KEYWORD_DESCENDANT: {
                                        last_relation = SelectorCollection.node.ANCESTOR;
                                        st_pos = st_keywords; 
                                        break;
                                    }
                                    case KEYWORD_CHILD: {
                                        last_relation = SelectorCollection.node.PARENT;
                                        st_pos = st_keywords; 
                                        break;
                                    }
                                    default: {
                                        st_pos = st_keywords; 
                                    }
                                }

                                break;
                            }
                            case MODE_GET_ELEMENT: {
                                if(last_keyword === KEYWORD_TAG) {
                                    result_selector.addSelector(last_relation, new Selector(Selector.types.ELEMENT, 'tagName', found));
                                }
                                
                                mode = MODE_KEYWORD;
                                st_pos = st_keywords;
                                break;
                            }
                            case MODE_GET_ATTR: {
                                switch(last_keyword) {
                                    case KEYWORD_HAS: {
                                        result_selector.addSelector(last_relation, new Selector(Selector.types.ATTR_HAS, 'attr', found));
                                        break;
                                    }
                                    case KEYWORD_EQUALS: {
                                        result_selector.addSelector(last_relation, new Selector(Selector.types.ATTR_EQUALS, found));
                                        break;
                                    }
                                }
                                
                                mode = MODE_KEYWORD;
                                st_pos = st_keywords;
                                break;
                            }
                        }
                    } else {
                        st_pos = found;
                    }
                }
            }
        }
        
        result_selector.each(function(selector_part) {
            var str_len,
                str;
                
            switch(selector_part.getType()) {
                case Selector.types.ID: 
                case Selector.types.CLASS: 
                case Selector.types.ATTR_EQUALS: {
                    
                    str_len = selector[byte_idx++];
                    str = selector.slice(byte_idx, byte_idx + str_len);
                    selector_part.setValue(String.fromCharCode.apply(null, str));
                    
                    byte_idx += str_len;
                }
            }
            
        });
       
        var result_css_selector = result_selector.getCssSelector(),
            selected = $(result_css_selector),
            distance,
            min_elem_dist,
            child_elem_dist,
            content = ElementContent.fromEncodedFreqs(selector.slice(byte_idx), st_elements),
            prospectives = [],
            lvl_cnter,
            min_children;

        function saveProspectives(css_selector) {
            var elem = $(css_selector); 

            if(elem.length > 0) {
                return content.minDistance(elem, function(elem, dist) {
                    prospectives.push({ dist: dist, elem: elem });
                });
            }
        }
        
        if(selected.length > 1) {
            min_elem_dist = content.minDistance(selected, function(elem, distance) {
                prospectives.push({ dist: distance, elem: elem });
            });   
        
            // found element in collection ( e.g. meanwhile added one with same class )
            if(min_elem_dist.dist === 0)
                return min_elem_dist.elem;

        } else if(selected.length === 1) {
            distance = content.distance(new ElementContent(selected));
            min_elem_dist = { dist: distance, elem: selected };
            prospectives.push(min_elem_dist);
            
            // matching exactly, DOM hasn't changed
            if(distance === 0)
                return selected;
            
        } else {
            // 1. replace all '>' child selectors with ' ' descendant ones &
            //    get rid off all :nth-of-type()'s
            result_selector.each(function(elem, type) {
                elem.setPosition(undefined);                
                
                if(type === SelectorCollection.node.PARENT)
                    return { type: SelectorCollection.node.ANCESTOR };
            });
            
            saveProspectives(result_selector.getCssSelector());
            
            // 2. cut children from right to left '.parent #child' => '.parent'
            for(var idx, max, idx = max = result_selector.size() - 1; 
                    idx > 0, (max - idx) < settings.trimSelectorParts; 
                    idx--) {
                // remove current element
                result_selector.splice(idx, 1);

                saveProspectives(result_selector.getCssSelector()); 
            }
        }

        var generalized = [];
        
        /* @todo use previous calculations as part of next loop iteration */
        for(var p = 0; p < prospectives.length; p++) {
            lvl_cnter = 0;
            
            for(var prosp = prospectives[p].elem; 
                lvl_cnter < settings.generalLevels && prosp[0] !== document;
                lvl_cnter++, prosp = prosp.parent()) {
                    
                    generalized.push(prosp);
                    generalized.push.apply(generalized, prosp.siblings());
                }
        }
        
        if(generalized.length > 0) {
            min_elem_dist = content.minDistance(generalized);   
            
            lvl_cnter = 0;
            while((min_children = min_elem_dist.elem.children()) 
                    && min_children.length > 0
                    && settings.approxLevels > (lvl_cnter++)) {
        
                child_elem_dist = content.minDistance(min_children);
                
                if(child_elem_dist.dist < min_elem_dist.dist) {
                    min_elem_dist = child_elem_dist;
                } else
                    break;
            }
        }
        
        if(min_elem_dist.dist > settings.similarityThreshold)
            throw new Error('xJQ: element with selector `' + result_css_selector + '` cannot be found or its content has changed');
        
        return min_elem_dist.elem;
    };
})(jQuery);

 })();

/**
 * Rangy, a cross-browser JavaScript range and selection library
 * http://code.google.com/p/rangy/
 *
 * Copyright 2013, Tim Down
 * Licensed under the MIT license.
 * Version: 1.3alpha.804
 * Build date: 8 December 2013
 */

(function(global) {
    var amdSupported = (typeof global.define == "function" && global.define.amd);

    var OBJECT = "object", FUNCTION = "function", UNDEFINED = "undefined";

    // Minimal set of properties required for DOM Level 2 Range compliance. Comparison constants such as START_TO_START
    // are omitted because ranges in KHTML do not have them but otherwise work perfectly well. See issue 113.
    var domRangeProperties = ["startContainer", "startOffset", "endContainer", "endOffset", "collapsed",
        "commonAncestorContainer"];

    // Minimal set of methods required for DOM Level 2 Range compliance
    var domRangeMethods = ["setStart", "setStartBefore", "setStartAfter", "setEnd", "setEndBefore",
        "setEndAfter", "collapse", "selectNode", "selectNodeContents", "compareBoundaryPoints", "deleteContents",
        "extractContents", "cloneContents", "insertNode", "surroundContents", "cloneRange", "toString", "detach"];

    var textRangeProperties = ["boundingHeight", "boundingLeft", "boundingTop", "boundingWidth", "htmlText", "text"];

    // Subset of TextRange's full set of methods that we're interested in
    var textRangeMethods = ["collapse", "compareEndPoints", "duplicate", "moveToElementText", "parentElement", "select",
        "setEndPoint", "getBoundingClientRect"];

    /*----------------------------------------------------------------------------------------------------------------*/

    // Trio of functions taken from Peter Michaux's article:
    // http://peter.michaux.ca/articles/feature-detection-state-of-the-art-browser-scripting
    function isHostMethod(o, p) {
        var t = typeof o[p];
        return t == FUNCTION || (!!(t == OBJECT && o[p])) || t == "unknown";
    }

    function isHostObject(o, p) {
        return !!(typeof o[p] == OBJECT && o[p]);
    }

    function isHostProperty(o, p) {
        return typeof o[p] != UNDEFINED;
    }

    // Creates a convenience function to save verbose repeated calls to tests functions
    function createMultiplePropertyTest(testFunc) {
        return function(o, props) {
            var i = props.length;
            while (i--) {
                if (!testFunc(o, props[i])) {
                    return false;
                }
            }
            return true;
        };
    }

    // Next trio of functions are a convenience to save verbose repeated calls to previous two functions
    var areHostMethods = createMultiplePropertyTest(isHostMethod);
    var areHostObjects = createMultiplePropertyTest(isHostObject);
    var areHostProperties = createMultiplePropertyTest(isHostProperty);

    function isTextRange(range) {
        return range && areHostMethods(range, textRangeMethods) && areHostProperties(range, textRangeProperties);
    }

    function getBody(doc) {
        return isHostObject(doc, "body") ? doc.body : doc.getElementsByTagName("body")[0];
    }

    var modules = {};

    var api = {
        version: "1.3alpha.804",
        initialized: false,
        supported: true,

        util: {
            isHostMethod: isHostMethod,
            isHostObject: isHostObject,
            isHostProperty: isHostProperty,
            areHostMethods: areHostMethods,
            areHostObjects: areHostObjects,
            areHostProperties: areHostProperties,
            isTextRange: isTextRange,
            getBody: getBody
        },

        features: {},

        modules: modules,
        config: {
            alertOnFail: true,
            alertOnWarn: false,
            preferTextRange: false
        }
    };

    function consoleLog(msg) {
        if (isHostObject(window, "console") && isHostMethod(window.console, "log")) {
            window.console.log(msg);
        }
    }

    function alertOrLog(msg, shouldAlert) {
        if (shouldAlert) {
            window.alert(msg);
        } else  {
            consoleLog(msg);
        }
    }

    function fail(reason) {
        api.initialized = true;
        api.supported = false;
        alertOrLog("Rangy is not supported on this page in your browser. Reason: " + reason, api.config.alertOnFail);
    }

    api.fail = fail;

    function warn(msg) {
        alertOrLog("Rangy warning: " + msg, api.config.alertOnWarn);
    }

    api.warn = warn;

    // Add utility extend() method
    if ({}.hasOwnProperty) {
        api.util.extend = function(obj, props, deep) {
            var o, p;
            for (var i in props) {
                if (props.hasOwnProperty(i)) {
                    o = obj[i];
                    p = props[i];
                    //if (deep) alert([o !== null, typeof o == "object", p !== null, typeof p == "object"])
                    if (deep && o !== null && typeof o == "object" && p !== null && typeof p == "object") {
                        api.util.extend(o, p, true);
                    }
                    obj[i] = p;
                }
            }
            return obj;
        };
    } else {
        fail("hasOwnProperty not supported");
    }

    // Test whether Array.prototype.slice can be relied on for NodeLists and use an alternative toArray() if not
    (function() {
        var el = document.createElement("div");
        el.appendChild(document.createElement("span"));
        var slice = [].slice;
        var toArray;
        try {
            if (slice.call(el.childNodes, 0)[0].nodeType == 1) {
                toArray = function(arrayLike) {
                    return slice.call(arrayLike, 0);
                };
            }
        } catch (e) {}

        if (!toArray) {
            toArray = function(arrayLike) {
                var arr = [];
                for (var i = 0, len = arrayLike.length; i < len; ++i) {
                    arr[i] = arrayLike[i];
                }
                return arr;
            };
        }

        api.util.toArray = toArray;
    })();


    // Very simple event handler wrapper function that doesn't attempt to solve issues such as "this" handling or
    // normalization of event properties
    var addListener;
    if (isHostMethod(document, "addEventListener")) {
        addListener = function(obj, eventType, listener) {
            obj.addEventListener(eventType, listener, false);
        };
    } else if (isHostMethod(document, "attachEvent")) {
        addListener = function(obj, eventType, listener) {
            obj.attachEvent("on" + eventType, listener);
        };
    } else {
        fail("Document does not have required addEventListener or attachEvent method");
    }

    api.util.addListener = addListener;

    var initListeners = [];

    function getErrorDesc(ex) {
        return ex.message || ex.description || String(ex);
    }

    // Initialization
    function init() {
        if (api.initialized) {
            return;
        }
        var testRange;
        var implementsDomRange = false, implementsTextRange = false;

        // First, perform basic feature tests

        if (isHostMethod(document, "createRange")) {
            testRange = document.createRange();
            if (areHostMethods(testRange, domRangeMethods) && areHostProperties(testRange, domRangeProperties)) {
                implementsDomRange = true;
            }
            testRange.detach();
        }

        var body = getBody(document);
        if (!body || body.nodeName.toLowerCase() != "body") {
            fail("No body element found");
            return;
        }

        if (body && isHostMethod(body, "createTextRange")) {
            testRange = body.createTextRange();
            if (isTextRange(testRange)) {
                implementsTextRange = true;
            }
        }

        if (!implementsDomRange && !implementsTextRange) {
            fail("Neither Range nor TextRange are available");
            return;
        }

        api.initialized = true;
        api.features = {
            implementsDomRange: implementsDomRange,
            implementsTextRange: implementsTextRange
        };

        // Initialize modules
        var module, errorMessage;
        for (var moduleName in modules) {
            if ( (module = modules[moduleName]) instanceof Module ) {
                module.init(module, api);
            }
        }

        // Call init listeners
        for (var i = 0, len = initListeners.length; i < len; ++i) {
            try {
                initListeners[i](api);
            } catch (ex) {
                errorMessage = "Rangy init listener threw an exception. Continuing. Detail: " + getErrorDesc(ex);
                consoleLog(errorMessage);
            }
        }
    }

    // Allow external scripts to initialize this library in case it's loaded after the document has loaded
    api.init = init;

    // Execute listener immediately if already initialized
    api.addInitListener = function(listener) {
        if (api.initialized) {
            listener(api);
        } else {
            initListeners.push(listener);
        }
    };

    var createMissingNativeApiListeners = [];

    api.addCreateMissingNativeApiListener = function(listener) {
        createMissingNativeApiListeners.push(listener);
    };

    function createMissingNativeApi(win) {
        win = win || window;
        init();

        // Notify listeners
        for (var i = 0, len = createMissingNativeApiListeners.length; i < len; ++i) {
            createMissingNativeApiListeners[i](win);
        }
    }

    api.createMissingNativeApi = createMissingNativeApi;

    function Module(name, dependencies, initializer) {
        this.name = name;
        this.dependencies = dependencies;
        this.initialized = false;
        this.supported = false;
        this.initializer = initializer;
    }

    Module.prototype = {
        init: function(api) {
            var requiredModuleNames = this.dependencies || [];
            for (var i = 0, len = requiredModuleNames.length, requiredModule, moduleName; i < len; ++i) {
                moduleName = requiredModuleNames[i];

                requiredModule = modules[moduleName];
                if (!requiredModule || !(requiredModule instanceof Module)) {
                    throw new Error("required module '" + moduleName + "' not found");
                }

                requiredModule.init();

                if (!requiredModule.supported) {
                    throw new Error("required module '" + moduleName + "' not supported");
                }
            }
            
            // Now run initializer
            this.initializer(this)
        },
        
        fail: function(reason) {
            this.initialized = true;
            this.supported = false;
            throw new Error("Module '" + this.name + "' failed to load: " + reason);
        },

        warn: function(msg) {
            api.warn("Module " + this.name + ": " + msg);
        },

        deprecationNotice: function(deprecated, replacement) {
            api.warn("DEPRECATED: " + deprecated + " in module " + this.name + "is deprecated. Please use "
                + replacement + " instead");
        },

        createError: function(msg) {
            return new Error("Error in Rangy " + this.name + " module: " + msg);
        }
    };
    
    function createModule(isCore, name, dependencies, initFunc) {
        var newModule = new Module(name, dependencies, function(module) {
            if (!module.initialized) {
                module.initialized = true;
                try {
                    initFunc(api, module);
                    module.supported = true;
                } catch (ex) {
                    var errorMessage = "Module '" + name + "' failed to load: " + getErrorDesc(ex);
                    consoleLog(errorMessage);
                }
            }
        });
        modules[name] = newModule;
        
/*
        // Add module AMD support
        if (!isCore && amdSupported) {
            global.define(["rangy-core"], function(rangy) {
                
            });
        }
*/
    }

    api.createModule = function(name) {
        // Allow 2 or 3 arguments (second argument is an optional array of dependencies)
        var initFunc, dependencies;
        if (arguments.length == 2) {
            initFunc = arguments[1];
            dependencies = [];
        } else {
            initFunc = arguments[2];
            dependencies = arguments[1];
        }
        createModule(false, name, dependencies, initFunc);
    };

    api.createCoreModule = function(name, dependencies, initFunc) {
        createModule(true, name, dependencies, initFunc);
    };

    /*----------------------------------------------------------------------------------------------------------------*/

    // Ensure rangy.rangePrototype and rangy.selectionPrototype are available immediately

    function RangePrototype() {}
    api.RangePrototype = RangePrototype;
    api.rangePrototype = new RangePrototype();

    function SelectionPrototype() {}
    api.selectionPrototype = new SelectionPrototype();

    /*----------------------------------------------------------------------------------------------------------------*/

    // Wait for document to load before running tests

    var docReady = false;

    var loadHandler = function(e) {
        if (!docReady) {
            docReady = true;
            if (!api.initialized) {
                init();
            }
        }
    };

    // Test whether we have window and document objects that we will need
    if (typeof window == UNDEFINED) {
        fail("No window found");
        return;
    }
    if (typeof document == UNDEFINED) {
        fail("No document found");
        return;
    }

    if (isHostMethod(document, "addEventListener")) {
        document.addEventListener("DOMContentLoaded", loadHandler, false);
    }

    // Add a fallback in case the DOMContentLoaded event isn't supported
    addListener(window, "load", loadHandler);

    /*----------------------------------------------------------------------------------------------------------------*/
    
    // AMD, for those who like this kind of thing

    if (amdSupported) {
        // AMD. Register as an anonymous module.
        global.define(function() {
            api.amd = true;
            return api;
        });
    }
    
    // Create a "rangy" property of the global object in any case. Other Rangy modules (which use Rangy's own simple
    // module system) rely on the existence of this global property
    global.rangy = api;
})(this);    

rangy.createCoreModule("DomUtil", [], function(api, module) {
    var UNDEF = "undefined";
    var util = api.util;

    // Perform feature tests
    if (!util.areHostMethods(document, ["createDocumentFragment", "createElement", "createTextNode"])) {
        module.fail("document missing a Node creation method");
    }

    if (!util.isHostMethod(document, "getElementsByTagName")) {
        module.fail("document missing getElementsByTagName method");
    }

    var el = document.createElement("div");
    if (!util.areHostMethods(el, ["insertBefore", "appendChild", "cloneNode"] ||
            !util.areHostObjects(el, ["previousSibling", "nextSibling", "childNodes", "parentNode"]))) {
        module.fail("Incomplete Element implementation");
    }

    // innerHTML is required for Range's createContextualFragment method
    if (!util.isHostProperty(el, "innerHTML")) {
        module.fail("Element is missing innerHTML property");
    }

    var textNode = document.createTextNode("test");
    if (!util.areHostMethods(textNode, ["splitText", "deleteData", "insertData", "appendData", "cloneNode"] ||
            !util.areHostObjects(el, ["previousSibling", "nextSibling", "childNodes", "parentNode"]) ||
            !util.areHostProperties(textNode, ["data"]))) {
        module.fail("Incomplete Text Node implementation");
    }

    /*----------------------------------------------------------------------------------------------------------------*/

    // Removed use of indexOf because of a bizarre bug in Opera that is thrown in one of the Acid3 tests. I haven't been
    // able to replicate it outside of the test. The bug is that indexOf returns -1 when called on an Array that
    // contains just the document as a single element and the value searched for is the document.
    var arrayContains = /*Array.prototype.indexOf ?
        function(arr, val) {
            return arr.indexOf(val) > -1;
        }:*/

        function(arr, val) {
            var i = arr.length;
            while (i--) {
                if (arr[i] === val) {
                    return true;
                }
            }
            return false;
        };

    // Opera 11 puts HTML elements in the null namespace, it seems, and IE 7 has undefined namespaceURI
    function isHtmlNamespace(node) {
        var ns;
        return typeof node.namespaceURI == UNDEF || ((ns = node.namespaceURI) === null || ns == "http://www.w3.org/1999/xhtml");
    }

    function parentElement(node) {
        var parent = node.parentNode;
        return (parent.nodeType == 1) ? parent : null;
    }

    function getNodeIndex(node) {
        var i = 0;
        while( (node = node.previousSibling) ) {
            ++i;
        }
        return i;
    }

    function getNodeLength(node) {
        switch (node.nodeType) {
            case 7:
            case 10:
                return 0;
            case 3:
            case 8:
                return node.length;
            default:
                return node.childNodes.length;
        }
    }

    function getCommonAncestor(node1, node2) {
        var ancestors = [], n;
        for (n = node1; n; n = n.parentNode) {
            ancestors.push(n);
        }

        for (n = node2; n; n = n.parentNode) {
            if (arrayContains(ancestors, n)) {
                return n;
            }
        }

        return null;
    }

    function isAncestorOf(ancestor, descendant, selfIsAncestor) {
        var n = selfIsAncestor ? descendant : descendant.parentNode;
        while (n) {
            if (n === ancestor) {
                return true;
            } else {
                n = n.parentNode;
            }
        }
        return false;
    }

    function isOrIsAncestorOf(ancestor, descendant) {
        return isAncestorOf(ancestor, descendant, true);
    }

    function getClosestAncestorIn(node, ancestor, selfIsAncestor) {
        var p, n = selfIsAncestor ? node : node.parentNode;
        while (n) {
            p = n.parentNode;
            if (p === ancestor) {
                return n;
            }
            n = p;
        }
        return null;
    }

    function isCharacterDataNode(node) {
        var t = node.nodeType;
        return t == 3 || t == 4 || t == 8 ; // Text, CDataSection or Comment
    }

    function isTextOrCommentNode(node) {
        if (!node) {
            return false;
        }
        var t = node.nodeType;
        return t == 3 || t == 8 ; // Text or Comment
    }

    function insertAfter(node, precedingNode) {
        var nextNode = precedingNode.nextSibling, parent = precedingNode.parentNode;
        if (nextNode) {
            parent.insertBefore(node, nextNode);
        } else {
            parent.appendChild(node);
        }
        return node;
    }

    // Note that we cannot use splitText() because it is bugridden in IE 9.
    function splitDataNode(node, index, positionsToPreserve) {
        var newNode = node.cloneNode(false);
        newNode.deleteData(0, index);
        node.deleteData(index, node.length - index);
        insertAfter(newNode, node);

        // Preserve positions
        if (positionsToPreserve) {
            for (var i = 0, position; position = positionsToPreserve[i++]; ) {
                // Handle case where position was inside the portion of node after the split point
                if (position.node == node && position.offset > index) {
                    position.node = newNode;
                    position.offset -= index;
                }
                // Handle the case where the position is a node offset within node's parent
                else if (position.node == node.parentNode && position.offset > getNodeIndex(node)) {
                    ++position.offset;
                }
            }
        }
        return newNode;
    }

    function getDocument(node) {
        if (node.nodeType == 9) {
            return node;
        } else if (typeof node.ownerDocument != UNDEF) {
            return node.ownerDocument;
        } else if (typeof node.document != UNDEF) {
            return node.document;
        } else if (node.parentNode) {
            return getDocument(node.parentNode);
        } else {
            throw module.createError("getDocument: no document found for node");
        }
    }

    function getWindow(node) {
        var doc = getDocument(node);
        if (typeof doc.defaultView != UNDEF) {
            return doc.defaultView;
        } else if (typeof doc.parentWindow != UNDEF) {
            return doc.parentWindow;
        } else {
            throw module.createError("Cannot get a window object for node");
        }
    }

    function getIframeDocument(iframeEl) {
        if (typeof iframeEl.contentDocument != UNDEF) {
            return iframeEl.contentDocument;
        } else if (typeof iframeEl.contentWindow != UNDEF) {
            return iframeEl.contentWindow.document;
        } else {
            throw module.createError("getIframeDocument: No Document object found for iframe element");
        }
    }

    function getIframeWindow(iframeEl) {
        if (typeof iframeEl.contentWindow != UNDEF) {
            return iframeEl.contentWindow;
        } else if (typeof iframeEl.contentDocument != UNDEF) {
            return iframeEl.contentDocument.defaultView;
        } else {
            throw module.createError("getIframeWindow: No Window object found for iframe element");
        }
    }

    // This looks bad. Is it worth it?
    function isWindow(obj) {
        return obj && util.isHostMethod(obj, "setTimeout") && util.isHostObject(obj, "document");
    }

    function getContentDocument(obj, module, methodName) {
        var doc;

        if (!obj) {
            doc = document;
        }

        // Test if a DOM node has been passed and obtain a document object for it if so
        else if (util.isHostProperty(obj, "nodeType")) {
            doc = (obj.nodeType == 1 && obj.tagName.toLowerCase() == "iframe")
                ? getIframeDocument(obj) : getDocument(obj);
        }

        // Test if the doc parameter appears to be a Window object
        else if (isWindow(obj)) {
            doc = obj.document;
        }

        if (!doc) {
            throw module.createError(methodName + "(): Parameter must be a Window object or DOM node");
        }

        return doc;
    }

    function getRootContainer(node) {
        var parent;
        while ( (parent = node.parentNode) ) {
            node = parent;
        }
        return node;
    }

    function comparePoints(nodeA, offsetA, nodeB, offsetB) {
        // See http://www.w3.org/TR/DOM-Level-2-Traversal-Range/ranges.html#Level-2-Range-Comparing
        var nodeC, root, childA, childB, n;
        if (nodeA == nodeB) {
            // Case 1: nodes are the same
            return offsetA === offsetB ? 0 : (offsetA < offsetB) ? -1 : 1;
        } else if ( (nodeC = getClosestAncestorIn(nodeB, nodeA, true)) ) {
            // Case 2: node C (container B or an ancestor) is a child node of A
            return offsetA <= getNodeIndex(nodeC) ? -1 : 1;
        } else if ( (nodeC = getClosestAncestorIn(nodeA, nodeB, true)) ) {
            // Case 3: node C (container A or an ancestor) is a child node of B
            return getNodeIndex(nodeC) < offsetB  ? -1 : 1;
        } else {
            root = getCommonAncestor(nodeA, nodeB);
            if (!root) {
                throw new Error("comparePoints error: nodes have no common ancestor");
            }

            // Case 4: containers are siblings or descendants of siblings
            childA = (nodeA === root) ? root : getClosestAncestorIn(nodeA, root, true);
            childB = (nodeB === root) ? root : getClosestAncestorIn(nodeB, root, true);

            if (childA === childB) {
                // This shouldn't be possible
                throw module.createError("comparePoints got to case 4 and childA and childB are the same!");
            } else {
                n = root.firstChild;
                while (n) {
                    if (n === childA) {
                        return -1;
                    } else if (n === childB) {
                        return 1;
                    }
                    n = n.nextSibling;
                }
            }
        }
    }

    /*----------------------------------------------------------------------------------------------------------------*/

    // Test for IE's crash (IE 6/7) or exception (IE >= 8) when a reference to garbage-collected text node is queried
    var crashyTextNodes = false;

    function isBrokenNode(node) {
        try {
            node.parentNode;
            return false;
        } catch (e) {
            return true;
        }
    }

    (function() {
        var el = document.createElement("b");
        el.innerHTML = "1";
        var textNode = el.firstChild;
        el.innerHTML = "<br>";
        crashyTextNodes = isBrokenNode(textNode);

        api.features.crashyTextNodes = crashyTextNodes;
    })();

    /*----------------------------------------------------------------------------------------------------------------*/

    function inspectNode(node) {
        if (!node) {
            return "[No node]";
        }
        if (crashyTextNodes && isBrokenNode(node)) {
            return "[Broken node]";
        }
        if (isCharacterDataNode(node)) {
            return '"' + node.data + '"';
        }
        if (node.nodeType == 1) {
            var idAttr = node.id ? ' id="' + node.id + '"' : "";
            return "<" + node.nodeName + idAttr + ">[" + getNodeIndex(node) + "][" + node.childNodes.length + "][" + (node.innerHTML || "[innerHTML not supported]").slice(0, 25) + "]";
        }
        return node.nodeName;
    }

    function fragmentFromNodeChildren(node) {
        var fragment = getDocument(node).createDocumentFragment(), child;
        while ( (child = node.firstChild) ) {
            fragment.appendChild(child);
        }
        return fragment;
    }

    var getComputedStyleProperty;
    if (typeof window.getComputedStyle != UNDEF) {
        getComputedStyleProperty = function(el, propName) {
            return getWindow(el).getComputedStyle(el, null)[propName];
        };
    } else if (typeof document.documentElement.currentStyle != UNDEF) {
        getComputedStyleProperty = function(el, propName) {
            return el.currentStyle[propName];
        };
    } else {
        module.fail("No means of obtaining computed style properties found");
    }

    function NodeIterator(root) {
        this.root = root;
        this._next = root;
    }

    NodeIterator.prototype = {
        _current: null,

        hasNext: function() {
            return !!this._next;
        },

        next: function() {
            var n = this._current = this._next;
            var child, next;
            if (this._current) {
                child = n.firstChild;
                if (child) {
                    this._next = child;
                } else {
                    next = null;
                    while ((n !== this.root) && !(next = n.nextSibling)) {
                        n = n.parentNode;
                    }
                    this._next = next;
                }
            }
            return this._current;
        },

        detach: function() {
            this._current = this._next = this.root = null;
        }
    };

    function createIterator(root) {
        return new NodeIterator(root);
    }

    function DomPosition(node, offset) {
        this.node = node;
        this.offset = offset;
    }

    DomPosition.prototype = {
        equals: function(pos) {
            return !!pos && this.node === pos.node && this.offset == pos.offset;
        },

        inspect: function() {
            return "[DomPosition(" + inspectNode(this.node) + ":" + this.offset + ")]";
        },

        toString: function() {
            return this.inspect();
        }
    };

    function DOMException(codeName) {
        this.code = this[codeName];
        this.codeName = codeName;
        this.message = "DOMException: " + this.codeName;
    }

    DOMException.prototype = {
        INDEX_SIZE_ERR: 1,
        HIERARCHY_REQUEST_ERR: 3,
        WRONG_DOCUMENT_ERR: 4,
        NO_MODIFICATION_ALLOWED_ERR: 7,
        NOT_FOUND_ERR: 8,
        NOT_SUPPORTED_ERR: 9,
        INVALID_STATE_ERR: 11
    };

    DOMException.prototype.toString = function() {
        return this.message;
    };

    api.dom = {
        arrayContains: arrayContains,
        isHtmlNamespace: isHtmlNamespace,
        parentElement: parentElement,
        getNodeIndex: getNodeIndex,
        getNodeLength: getNodeLength,
        getCommonAncestor: getCommonAncestor,
        isAncestorOf: isAncestorOf,
        isOrIsAncestorOf: isOrIsAncestorOf,
        getClosestAncestorIn: getClosestAncestorIn,
        isCharacterDataNode: isCharacterDataNode,
        isTextOrCommentNode: isTextOrCommentNode,
        insertAfter: insertAfter,
        splitDataNode: splitDataNode,
        getDocument: getDocument,
        getWindow: getWindow,
        getIframeWindow: getIframeWindow,
        getIframeDocument: getIframeDocument,
        getBody: util.getBody,
        isWindow: isWindow,
        getContentDocument: getContentDocument,
        getRootContainer: getRootContainer,
        comparePoints: comparePoints,
        isBrokenNode: isBrokenNode,
        inspectNode: inspectNode,
        getComputedStyleProperty: getComputedStyleProperty,
        fragmentFromNodeChildren: fragmentFromNodeChildren,
        createIterator: createIterator,
        DomPosition: DomPosition
    };

    api.DOMException = DOMException;
});
rangy.createCoreModule("DomRange", ["DomUtil"], function(api, module) {
    var dom = api.dom;
    var util = api.util;
    var DomPosition = dom.DomPosition;
    var DOMException = api.DOMException;

    var isCharacterDataNode = dom.isCharacterDataNode;
    var getNodeIndex = dom.getNodeIndex;
    var isOrIsAncestorOf = dom.isOrIsAncestorOf;
    var getDocument = dom.getDocument;
    var comparePoints = dom.comparePoints;
    var splitDataNode = dom.splitDataNode;
    var getClosestAncestorIn = dom.getClosestAncestorIn;
    var getNodeLength = dom.getNodeLength;
    var arrayContains = dom.arrayContains;
    var getRootContainer = dom.getRootContainer;
    var crashyTextNodes = api.features.crashyTextNodes;

    /*----------------------------------------------------------------------------------------------------------------*/

    // Utility functions

    function isNonTextPartiallySelected(node, range) {
        return (node.nodeType != 3) &&
               (isOrIsAncestorOf(node, range.startContainer) || isOrIsAncestorOf(node, range.endContainer));
    }

    function getRangeDocument(range) {
        return range.document || getDocument(range.startContainer);
    }

    function getBoundaryBeforeNode(node) {
        return new DomPosition(node.parentNode, getNodeIndex(node));
    }

    function getBoundaryAfterNode(node) {
        return new DomPosition(node.parentNode, getNodeIndex(node) + 1);
    }

    function insertNodeAtPosition(node, n, o) {
        var firstNodeInserted = node.nodeType == 11 ? node.firstChild : node;
        if (isCharacterDataNode(n)) {
            if (o == n.length) {
                dom.insertAfter(node, n);
            } else {
                n.parentNode.insertBefore(node, o == 0 ? n : splitDataNode(n, o));
            }
        } else if (o >= n.childNodes.length) {
            n.appendChild(node);
        } else {
            n.insertBefore(node, n.childNodes[o]);
        }
        return firstNodeInserted;
    }

    function rangesIntersect(rangeA, rangeB, touchingIsIntersecting) {
        assertRangeValid(rangeA);
        assertRangeValid(rangeB);

        if (getRangeDocument(rangeB) != getRangeDocument(rangeA)) {
            throw new DOMException("WRONG_DOCUMENT_ERR");
        }

        var startComparison = comparePoints(rangeA.startContainer, rangeA.startOffset, rangeB.endContainer, rangeB.endOffset),
            endComparison = comparePoints(rangeA.endContainer, rangeA.endOffset, rangeB.startContainer, rangeB.startOffset);

        return touchingIsIntersecting ? startComparison <= 0 && endComparison >= 0 : startComparison < 0 && endComparison > 0;
    }

    function cloneSubtree(iterator) {
        var partiallySelected;
        for (var node, frag = getRangeDocument(iterator.range).createDocumentFragment(), subIterator; node = iterator.next(); ) {
            partiallySelected = iterator.isPartiallySelectedSubtree();
            node = node.cloneNode(!partiallySelected);
            if (partiallySelected) {
                subIterator = iterator.getSubtreeIterator();
                node.appendChild(cloneSubtree(subIterator));
                subIterator.detach(true);
            }

            if (node.nodeType == 10) { // DocumentType
                throw new DOMException("HIERARCHY_REQUEST_ERR");
            }
            frag.appendChild(node);
        }
        return frag;
    }

    function iterateSubtree(rangeIterator, func, iteratorState) {
        var it, n;
        iteratorState = iteratorState || { stop: false };
        for (var node, subRangeIterator; node = rangeIterator.next(); ) {
            if (rangeIterator.isPartiallySelectedSubtree()) {
                if (func(node) === false) {
                    iteratorState.stop = true;
                    return;
                } else {
                    // The node is partially selected by the Range, so we can use a new RangeIterator on the portion of
                    // the node selected by the Range.
                    subRangeIterator = rangeIterator.getSubtreeIterator();
                    iterateSubtree(subRangeIterator, func, iteratorState);
                    subRangeIterator.detach(true);
                    if (iteratorState.stop) {
                        return;
                    }
                }
            } else {
                // The whole node is selected, so we can use efficient DOM iteration to iterate over the node and its
                // descendants
                it = dom.createIterator(node);
                while ( (n = it.next()) ) {
                    if (func(n) === false) {
                        iteratorState.stop = true;
                        return;
                    }
                }
            }
        }
    }

    function deleteSubtree(iterator) {
        var subIterator;
        while (iterator.next()) {
            if (iterator.isPartiallySelectedSubtree()) {
                subIterator = iterator.getSubtreeIterator();
                deleteSubtree(subIterator);
                subIterator.detach(true);
            } else {
                iterator.remove();
            }
        }
    }

    function extractSubtree(iterator) {
        for (var node, frag = getRangeDocument(iterator.range).createDocumentFragment(), subIterator; node = iterator.next(); ) {

            if (iterator.isPartiallySelectedSubtree()) {
                node = node.cloneNode(false);
                subIterator = iterator.getSubtreeIterator();
                node.appendChild(extractSubtree(subIterator));
                subIterator.detach(true);
            } else {
                iterator.remove();
            }
            if (node.nodeType == 10) { // DocumentType
                throw new DOMException("HIERARCHY_REQUEST_ERR");
            }
            frag.appendChild(node);
        }
        return frag;
    }

    function getNodesInRange(range, nodeTypes, filter) {
        var filterNodeTypes = !!(nodeTypes && nodeTypes.length), regex;
        var filterExists = !!filter;
        if (filterNodeTypes) {
            regex = new RegExp("^(" + nodeTypes.join("|") + ")$");
        }

        var nodes = [];
        iterateSubtree(new RangeIterator(range, false), function(node) {
            if (filterNodeTypes && !regex.test(node.nodeType)) {
                return;
            }
            if (filterExists && !filter(node)) {
                return;
            }
            // Don't include a boundary container if it is a character data node and the range does not contain any
            // of its character data. See issue 190.
            var sc = range.startContainer;
            if (node == sc && isCharacterDataNode(sc) && range.startOffset == sc.length) {
                return;
            }

            var ec = range.endContainer;
            if (node == ec && isCharacterDataNode(ec) && range.endOffset == 0) {
                return;
            }

            nodes.push(node);
        });
        return nodes;
    }

    function inspect(range) {
        var name = (typeof range.getName == "undefined") ? "Range" : range.getName();
        return "[" + name + "(" + dom.inspectNode(range.startContainer) + ":" + range.startOffset + ", " +
                dom.inspectNode(range.endContainer) + ":" + range.endOffset + ")]";
    }

    /*----------------------------------------------------------------------------------------------------------------*/

    // RangeIterator code partially borrows from IERange by Tim Ryan (http://github.com/timcameronryan/IERange)

    function RangeIterator(range, clonePartiallySelectedTextNodes) {
        this.range = range;
        this.clonePartiallySelectedTextNodes = clonePartiallySelectedTextNodes;


        if (!range.collapsed) {
            this.sc = range.startContainer;
            this.so = range.startOffset;
            this.ec = range.endContainer;
            this.eo = range.endOffset;
            var root = range.commonAncestorContainer;

            if (this.sc === this.ec && isCharacterDataNode(this.sc)) {
                this.isSingleCharacterDataNode = true;
                this._first = this._last = this._next = this.sc;
            } else {
                this._first = this._next = (this.sc === root && !isCharacterDataNode(this.sc)) ?
                    this.sc.childNodes[this.so] : getClosestAncestorIn(this.sc, root, true);
                this._last = (this.ec === root && !isCharacterDataNode(this.ec)) ?
                    this.ec.childNodes[this.eo - 1] : getClosestAncestorIn(this.ec, root, true);
            }
        }
    }

    RangeIterator.prototype = {
        _current: null,
        _next: null,
        _first: null,
        _last: null,
        isSingleCharacterDataNode: false,

        reset: function() {
            this._current = null;
            this._next = this._first;
        },

        hasNext: function() {
            return !!this._next;
        },

        next: function() {
            // Move to next node
            var current = this._current = this._next;
            if (current) {
                this._next = (current !== this._last) ? current.nextSibling : null;

                // Check for partially selected text nodes
                if (isCharacterDataNode(current) && this.clonePartiallySelectedTextNodes) {
                    if (current === this.ec) {
                        (current = current.cloneNode(true)).deleteData(this.eo, current.length - this.eo);
                    }
                    if (this._current === this.sc) {
                        (current = current.cloneNode(true)).deleteData(0, this.so);
                    }
                }
            }

            return current;
        },

        remove: function() {
            var current = this._current, start, end;

            if (isCharacterDataNode(current) && (current === this.sc || current === this.ec)) {
                start = (current === this.sc) ? this.so : 0;
                end = (current === this.ec) ? this.eo : current.length;
                if (start != end) {
                    current.deleteData(start, end - start);
                }
            } else {
                if (current.parentNode) {
                    current.parentNode.removeChild(current);
                } else {
                }
            }
        },

        // Checks if the current node is partially selected
        isPartiallySelectedSubtree: function() {
            var current = this._current;
            return isNonTextPartiallySelected(current, this.range);
        },

        getSubtreeIterator: function() {
            var subRange;
            if (this.isSingleCharacterDataNode) {
                subRange = this.range.cloneRange();
                subRange.collapse(false);
            } else {
                subRange = new Range(getRangeDocument(this.range));
                var current = this._current;
                var startContainer = current, startOffset = 0, endContainer = current, endOffset = getNodeLength(current);

                if (isOrIsAncestorOf(current, this.sc)) {
                    startContainer = this.sc;
                    startOffset = this.so;
                }
                if (isOrIsAncestorOf(current, this.ec)) {
                    endContainer = this.ec;
                    endOffset = this.eo;
                }

                updateBoundaries(subRange, startContainer, startOffset, endContainer, endOffset);
            }
            return new RangeIterator(subRange, this.clonePartiallySelectedTextNodes);
        },

        detach: function(detachRange) {
            if (detachRange) {
                this.range.detach();
            }
            this.range = this._current = this._next = this._first = this._last = this.sc = this.so = this.ec = this.eo = null;
        }
    };

    /*----------------------------------------------------------------------------------------------------------------*/

    // Exceptions

    function RangeException(codeName) {
        this.code = this[codeName];
        this.codeName = codeName;
        this.message = "RangeException: " + this.codeName;
    }

    RangeException.prototype = {
        BAD_BOUNDARYPOINTS_ERR: 1,
        INVALID_NODE_TYPE_ERR: 2
    };

    RangeException.prototype.toString = function() {
        return this.message;
    };

    /*----------------------------------------------------------------------------------------------------------------*/

    var beforeAfterNodeTypes = [1, 3, 4, 5, 7, 8, 10];
    var rootContainerNodeTypes = [2, 9, 11];
    var readonlyNodeTypes = [5, 6, 10, 12];
    var insertableNodeTypes = [1, 3, 4, 5, 7, 8, 10, 11];
    var surroundNodeTypes = [1, 3, 4, 5, 7, 8];

    function createAncestorFinder(nodeTypes) {
        return function(node, selfIsAncestor) {
            var t, n = selfIsAncestor ? node : node.parentNode;
            while (n) {
                t = n.nodeType;
                if (arrayContains(nodeTypes, t)) {
                    return n;
                }
                n = n.parentNode;
            }
            return null;
        };
    }

    var getDocumentOrFragmentContainer = createAncestorFinder( [9, 11] );
    var getReadonlyAncestor = createAncestorFinder(readonlyNodeTypes);
    var getDocTypeNotationEntityAncestor = createAncestorFinder( [6, 10, 12] );

    function assertNoDocTypeNotationEntityAncestor(node, allowSelf) {
        if (getDocTypeNotationEntityAncestor(node, allowSelf)) {
            throw new RangeException("INVALID_NODE_TYPE_ERR");
        }
    }

    function assertNotDetached(range) {
        if (!range.startContainer) {
            throw new DOMException("INVALID_STATE_ERR");
        }
    }

    function assertValidNodeType(node, invalidTypes) {
        if (!arrayContains(invalidTypes, node.nodeType)) {
            throw new RangeException("INVALID_NODE_TYPE_ERR");
        }
    }

    function assertValidOffset(node, offset) {
        if (offset < 0 || offset > (isCharacterDataNode(node) ? node.length : node.childNodes.length)) {
            throw new DOMException("INDEX_SIZE_ERR");
        }
    }

    function assertSameDocumentOrFragment(node1, node2) {
        if (getDocumentOrFragmentContainer(node1, true) !== getDocumentOrFragmentContainer(node2, true)) {
            throw new DOMException("WRONG_DOCUMENT_ERR");
        }
    }

    function assertNodeNotReadOnly(node) {
        if (getReadonlyAncestor(node, true)) {
            throw new DOMException("NO_MODIFICATION_ALLOWED_ERR");
        }
    }

    function assertNode(node, codeName) {
        if (!node) {
            throw new DOMException(codeName);
        }
    }

    function isOrphan(node) {
        return (crashyTextNodes && dom.isBrokenNode(node)) ||
            !arrayContains(rootContainerNodeTypes, node.nodeType) && !getDocumentOrFragmentContainer(node, true);
    }

    function isValidOffset(node, offset) {
        return offset <= (isCharacterDataNode(node) ? node.length : node.childNodes.length);
    }

    function isRangeValid(range) {
        return (!!range.startContainer && !!range.endContainer
                && !isOrphan(range.startContainer)
                && !isOrphan(range.endContainer)
                && isValidOffset(range.startContainer, range.startOffset)
                && isValidOffset(range.endContainer, range.endOffset));
    }

    function assertRangeValid(range) {
        assertNotDetached(range);
        if (!isRangeValid(range)) {
            throw new Error("Range error: Range is no longer valid after DOM mutation (" + range.inspect() + ")");
        }
    }

    /*----------------------------------------------------------------------------------------------------------------*/

    // Test the browser's innerHTML support to decide how to implement createContextualFragment
    var styleEl = document.createElement("style");
    var htmlParsingConforms = false;
    try {
        styleEl.innerHTML = "<b>x</b>";
        htmlParsingConforms = (styleEl.firstChild.nodeType == 3); // Opera incorrectly creates an element node
    } catch (e) {
        // IE 6 and 7 throw
    }

    api.features.htmlParsingConforms = htmlParsingConforms;

    var createContextualFragment = htmlParsingConforms ?

        // Implementation as per HTML parsing spec, trusting in the browser's implementation of innerHTML. See
        // discussion and base code for this implementation at issue 67.
        // Spec: http://html5.org/specs/dom-parsing.html#extensions-to-the-range-interface
        // Thanks to Aleks Williams.
        function(fragmentStr) {
            // "Let node the context object's start's node."
            var node = this.startContainer;
            var doc = getDocument(node);

            // "If the context object's start's node is null, raise an INVALID_STATE_ERR
            // exception and abort these steps."
            if (!node) {
                throw new DOMException("INVALID_STATE_ERR");
            }

            // "Let element be as follows, depending on node's interface:"
            // Document, Document Fragment: null
            var el = null;

            // "Element: node"
            if (node.nodeType == 1) {
                el = node;

            // "Text, Comment: node's parentElement"
            } else if (isCharacterDataNode(node)) {
                el = dom.parentElement(node);
            }

            // "If either element is null or element's ownerDocument is an HTML document
            // and element's local name is "html" and element's namespace is the HTML
            // namespace"
            if (el === null || (
                el.nodeName == "HTML"
                && dom.isHtmlNamespace(getDocument(el).documentElement)
                && dom.isHtmlNamespace(el)
            )) {

            // "let element be a new Element with "body" as its local name and the HTML
            // namespace as its namespace.""
                el = doc.createElement("body");
            } else {
                el = el.cloneNode(false);
            }

            // "If the node's document is an HTML document: Invoke the HTML fragment parsing algorithm."
            // "If the node's document is an XML document: Invoke the XML fragment parsing algorithm."
            // "In either case, the algorithm must be invoked with fragment as the input
            // and element as the context element."
            el.innerHTML = fragmentStr;

            // "If this raises an exception, then abort these steps. Otherwise, let new
            // children be the nodes returned."

            // "Let fragment be a new DocumentFragment."
            // "Append all new children to fragment."
            // "Return fragment."
            return dom.fragmentFromNodeChildren(el);
        } :

        // In this case, innerHTML cannot be trusted, so fall back to a simpler, non-conformant implementation that
        // previous versions of Rangy used (with the exception of using a body element rather than a div)
        function(fragmentStr) {
            assertNotDetached(this);
            var doc = getRangeDocument(this);
            var el = doc.createElement("body");
            el.innerHTML = fragmentStr;

            return dom.fragmentFromNodeChildren(el);
        };

    function splitRangeBoundaries(range, positionsToPreserve) {
        assertRangeValid(range);

        var sc = range.startContainer, so = range.startOffset, ec = range.endContainer, eo = range.endOffset;
        var startEndSame = (sc === ec);

        if (isCharacterDataNode(ec) && eo > 0 && eo < ec.length) {
            splitDataNode(ec, eo, positionsToPreserve);
        }

        if (isCharacterDataNode(sc) && so > 0 && so < sc.length) {
            sc = splitDataNode(sc, so, positionsToPreserve);
            if (startEndSame) {
                eo -= so;
                ec = sc;
            } else if (ec == sc.parentNode && eo >= getNodeIndex(sc)) {
                eo++;
            }
            so = 0;
        }
        range.setStartAndEnd(sc, so, ec, eo);
    }

    /*----------------------------------------------------------------------------------------------------------------*/

    var rangeProperties = ["startContainer", "startOffset", "endContainer", "endOffset", "collapsed",
        "commonAncestorContainer"];

    var s2s = 0, s2e = 1, e2e = 2, e2s = 3;
    var n_b = 0, n_a = 1, n_b_a = 2, n_i = 3;

    util.extend(api.rangePrototype, {
        compareBoundaryPoints: function(how, range) {
            assertRangeValid(this);
            assertSameDocumentOrFragment(this.startContainer, range.startContainer);

            var nodeA, offsetA, nodeB, offsetB;
            var prefixA = (how == e2s || how == s2s) ? "start" : "end";
            var prefixB = (how == s2e || how == s2s) ? "start" : "end";
            nodeA = this[prefixA + "Container"];
            offsetA = this[prefixA + "Offset"];
            nodeB = range[prefixB + "Container"];
            offsetB = range[prefixB + "Offset"];
            return comparePoints(nodeA, offsetA, nodeB, offsetB);
        },

        insertNode: function(node) {
            assertRangeValid(this);
            assertValidNodeType(node, insertableNodeTypes);
            assertNodeNotReadOnly(this.startContainer);

            if (isOrIsAncestorOf(node, this.startContainer)) {
                throw new DOMException("HIERARCHY_REQUEST_ERR");
            }

            // No check for whether the container of the start of the Range is of a type that does not allow
            // children of the type of node: the browser's DOM implementation should do this for us when we attempt
            // to add the node

            var firstNodeInserted = insertNodeAtPosition(node, this.startContainer, this.startOffset);
            this.setStartBefore(firstNodeInserted);
        },

        cloneContents: function() {
            assertRangeValid(this);

            var clone, frag;
            if (this.collapsed) {
                return getRangeDocument(this).createDocumentFragment();
            } else {
                if (this.startContainer === this.endContainer && isCharacterDataNode(this.startContainer)) {
                    clone = this.startContainer.cloneNode(true);
                    clone.data = clone.data.slice(this.startOffset, this.endOffset);
                    frag = getRangeDocument(this).createDocumentFragment();
                    frag.appendChild(clone);
                    return frag;
                } else {
                    var iterator = new RangeIterator(this, true);
                    clone = cloneSubtree(iterator);
                    iterator.detach();
                }
                return clone;
            }
        },

        canSurroundContents: function() {
            assertRangeValid(this);
            assertNodeNotReadOnly(this.startContainer);
            assertNodeNotReadOnly(this.endContainer);

            // Check if the contents can be surrounded. Specifically, this means whether the range partially selects
            // no non-text nodes.
            var iterator = new RangeIterator(this, true);
            var boundariesInvalid = (iterator._first && (isNonTextPartiallySelected(iterator._first, this)) ||
                    (iterator._last && isNonTextPartiallySelected(iterator._last, this)));
            iterator.detach();
            return !boundariesInvalid;
        },

        surroundContents: function(node) {
            assertValidNodeType(node, surroundNodeTypes);

            if (!this.canSurroundContents()) {
                throw new RangeException("BAD_BOUNDARYPOINTS_ERR");
            }

            // Extract the contents
            var content = this.extractContents();

            // Clear the children of the node
            if (node.hasChildNodes()) {
                while (node.lastChild) {
                    node.removeChild(node.lastChild);
                }
            }

            // Insert the new node and add the extracted contents
            insertNodeAtPosition(node, this.startContainer, this.startOffset);
            node.appendChild(content);

            this.selectNode(node);
        },

        cloneRange: function() {
            assertRangeValid(this);
            var range = new Range(getRangeDocument(this));
            var i = rangeProperties.length, prop;
            while (i--) {
                prop = rangeProperties[i];
                range[prop] = this[prop];
            }
            return range;
        },

        toString: function() {
            assertRangeValid(this);
            var sc = this.startContainer;
            if (sc === this.endContainer && isCharacterDataNode(sc)) {
                return (sc.nodeType == 3 || sc.nodeType == 4) ? sc.data.slice(this.startOffset, this.endOffset) : "";
            } else {
                var textParts = [], iterator = new RangeIterator(this, true);
                iterateSubtree(iterator, function(node) {
                    // Accept only text or CDATA nodes, not comments
                    if (node.nodeType == 3 || node.nodeType == 4) {
                        textParts.push(node.data);
                    }
                });
                iterator.detach();
                return textParts.join("");
            }
        },

        // The methods below are all non-standard. The following batch were introduced by Mozilla but have since
        // been removed from Mozilla.

        compareNode: function(node) {
            assertRangeValid(this);

            var parent = node.parentNode;
            var nodeIndex = getNodeIndex(node);

            if (!parent) {
                throw new DOMException("NOT_FOUND_ERR");
            }

            var startComparison = this.comparePoint(parent, nodeIndex),
                endComparison = this.comparePoint(parent, nodeIndex + 1);

            if (startComparison < 0) { // Node starts before
                return (endComparison > 0) ? n_b_a : n_b;
            } else {
                return (endComparison > 0) ? n_a : n_i;
            }
        },

        comparePoint: function(node, offset) {
            assertRangeValid(this);
            assertNode(node, "HIERARCHY_REQUEST_ERR");
            assertSameDocumentOrFragment(node, this.startContainer);

            if (comparePoints(node, offset, this.startContainer, this.startOffset) < 0) {
                return -1;
            } else if (comparePoints(node, offset, this.endContainer, this.endOffset) > 0) {
                return 1;
            }
            return 0;
        },

        createContextualFragment: createContextualFragment,

        toHtml: function() {
            assertRangeValid(this);
            var container = this.commonAncestorContainer.parentNode.cloneNode(false);
            container.appendChild(this.cloneContents());
            return container.innerHTML;
        },

        // touchingIsIntersecting determines whether this method considers a node that borders a range intersects
        // with it (as in WebKit) or not (as in Gecko pre-1.9, and the default)
        intersectsNode: function(node, touchingIsIntersecting) {
            assertRangeValid(this);
            assertNode(node, "NOT_FOUND_ERR");
            if (getDocument(node) !== getRangeDocument(this)) {
                return false;
            }

            var parent = node.parentNode, offset = getNodeIndex(node);
            assertNode(parent, "NOT_FOUND_ERR");

            var startComparison = comparePoints(parent, offset, this.endContainer, this.endOffset),
                endComparison = comparePoints(parent, offset + 1, this.startContainer, this.startOffset);

            return touchingIsIntersecting ? startComparison <= 0 && endComparison >= 0 : startComparison < 0 && endComparison > 0;
        },

        isPointInRange: function(node, offset) {
            assertRangeValid(this);
            assertNode(node, "HIERARCHY_REQUEST_ERR");
            assertSameDocumentOrFragment(node, this.startContainer);

            return (comparePoints(node, offset, this.startContainer, this.startOffset) >= 0) &&
                   (comparePoints(node, offset, this.endContainer, this.endOffset) <= 0);
        },

        // The methods below are non-standard and invented by me.

        // Sharing a boundary start-to-end or end-to-start does not count as intersection.
        intersectsRange: function(range) {
            return rangesIntersect(this, range, false);
        },

        // Sharing a boundary start-to-end or end-to-start does count as intersection.
        intersectsOrTouchesRange: function(range) {
            return rangesIntersect(this, range, true);
        },

        intersection: function(range) {
            if (this.intersectsRange(range)) {
                var startComparison = comparePoints(this.startContainer, this.startOffset, range.startContainer, range.startOffset),
                    endComparison = comparePoints(this.endContainer, this.endOffset, range.endContainer, range.endOffset);

                var intersectionRange = this.cloneRange();
                if (startComparison == -1) {
                    intersectionRange.setStart(range.startContainer, range.startOffset);
                }
                if (endComparison == 1) {
                    intersectionRange.setEnd(range.endContainer, range.endOffset);
                }
                return intersectionRange;
            }
            return null;
        },

        union: function(range) {
            if (this.intersectsOrTouchesRange(range)) {
                var unionRange = this.cloneRange();
                if (comparePoints(range.startContainer, range.startOffset, this.startContainer, this.startOffset) == -1) {
                    unionRange.setStart(range.startContainer, range.startOffset);
                }
                if (comparePoints(range.endContainer, range.endOffset, this.endContainer, this.endOffset) == 1) {
                    unionRange.setEnd(range.endContainer, range.endOffset);
                }
                return unionRange;
            } else {
                throw new RangeException("Ranges do not intersect");
            }
        },

        containsNode: function(node, allowPartial) {
            if (allowPartial) {
                return this.intersectsNode(node, false);
            } else {
                return this.compareNode(node) == n_i;
            }
        },

        containsNodeContents: function(node) {
            return this.comparePoint(node, 0) >= 0 && this.comparePoint(node, getNodeLength(node)) <= 0;
        },

        containsRange: function(range) {
            var intersection = this.intersection(range);
            return intersection !== null && range.equals(intersection);
        },

        containsNodeText: function(node) {
            var nodeRange = this.cloneRange();
            nodeRange.selectNode(node);
            var textNodes = nodeRange.getNodes([3]);
            if (textNodes.length > 0) {
                nodeRange.setStart(textNodes[0], 0);
                var lastTextNode = textNodes.pop();
                nodeRange.setEnd(lastTextNode, lastTextNode.length);
                var contains = this.containsRange(nodeRange);
                nodeRange.detach();
                return contains;
            } else {
                return this.containsNodeContents(node);
            }
        },

        getNodes: function(nodeTypes, filter) {
            assertRangeValid(this);
            return getNodesInRange(this, nodeTypes, filter);
        },

        getDocument: function() {
            return getRangeDocument(this);
        },

        collapseBefore: function(node) {
            assertNotDetached(this);

            this.setEndBefore(node);
            this.collapse(false);
        },

        collapseAfter: function(node) {
            assertNotDetached(this);

            this.setStartAfter(node);
            this.collapse(true);
        },
        
        getBookmark: function(containerNode) {
            var doc = getRangeDocument(this);
            var preSelectionRange = api.createRange(doc);
            containerNode = containerNode || dom.getBody(doc);
            preSelectionRange.selectNodeContents(containerNode);
            var range = this.intersection(preSelectionRange);
            var start = 0, end = 0;
            if (range) {
                preSelectionRange.setEnd(range.startContainer, range.startOffset);
                start = preSelectionRange.toString().length;
                end = start + range.toString().length;
                preSelectionRange.detach();
            }

            return {
                start: start,
                end: end,
                containerNode: containerNode
            };
        },
        
        moveToBookmark: function(bookmark) {
            var containerNode = bookmark.containerNode;
            var charIndex = 0;
            this.setStart(containerNode, 0);
            this.collapse(true);
            var nodeStack = [containerNode], node, foundStart = false, stop = false;
            var nextCharIndex, i, childNodes;

            while (!stop && (node = nodeStack.pop())) {
                if (node.nodeType == 3) {
                    nextCharIndex = charIndex + node.length;
                    if (!foundStart && bookmark.start >= charIndex && bookmark.start <= nextCharIndex) {
                        this.setStart(node, bookmark.start - charIndex);
                        foundStart = true;
                    }
                    if (foundStart && bookmark.end >= charIndex && bookmark.end <= nextCharIndex) {
                        this.setEnd(node, bookmark.end - charIndex);
                        stop = true;
                    }
                    charIndex = nextCharIndex;
                } else {
                    childNodes = node.childNodes;
                    i = childNodes.length;
                    while (i--) {
                        nodeStack.push(childNodes[i]);
                    }
                }
            }
        },

        getName: function() {
            return "DomRange";
        },

        equals: function(range) {
            return Range.rangesEqual(this, range);
        },

        isValid: function() {
            return isRangeValid(this);
        },
        
        inspect: function() {
            return inspect(this);
        }
    });

    function copyComparisonConstantsToObject(obj) {
        obj.START_TO_START = s2s;
        obj.START_TO_END = s2e;
        obj.END_TO_END = e2e;
        obj.END_TO_START = e2s;

        obj.NODE_BEFORE = n_b;
        obj.NODE_AFTER = n_a;
        obj.NODE_BEFORE_AND_AFTER = n_b_a;
        obj.NODE_INSIDE = n_i;
    }

    function copyComparisonConstants(constructor) {
        copyComparisonConstantsToObject(constructor);
        copyComparisonConstantsToObject(constructor.prototype);
    }

    function createRangeContentRemover(remover, boundaryUpdater) {
        return function() {
            assertRangeValid(this);

            var sc = this.startContainer, so = this.startOffset, root = this.commonAncestorContainer;

            var iterator = new RangeIterator(this, true);

            // Work out where to position the range after content removal
            var node, boundary;
            if (sc !== root) {
                node = getClosestAncestorIn(sc, root, true);
                boundary = getBoundaryAfterNode(node);
                sc = boundary.node;
                so = boundary.offset;
            }

            // Check none of the range is read-only
            iterateSubtree(iterator, assertNodeNotReadOnly);

            iterator.reset();

            // Remove the content
            var returnValue = remover(iterator);
            iterator.detach();

            // Move to the new position
            boundaryUpdater(this, sc, so, sc, so);

            return returnValue;
        };
    }

    function createPrototypeRange(constructor, boundaryUpdater, detacher) {
        function createBeforeAfterNodeSetter(isBefore, isStart) {
            return function(node) {
                assertNotDetached(this);
                assertValidNodeType(node, beforeAfterNodeTypes);
                assertValidNodeType(getRootContainer(node), rootContainerNodeTypes);

                var boundary = (isBefore ? getBoundaryBeforeNode : getBoundaryAfterNode)(node);
                (isStart ? setRangeStart : setRangeEnd)(this, boundary.node, boundary.offset);
            };
        }

        function setRangeStart(range, node, offset) {
            var ec = range.endContainer, eo = range.endOffset;
            if (node !== range.startContainer || offset !== range.startOffset) {
                // Check the root containers of the range and the new boundary, and also check whether the new boundary
                // is after the current end. In either case, collapse the range to the new position
                if (getRootContainer(node) != getRootContainer(ec) || comparePoints(node, offset, ec, eo) == 1) {
                    ec = node;
                    eo = offset;
                }
                boundaryUpdater(range, node, offset, ec, eo);
            }
        }

        function setRangeEnd(range, node, offset) {
            var sc = range.startContainer, so = range.startOffset;
            if (node !== range.endContainer || offset !== range.endOffset) {
                // Check the root containers of the range and the new boundary, and also check whether the new boundary
                // is after the current end. In either case, collapse the range to the new position
                if (getRootContainer(node) != getRootContainer(sc) || comparePoints(node, offset, sc, so) == -1) {
                    sc = node;
                    so = offset;
                }
                boundaryUpdater(range, sc, so, node, offset);
            }
        }

        // Set up inheritance
        var F = function() {};
        F.prototype = api.rangePrototype;
        constructor.prototype = new F();

        util.extend(constructor.prototype, {
            setStart: function(node, offset) {
                assertNotDetached(this);
                assertNoDocTypeNotationEntityAncestor(node, true);
                assertValidOffset(node, offset);

                setRangeStart(this, node, offset);
            },

            setEnd: function(node, offset) {
                assertNotDetached(this);
                assertNoDocTypeNotationEntityAncestor(node, true);
                assertValidOffset(node, offset);

                setRangeEnd(this, node, offset);
            },

            /**
             * Convenience method to set a range's start and end boundaries. Overloaded as follows:
             * - Two parameters (node, offset) creates a collapsed range at that position
             * - Three parameters (node, startOffset, endOffset) creates a range contained with node starting at
             *   startOffset and ending at endOffset
             * - Four parameters (startNode, startOffset, endNode, endOffset) creates a range starting at startOffset in
             *   startNode and ending at endOffset in endNode
             */
            setStartAndEnd: function() {
                assertNotDetached(this);

                var args = arguments;
                var sc = args[0], so = args[1], ec = sc, eo = so;

                switch (args.length) {
                    case 3:
                        eo = args[2];
                        break;
                    case 4:
                        ec = args[2];
                        eo = args[3];
                        break;
                }

                boundaryUpdater(this, sc, so, ec, eo);
            },
            
            setBoundary: function(node, offset, isStart) {
                this["set" + (isStart ? "Start" : "End")](node, offset);
            },

            setStartBefore: createBeforeAfterNodeSetter(true, true),
            setStartAfter: createBeforeAfterNodeSetter(false, true),
            setEndBefore: createBeforeAfterNodeSetter(true, false),
            setEndAfter: createBeforeAfterNodeSetter(false, false),

            collapse: function(isStart) {
                assertRangeValid(this);
                if (isStart) {
                    boundaryUpdater(this, this.startContainer, this.startOffset, this.startContainer, this.startOffset);
                } else {
                    boundaryUpdater(this, this.endContainer, this.endOffset, this.endContainer, this.endOffset);
                }
            },

            selectNodeContents: function(node) {
                assertNotDetached(this);
                assertNoDocTypeNotationEntityAncestor(node, true);

                boundaryUpdater(this, node, 0, node, getNodeLength(node));
            },

            selectNode: function(node) {
                assertNotDetached(this);
                assertNoDocTypeNotationEntityAncestor(node, false);
                assertValidNodeType(node, beforeAfterNodeTypes);

                var start = getBoundaryBeforeNode(node), end = getBoundaryAfterNode(node);
                boundaryUpdater(this, start.node, start.offset, end.node, end.offset);
            },

            extractContents: createRangeContentRemover(extractSubtree, boundaryUpdater),

            deleteContents: createRangeContentRemover(deleteSubtree, boundaryUpdater),

            canSurroundContents: function() {
                assertRangeValid(this);
                assertNodeNotReadOnly(this.startContainer);
                assertNodeNotReadOnly(this.endContainer);

                // Check if the contents can be surrounded. Specifically, this means whether the range partially selects
                // no non-text nodes.
                var iterator = new RangeIterator(this, true);
                var boundariesInvalid = (iterator._first && (isNonTextPartiallySelected(iterator._first, this)) ||
                        (iterator._last && isNonTextPartiallySelected(iterator._last, this)));
                iterator.detach();
                return !boundariesInvalid;
            },

            detach: function() {
                detacher(this);
            },

            splitBoundaries: function() {
                splitRangeBoundaries(this);
            },

            splitBoundariesPreservingPositions: function(positionsToPreserve) {
                splitRangeBoundaries(this, positionsToPreserve);
            },

            normalizeBoundaries: function() {
                assertRangeValid(this);

                var sc = this.startContainer, so = this.startOffset, ec = this.endContainer, eo = this.endOffset;

                var mergeForward = function(node) {
                    var sibling = node.nextSibling;
                    if (sibling && sibling.nodeType == node.nodeType) {
                        ec = node;
                        eo = node.length;
                        node.appendData(sibling.data);
                        sibling.parentNode.removeChild(sibling);
                    }
                };

                var mergeBackward = function(node) {
                    var sibling = node.previousSibling;
                    if (sibling && sibling.nodeType == node.nodeType) {
                        sc = node;
                        var nodeLength = node.length;
                        so = sibling.length;
                        node.insertData(0, sibling.data);
                        sibling.parentNode.removeChild(sibling);
                        if (sc == ec) {
                            eo += so;
                            ec = sc;
                        } else if (ec == node.parentNode) {
                            var nodeIndex = getNodeIndex(node);
                            if (eo == nodeIndex) {
                                ec = node;
                                eo = nodeLength;
                            } else if (eo > nodeIndex) {
                                eo--;
                            }
                        }
                    }
                };

                var normalizeStart = true;

                if (isCharacterDataNode(ec)) {
                    if (ec.length == eo) {
                        mergeForward(ec);
                    }
                } else {
                    if (eo > 0) {
                        var endNode = ec.childNodes[eo - 1];
                        if (endNode && isCharacterDataNode(endNode)) {
                            mergeForward(endNode);
                        }
                    }
                    normalizeStart = !this.collapsed;
                }

                if (normalizeStart) {
                    if (isCharacterDataNode(sc)) {
                        if (so == 0) {
                            mergeBackward(sc);
                        }
                    } else {
                        if (so < sc.childNodes.length) {
                            var startNode = sc.childNodes[so];
                            if (startNode && isCharacterDataNode(startNode)) {
                                mergeBackward(startNode);
                            }
                        }
                    }
                } else {
                    sc = ec;
                    so = eo;
                }

                boundaryUpdater(this, sc, so, ec, eo);
            },

            collapseToPoint: function(node, offset) {
                assertNotDetached(this);
                assertNoDocTypeNotationEntityAncestor(node, true);
                assertValidOffset(node, offset);
                this.setStartAndEnd(node, offset);
            }
        });

        copyComparisonConstants(constructor);
    }

    /*----------------------------------------------------------------------------------------------------------------*/

    // Updates commonAncestorContainer and collapsed after boundary change
    function updateCollapsedAndCommonAncestor(range) {
        range.collapsed = (range.startContainer === range.endContainer && range.startOffset === range.endOffset);
        range.commonAncestorContainer = range.collapsed ?
            range.startContainer : dom.getCommonAncestor(range.startContainer, range.endContainer);
    }

    function updateBoundaries(range, startContainer, startOffset, endContainer, endOffset) {
        range.startContainer = startContainer;
        range.startOffset = startOffset;
        range.endContainer = endContainer;
        range.endOffset = endOffset;
        range.document = dom.getDocument(startContainer);

        updateCollapsedAndCommonAncestor(range);
    }

    function detach(range) {
        assertNotDetached(range);
        range.startContainer = range.startOffset = range.endContainer = range.endOffset = range.document = null;
        range.collapsed = range.commonAncestorContainer = null;
    }

    function Range(doc) {
        this.startContainer = doc;
        this.startOffset = 0;
        this.endContainer = doc;
        this.endOffset = 0;
        this.document = doc;
        updateCollapsedAndCommonAncestor(this);
    }

    createPrototypeRange(Range, updateBoundaries, detach);

    util.extend(Range, {
        rangeProperties: rangeProperties,
        RangeIterator: RangeIterator,
        copyComparisonConstants: copyComparisonConstants,
        createPrototypeRange: createPrototypeRange,
        inspect: inspect,
        getRangeDocument: getRangeDocument,
        rangesEqual: function(r1, r2) {
            return r1.startContainer === r2.startContainer &&
                r1.startOffset === r2.startOffset &&
                r1.endContainer === r2.endContainer &&
                r1.endOffset === r2.endOffset;
        }
    });

    api.DomRange = Range;
    api.RangeException = RangeException;
});
rangy.createCoreModule("WrappedRange", ["DomRange"], function(api, module) {
    var WrappedRange, WrappedTextRange;
    var dom = api.dom;
    var util = api.util;
    var DomPosition = dom.DomPosition;
    var DomRange = api.DomRange;
    var getBody = dom.getBody;
    var getContentDocument = dom.getContentDocument;
    var isCharacterDataNode = dom.isCharacterDataNode;


    /*----------------------------------------------------------------------------------------------------------------*/

    if (api.features.implementsDomRange) {
        // This is a wrapper around the browser's native DOM Range. It has two aims:
        // - Provide workarounds for specific browser bugs
        // - provide convenient extensions, which are inherited from Rangy's DomRange

        (function() {
            var rangeProto;
            var rangeProperties = DomRange.rangeProperties;

            function updateRangeProperties(range) {
                var i = rangeProperties.length, prop;
                while (i--) {
                    prop = rangeProperties[i];
                    range[prop] = range.nativeRange[prop];
                }
                // Fix for broken collapsed property in IE 9.
                range.collapsed = (range.startContainer === range.endContainer && range.startOffset === range.endOffset);
            }

            function updateNativeRange(range, startContainer, startOffset, endContainer, endOffset) {
                var startMoved = (range.startContainer !== startContainer || range.startOffset != startOffset);
                var endMoved = (range.endContainer !== endContainer || range.endOffset != endOffset);
                var nativeRangeDifferent = !range.equals(range.nativeRange);

                // Always set both boundaries for the benefit of IE9 (see issue 35)
                if (startMoved || endMoved || nativeRangeDifferent) {
                    range.setEnd(endContainer, endOffset);
                    range.setStart(startContainer, startOffset);
                }
            }

            function detach(range) {
                range.nativeRange.detach();
                range.detached = true;
                var i = rangeProperties.length;
                while (i--) {
                    range[ rangeProperties[i] ] = null;
                }
            }

            var createBeforeAfterNodeSetter;

            WrappedRange = function(range) {
                if (!range) {
                    throw module.createError("WrappedRange: Range must be specified");
                }
                this.nativeRange = range;
                updateRangeProperties(this);
            };

            DomRange.createPrototypeRange(WrappedRange, updateNativeRange, detach);

            rangeProto = WrappedRange.prototype;

            rangeProto.selectNode = function(node) {
                this.nativeRange.selectNode(node);
                updateRangeProperties(this);
            };

            rangeProto.cloneContents = function() {
                return this.nativeRange.cloneContents();
            };

            // Due to a long-standing Firefox bug that I have not been able to find a reliable way to detect,
            // insertNode() is never delegated to the native range.

            rangeProto.surroundContents = function(node) {
                this.nativeRange.surroundContents(node);
                updateRangeProperties(this);
            };

            rangeProto.collapse = function(isStart) {
                this.nativeRange.collapse(isStart);
                updateRangeProperties(this);
            };

            rangeProto.cloneRange = function() {
                return new WrappedRange(this.nativeRange.cloneRange());
            };

            rangeProto.refresh = function() {
                updateRangeProperties(this);
            };

            rangeProto.toString = function() {
                return this.nativeRange.toString();
            };

            // Create test range and node for feature detection

            var testTextNode = document.createTextNode("test");
            getBody(document).appendChild(testTextNode);
            var range = document.createRange();

            /*--------------------------------------------------------------------------------------------------------*/

            // Test for Firefox 2 bug that prevents moving the start of a Range to a point after its current end and
            // correct for it

            range.setStart(testTextNode, 0);
            range.setEnd(testTextNode, 0);

            try {
                range.setStart(testTextNode, 1);

                rangeProto.setStart = function(node, offset) {
                    this.nativeRange.setStart(node, offset);
                    updateRangeProperties(this);
                };

                rangeProto.setEnd = function(node, offset) {
                    this.nativeRange.setEnd(node, offset);
                    updateRangeProperties(this);
                };

                createBeforeAfterNodeSetter = function(name) {
                    return function(node) {
                        this.nativeRange[name](node);
                        updateRangeProperties(this);
                    };
                };

            } catch(ex) {

                rangeProto.setStart = function(node, offset) {
                    try {
                        this.nativeRange.setStart(node, offset);
                    } catch (ex) {
                        this.nativeRange.setEnd(node, offset);
                        this.nativeRange.setStart(node, offset);
                    }
                    updateRangeProperties(this);
                };

                rangeProto.setEnd = function(node, offset) {
                    try {
                        this.nativeRange.setEnd(node, offset);
                    } catch (ex) {
                        this.nativeRange.setStart(node, offset);
                        this.nativeRange.setEnd(node, offset);
                    }
                    updateRangeProperties(this);
                };

                createBeforeAfterNodeSetter = function(name, oppositeName) {
                    return function(node) {
                        try {
                            this.nativeRange[name](node);
                        } catch (ex) {
                            this.nativeRange[oppositeName](node);
                            this.nativeRange[name](node);
                        }
                        updateRangeProperties(this);
                    };
                };
            }

            rangeProto.setStartBefore = createBeforeAfterNodeSetter("setStartBefore", "setEndBefore");
            rangeProto.setStartAfter = createBeforeAfterNodeSetter("setStartAfter", "setEndAfter");
            rangeProto.setEndBefore = createBeforeAfterNodeSetter("setEndBefore", "setStartBefore");
            rangeProto.setEndAfter = createBeforeAfterNodeSetter("setEndAfter", "setStartAfter");

            /*--------------------------------------------------------------------------------------------------------*/

            // Always use DOM4-compliant selectNodeContents implementation: it's simpler and less code than testing
            // whether the native implementation can be trusted
            rangeProto.selectNodeContents = function(node) {
                this.setStartAndEnd(node, 0, dom.getNodeLength(node));
            };

            /*--------------------------------------------------------------------------------------------------------*/

            // Test for and correct WebKit bug that has the behaviour of compareBoundaryPoints round the wrong way for
            // constants START_TO_END and END_TO_START: https://bugs.webkit.org/show_bug.cgi?id=20738

            range.selectNodeContents(testTextNode);
            range.setEnd(testTextNode, 3);

            var range2 = document.createRange();
            range2.selectNodeContents(testTextNode);
            range2.setEnd(testTextNode, 4);
            range2.setStart(testTextNode, 2);

            if (range.compareBoundaryPoints(range.START_TO_END, range2) == -1 &&
                    range.compareBoundaryPoints(range.END_TO_START, range2) == 1) {
                // This is the wrong way round, so correct for it

                rangeProto.compareBoundaryPoints = function(type, range) {
                    range = range.nativeRange || range;
                    if (type == range.START_TO_END) {
                        type = range.END_TO_START;
                    } else if (type == range.END_TO_START) {
                        type = range.START_TO_END;
                    }
                    return this.nativeRange.compareBoundaryPoints(type, range);
                };
            } else {
                rangeProto.compareBoundaryPoints = function(type, range) {
                    return this.nativeRange.compareBoundaryPoints(type, range.nativeRange || range);
                };
            }

            /*--------------------------------------------------------------------------------------------------------*/

            // Test for IE 9 deleteContents() and extractContents() bug and correct it. See issue 107.

            var el = document.createElement("div");
            el.innerHTML = "123";
            var textNode = el.firstChild;
            var body = getBody(document);
            body.appendChild(el);

            range.setStart(textNode, 1);
            range.setEnd(textNode, 2);
            range.deleteContents();

            if (textNode.data == "13") {
                // Behaviour is correct per DOM4 Range so wrap the browser's implementation of deleteContents() and
                // extractContents()
                rangeProto.deleteContents = function() {
                    this.nativeRange.deleteContents();
                    updateRangeProperties(this);
                };

                rangeProto.extractContents = function() {
                    var frag = this.nativeRange.extractContents();
                    updateRangeProperties(this);
                    return frag;
                };
            } else {
            }

            body.removeChild(el);
            body = null;

            /*--------------------------------------------------------------------------------------------------------*/

            // Test for existence of createContextualFragment and delegate to it if it exists
            if (util.isHostMethod(range, "createContextualFragment")) {
                rangeProto.createContextualFragment = function(fragmentStr) {
                    return this.nativeRange.createContextualFragment(fragmentStr);
                };
            }

            /*--------------------------------------------------------------------------------------------------------*/

            // Clean up
            getBody(document).removeChild(testTextNode);
            range.detach();
            range2.detach();

            rangeProto.getName = function() {
                return "WrappedRange";
            };

            api.WrappedRange = WrappedRange;

            api.createNativeRange = function(doc) {
                doc = getContentDocument(doc, module, "createNativeRange");
                return doc.createRange();
            };
        })();
    }
    
    if (api.features.implementsTextRange) {
        /*
        This is a workaround for a bug where IE returns the wrong container element from the TextRange's parentElement()
        method. For example, in the following (where pipes denote the selection boundaries):

        <ul id="ul"><li id="a">| a </li><li id="b"> b |</li></ul>

        var range = document.selection.createRange();
        alert(range.parentElement().id); // Should alert "ul" but alerts "b"

        This method returns the common ancestor node of the following:
        - the parentElement() of the textRange
        - the parentElement() of the textRange after calling collapse(true)
        - the parentElement() of the textRange after calling collapse(false)
        */
        var getTextRangeContainerElement = function(textRange) {
            var parentEl = textRange.parentElement();
            var range = textRange.duplicate();
            range.collapse(true);
            var startEl = range.parentElement();
            range = textRange.duplicate();
            range.collapse(false);
            var endEl = range.parentElement();
            var startEndContainer = (startEl == endEl) ? startEl : dom.getCommonAncestor(startEl, endEl);

            return startEndContainer == parentEl ? startEndContainer : dom.getCommonAncestor(parentEl, startEndContainer);
        };

        var textRangeIsCollapsed = function(textRange) {
            return textRange.compareEndPoints("StartToEnd", textRange) == 0;
        };

        // Gets the boundary of a TextRange expressed as a node and an offset within that node. This function started out as
        // an improved version of code found in Tim Cameron Ryan's IERange (http://code.google.com/p/ierange/) but has
        // grown, fixing problems with line breaks in preformatted text, adding workaround for IE TextRange bugs, handling
        // for inputs and images, plus optimizations.
        var getTextRangeBoundaryPosition = function(textRange, wholeRangeContainerElement, isStart, isCollapsed, startInfo) {
            var workingRange = textRange.duplicate();
            workingRange.collapse(isStart);
            var containerElement = workingRange.parentElement();

            // Sometimes collapsing a TextRange that's at the start of a text node can move it into the previous node, so
            // check for that
            if (!dom.isOrIsAncestorOf(wholeRangeContainerElement, containerElement)) {
                containerElement = wholeRangeContainerElement;
            }


            // Deal with nodes that cannot "contain rich HTML markup". In practice, this means form inputs, images and
            // similar. See http://msdn.microsoft.com/en-us/library/aa703950%28VS.85%29.aspx
            if (!containerElement.canHaveHTML) {
                var pos = new DomPosition(containerElement.parentNode, dom.getNodeIndex(containerElement));
                return {
                    boundaryPosition: pos,
                    nodeInfo: {
                        nodeIndex: pos.offset,
                        containerElement: pos.node
                    }
                };
            }

            var workingNode = dom.getDocument(containerElement).createElement("span");

            // Workaround for HTML5 Shiv's insane violation of document.createElement(). See Rangy issue 104 and HTML5
            // Shiv issue 64: https://github.com/aFarkas/html5shiv/issues/64
            if (workingNode.parentNode) {
                workingNode.parentNode.removeChild(workingNode);
            }

            var comparison, workingComparisonType = isStart ? "StartToStart" : "StartToEnd";
            var previousNode, nextNode, boundaryPosition, boundaryNode;
            var start = (startInfo && startInfo.containerElement == containerElement) ? startInfo.nodeIndex : 0;
            var childNodeCount = containerElement.childNodes.length;
            var end = childNodeCount;

            // Check end first. Code within the loop assumes that the endth child node of the container is definitely
            // after the range boundary.
            var nodeIndex = end;

            while (true) {
                if (nodeIndex == childNodeCount) {
                    containerElement.appendChild(workingNode);
                } else {
                    containerElement.insertBefore(workingNode, containerElement.childNodes[nodeIndex]);
                }
                workingRange.moveToElementText(workingNode);
                comparison = workingRange.compareEndPoints(workingComparisonType, textRange);
                if (comparison == 0 || start == end) {
                    break;
                } else if (comparison == -1) {
                    if (end == start + 1) {
                        // We know the endth child node is after the range boundary, so we must be done.
                        break;
                    } else {
                        start = nodeIndex;
                    }
                } else {
                    end = (end == start + 1) ? start : nodeIndex;
                }
                nodeIndex = Math.floor((start + end) / 2);
                containerElement.removeChild(workingNode);
            }


            // We've now reached or gone past the boundary of the text range we're interested in
            // so have identified the node we want
            boundaryNode = workingNode.nextSibling;

            if (comparison == -1 && boundaryNode && isCharacterDataNode(boundaryNode)) {
                // This is a character data node (text, comment, cdata). The working range is collapsed at the start of the
                // node containing the text range's boundary, so we move the end of the working range to the boundary point
                // and measure the length of its text to get the boundary's offset within the node.
                workingRange.setEndPoint(isStart ? "EndToStart" : "EndToEnd", textRange);

                var offset;

                if (/[\r\n]/.test(boundaryNode.data)) {
                    /*
                    For the particular case of a boundary within a text node containing rendered line breaks (within a <pre>
                    element, for example), we need a slightly complicated approach to get the boundary's offset in IE. The
                    facts:
                    
                    - Each line break is represented as \r in the text node's data/nodeValue properties
                    - Each line break is represented as \r\n in the TextRange's 'text' property
                    - The 'text' property of the TextRange does not contain trailing line breaks
                    
                    To get round the problem presented by the final fact above, we can use the fact that TextRange's
                    moveStart() and moveEnd() methods return the actual number of characters moved, which is not necessarily
                    the same as the number of characters it was instructed to move. The simplest approach is to use this to
                    store the characters moved when moving both the start and end of the range to the start of the document
                    body and subtracting the start offset from the end offset (the "move-negative-gazillion" method).
                    However, this is extremely slow when the document is large and the range is near the end of it. Clearly
                    doing the mirror image (i.e. moving the range boundaries to the end of the document) has the same
                    problem.
                    
                    Another approach that works is to use moveStart() to move the start boundary of the range up to the end
                    boundary one character at a time and incrementing a counter with the value returned by the moveStart()
                    call. However, the check for whether the start boundary has reached the end boundary is expensive, so
                    this method is slow (although unlike "move-negative-gazillion" is largely unaffected by the location of
                    the range within the document).
                    
                    The method below is a hybrid of the two methods above. It uses the fact that a string containing the
                    TextRange's 'text' property with each \r\n converted to a single \r character cannot be longer than the
                    text of the TextRange, so the start of the range is moved that length initially and then a character at
                    a time to make up for any trailing line breaks not contained in the 'text' property. This has good
                    performance in most situations compared to the previous two methods.
                    */
                    var tempRange = workingRange.duplicate();
                    var rangeLength = tempRange.text.replace(/\r\n/g, "\r").length;

                    offset = tempRange.moveStart("character", rangeLength);
                    while ( (comparison = tempRange.compareEndPoints("StartToEnd", tempRange)) == -1) {
                        offset++;
                        tempRange.moveStart("character", 1);
                    }
                } else {
                    offset = workingRange.text.length;
                }
                boundaryPosition = new DomPosition(boundaryNode, offset);
            } else {

                // If the boundary immediately follows a character data node and this is the end boundary, we should favour
                // a position within that, and likewise for a start boundary preceding a character data node
                previousNode = (isCollapsed || !isStart) && workingNode.previousSibling;
                nextNode = (isCollapsed || isStart) && workingNode.nextSibling;
                if (nextNode && isCharacterDataNode(nextNode)) {
                    boundaryPosition = new DomPosition(nextNode, 0);
                } else if (previousNode && isCharacterDataNode(previousNode)) {
                    boundaryPosition = new DomPosition(previousNode, previousNode.data.length);
                } else {
                    boundaryPosition = new DomPosition(containerElement, dom.getNodeIndex(workingNode));
                }
            }

            // Clean up
            workingNode.parentNode.removeChild(workingNode);

            return {
                boundaryPosition: boundaryPosition,
                nodeInfo: {
                    nodeIndex: nodeIndex,
                    containerElement: containerElement
                }
            };
        };

        // Returns a TextRange representing the boundary of a TextRange expressed as a node and an offset within that node.
        // This function started out as an optimized version of code found in Tim Cameron Ryan's IERange
        // (http://code.google.com/p/ierange/)
        var createBoundaryTextRange = function(boundaryPosition, isStart) {
            var boundaryNode, boundaryParent, boundaryOffset = boundaryPosition.offset;
            var doc = dom.getDocument(boundaryPosition.node);
            var workingNode, childNodes, workingRange = getBody(doc).createTextRange();
            var nodeIsDataNode = isCharacterDataNode(boundaryPosition.node);

            if (nodeIsDataNode) {
                boundaryNode = boundaryPosition.node;
                boundaryParent = boundaryNode.parentNode;
            } else {
                childNodes = boundaryPosition.node.childNodes;
                boundaryNode = (boundaryOffset < childNodes.length) ? childNodes[boundaryOffset] : null;
                boundaryParent = boundaryPosition.node;
            }

            // Position the range immediately before the node containing the boundary
            workingNode = doc.createElement("span");

            // Making the working element non-empty element persuades IE to consider the TextRange boundary to be within the
            // element rather than immediately before or after it
            workingNode.innerHTML = "&#feff;";

            // insertBefore is supposed to work like appendChild if the second parameter is null. However, a bug report
            // for IERange suggests that it can crash the browser: http://code.google.com/p/ierange/issues/detail?id=12
            if (boundaryNode) {
                boundaryParent.insertBefore(workingNode, boundaryNode);
            } else {
                boundaryParent.appendChild(workingNode);
            }

            workingRange.moveToElementText(workingNode);
            workingRange.collapse(!isStart);

            // Clean up
            boundaryParent.removeChild(workingNode);

            // Move the working range to the text offset, if required
            if (nodeIsDataNode) {
                workingRange[isStart ? "moveStart" : "moveEnd"]("character", boundaryOffset);
            }

            return workingRange;
        };

        /*------------------------------------------------------------------------------------------------------------*/

        // This is a wrapper around a TextRange, providing full DOM Range functionality using rangy's DomRange as a
        // prototype

        WrappedTextRange = function(textRange) {
            this.textRange = textRange;
            this.refresh();
        };

        WrappedTextRange.prototype = new DomRange(document);

        WrappedTextRange.prototype.refresh = function() {
            var start, end, startBoundary;

            // TextRange's parentElement() method cannot be trusted. getTextRangeContainerElement() works around that.
            var rangeContainerElement = getTextRangeContainerElement(this.textRange);

            if (textRangeIsCollapsed(this.textRange)) {
                end = start = getTextRangeBoundaryPosition(this.textRange, rangeContainerElement, true,
                    true).boundaryPosition;
            } else {
                startBoundary = getTextRangeBoundaryPosition(this.textRange, rangeContainerElement, true, false);
                start = startBoundary.boundaryPosition;

                // An optimization used here is that if the start and end boundaries have the same parent element, the
                // search scope for the end boundary can be limited to exclude the portion of the element that precedes
                // the start boundary
                end = getTextRangeBoundaryPosition(this.textRange, rangeContainerElement, false, false,
                    startBoundary.nodeInfo).boundaryPosition;
            }

            this.setStart(start.node, start.offset);
            this.setEnd(end.node, end.offset);
        };

        WrappedTextRange.prototype.getName = function() {
            return "WrappedTextRange";
        };

        DomRange.copyComparisonConstants(WrappedTextRange);

        WrappedTextRange.rangeToTextRange = function(range) {
            if (range.collapsed) {
                return createBoundaryTextRange(new DomPosition(range.startContainer, range.startOffset), true);
            } else {
                var startRange = createBoundaryTextRange(new DomPosition(range.startContainer, range.startOffset), true);
                var endRange = createBoundaryTextRange(new DomPosition(range.endContainer, range.endOffset), false);
                var textRange = getBody( DomRange.getRangeDocument(range) ).createTextRange();
                textRange.setEndPoint("StartToStart", startRange);
                textRange.setEndPoint("EndToEnd", endRange);
                return textRange;
            }
        };

        api.WrappedTextRange = WrappedTextRange;

        // IE 9 and above have both implementations and Rangy makes both available. The next few lines sets which
        // implementation to use by default.
        if (!api.features.implementsDomRange || api.config.preferTextRange) {
            // Add WrappedTextRange as the Range property of the global object to allow expression like Range.END_TO_END to work
            var globalObj = (function() { return this; })();
            if (typeof globalObj.Range == "undefined") {
                globalObj.Range = WrappedTextRange;
            }

            api.createNativeRange = function(doc) {
                doc = getContentDocument(doc, module, "createNativeRange");
                return getBody(doc).createTextRange();
            };

            api.WrappedRange = WrappedTextRange;
        }
    }

    api.createRange = function(doc) {
        doc = getContentDocument(doc, module, "createRange");
        return new api.WrappedRange(api.createNativeRange(doc));
    };

    api.createRangyRange = function(doc) {
        doc = getContentDocument(doc, module, "createRangyRange");
        return new DomRange(doc);
    };

    api.createIframeRange = function(iframeEl) {
        module.deprecationNotice("createIframeRange()", "createRange(iframeEl)");
        return api.createRange(iframeEl);
    };

    api.createIframeRangyRange = function(iframeEl) {
        module.deprecationNotice("createIframeRangyRange()", "createRangyRange(iframeEl)");
        return api.createRangyRange(iframeEl);
    };

    api.addCreateMissingNativeApiListener(function(win) {
        var doc = win.document;
        if (typeof doc.createRange == "undefined") {
            doc.createRange = function() {
                return api.createRange(doc);
            };
        }
        doc = win = null;
    });
});
// This module creates a selection object wrapper that conforms as closely as possible to the Selection specification
// in the HTML Editing spec (http://dvcs.w3.org/hg/editing/raw-file/tip/editing.html#selections)
rangy.createCoreModule("WrappedSelection", ["DomRange", "WrappedRange"], function(api, module) {
    api.config.checkSelectionRanges = true;

    var BOOLEAN = "boolean";
    var NUMBER = "number";
    var dom = api.dom;
    var util = api.util;
    var isHostMethod = util.isHostMethod;
    var DomRange = api.DomRange;
    var WrappedRange = api.WrappedRange;
    var DOMException = api.DOMException;
    var DomPosition = dom.DomPosition;
    var getNativeSelection;
    var selectionIsCollapsed;
    var features = api.features;
    var CONTROL = "Control";
    var getDocument = dom.getDocument;
    var getBody = dom.getBody;
    var rangesEqual = DomRange.rangesEqual;


    // Utility function to support direction parameters in the API that may be a string ("backward" or "forward") or a
    // Boolean (true for backwards).
    function isDirectionBackward(dir) {
        return (typeof dir == "string") ? /^backward(s)?$/i.test(dir) : !!dir;
    }

    function getWindow(win, methodName) {
        if (!win) {
            return window;
        } else if (dom.isWindow(win)) {
            return win;
        } else if (win instanceof WrappedSelection) {
            return win.win;
        } else {
            var doc = dom.getContentDocument(win, module, methodName);
            return dom.getWindow(doc);
        }
    }

    function getWinSelection(winParam) {
        return getWindow(winParam, "getWinSelection").getSelection();
    }

    function getDocSelection(winParam) {
        return getWindow(winParam, "getDocSelection").document.selection;
    }
    
    function winSelectionIsBackward(sel) {
        var backward = false;
        if (sel.anchorNode) {
            backward = (dom.comparePoints(sel.anchorNode, sel.anchorOffset, sel.focusNode, sel.focusOffset) == 1);
        }
        return backward;
    }

    // Test for the Range/TextRange and Selection features required
    // Test for ability to retrieve selection
    var implementsWinGetSelection = isHostMethod(window, "getSelection"),
        implementsDocSelection = util.isHostObject(document, "selection");

    features.implementsWinGetSelection = implementsWinGetSelection;
    features.implementsDocSelection = implementsDocSelection;

    var useDocumentSelection = implementsDocSelection && (!implementsWinGetSelection || api.config.preferTextRange);

    if (useDocumentSelection) {
        getNativeSelection = getDocSelection;
        api.isSelectionValid = function(winParam) {
            var doc = getWindow(winParam, "isSelectionValid").document, nativeSel = doc.selection;

            // Check whether the selection TextRange is actually contained within the correct document
            return (nativeSel.type != "None" || getDocument(nativeSel.createRange().parentElement()) == doc);
        };
    } else if (implementsWinGetSelection) {
        getNativeSelection = getWinSelection;
        api.isSelectionValid = function() {
            return true;
        };
    } else {
        module.fail("Neither document.selection or window.getSelection() detected.");
    }

    api.getNativeSelection = getNativeSelection;

    var testSelection = getNativeSelection();
    var testRange = api.createNativeRange(document);
    var body = getBody(document);

    // Obtaining a range from a selection
    var selectionHasAnchorAndFocus = util.areHostProperties(testSelection,
        ["anchorNode", "focusNode", "anchorOffset", "focusOffset"]);

    features.selectionHasAnchorAndFocus = selectionHasAnchorAndFocus;

    // Test for existence of native selection extend() method
    var selectionHasExtend = isHostMethod(testSelection, "extend");
    features.selectionHasExtend = selectionHasExtend;
    
    // Test if rangeCount exists
    var selectionHasRangeCount = (typeof testSelection.rangeCount == NUMBER);
    features.selectionHasRangeCount = selectionHasRangeCount;

    var selectionSupportsMultipleRanges = false;
    var collapsedNonEditableSelectionsSupported = true;

    var addRangeBackwardToNative = selectionHasExtend ?
        function(nativeSelection, range) {
            var doc = DomRange.getRangeDocument(range);
            var endRange = api.createRange(doc);
            endRange.collapseToPoint(range.endContainer, range.endOffset);
            nativeSelection.addRange(getNativeRange(endRange));
            nativeSelection.extend(range.startContainer, range.startOffset);
        } : null;

    if (util.areHostMethods(testSelection, ["addRange", "getRangeAt", "removeAllRanges"]) &&
            typeof testSelection.rangeCount == NUMBER && features.implementsDomRange) {

        (function() {
            // Previously an iframe was used but this caused problems in some circumstances in IE, so tests are
            // performed on the current document's selection. See issue 109.

            // Note also that if a selection previously existed, it is wiped by these tests. This should usually be fine
            // because initialization usually happens when the document loads, but could be a problem for a script that
            // loads and initializes Rangy later. If anyone complains, code could be added to save and restore the
            // selection.
            var sel = window.getSelection();
            if (sel) {
                // Store the current selection
                var originalSelectionRangeCount = sel.rangeCount;
                var selectionHasMultipleRanges = (originalSelectionRangeCount > 1);
                var originalSelectionRanges = [];
                var originalSelectionBackward = winSelectionIsBackward(sel); 
                for (var i = 0; i < originalSelectionRangeCount; ++i) {
                    originalSelectionRanges[i] = sel.getRangeAt(i);
                }
                
                // Create some test elements
                var body = getBody(document);
                var testEl = body.appendChild( document.createElement("div") );
                testEl.contentEditable = "false";
                var textNode = testEl.appendChild( document.createTextNode("\u00a0\u00a0\u00a0") );

                // Test whether the native selection will allow a collapsed selection within a non-editable element
                var r1 = document.createRange();

                r1.setStart(textNode, 1);
                r1.collapse(true);
                sel.addRange(r1);
                collapsedNonEditableSelectionsSupported = (sel.rangeCount == 1);
                sel.removeAllRanges();

                // Test whether the native selection is capable of supporting multiple ranges
                if (!selectionHasMultipleRanges) {
                    var r2 = r1.cloneRange();
                    r1.setStart(textNode, 0);
                    r2.setEnd(textNode, 3);
                    r2.setStart(textNode, 2);
                    sel.addRange(r1);
                    sel.addRange(r2);

                    selectionSupportsMultipleRanges = (sel.rangeCount == 2);
                    r2.detach();
                }

                // Clean up
                body.removeChild(testEl);
                sel.removeAllRanges();
                r1.detach();

                for (i = 0; i < originalSelectionRangeCount; ++i) {
                    if (i == 0 && originalSelectionBackward) {
                        if (addRangeBackwardToNative) {
                            addRangeBackwardToNative(sel, originalSelectionRanges[i]);
                        } else {
                            api.warn("Rangy initialization: original selection was backwards but selection has been restored forwards because browser does not support Selection.extend");
                            sel.addRange(originalSelectionRanges[i])
                        }
                    } else {
                        sel.addRange(originalSelectionRanges[i])
                    }
                }
            }
        })();
    }

    features.selectionSupportsMultipleRanges = selectionSupportsMultipleRanges;
    features.collapsedNonEditableSelectionsSupported = collapsedNonEditableSelectionsSupported;

    // ControlRanges
    var implementsControlRange = false, testControlRange;

    if (body && isHostMethod(body, "createControlRange")) {
        testControlRange = body.createControlRange();
        if (util.areHostProperties(testControlRange, ["item", "add"])) {
            implementsControlRange = true;
        }
    }
    features.implementsControlRange = implementsControlRange;

    // Selection collapsedness
    if (selectionHasAnchorAndFocus) {
        selectionIsCollapsed = function(sel) {
            return sel.anchorNode === sel.focusNode && sel.anchorOffset === sel.focusOffset;
        };
    } else {
        selectionIsCollapsed = function(sel) {
            return sel.rangeCount ? sel.getRangeAt(sel.rangeCount - 1).collapsed : false;
        };
    }

    function updateAnchorAndFocusFromRange(sel, range, backward) {
        var anchorPrefix = backward ? "end" : "start", focusPrefix = backward ? "start" : "end";
        sel.anchorNode = range[anchorPrefix + "Container"];
        sel.anchorOffset = range[anchorPrefix + "Offset"];
        sel.focusNode = range[focusPrefix + "Container"];
        sel.focusOffset = range[focusPrefix + "Offset"];
    }

    function updateAnchorAndFocusFromNativeSelection(sel) {
        var nativeSel = sel.nativeSelection;
        sel.anchorNode = nativeSel.anchorNode;
        sel.anchorOffset = nativeSel.anchorOffset;
        sel.focusNode = nativeSel.focusNode;
        sel.focusOffset = nativeSel.focusOffset;
    }

    function updateEmptySelection(sel) {
        sel.anchorNode = sel.focusNode = null;
        sel.anchorOffset = sel.focusOffset = 0;
        sel.rangeCount = 0;
        sel.isCollapsed = true;
        sel._ranges.length = 0;
    }

    function getNativeRange(range) {
        var nativeRange;
        if (range instanceof DomRange) {
            nativeRange = api.createNativeRange(range.getDocument());
            nativeRange.setEnd(range.endContainer, range.endOffset);
            nativeRange.setStart(range.startContainer, range.startOffset);
        } else if (range instanceof WrappedRange) {
            nativeRange = range.nativeRange;
        } else if (features.implementsDomRange && (range instanceof dom.getWindow(range.startContainer).Range)) {
            nativeRange = range;
        }
        return nativeRange;
    }

    function rangeContainsSingleElement(rangeNodes) {
        if (!rangeNodes.length || rangeNodes[0].nodeType != 1) {
            return false;
        }
        for (var i = 1, len = rangeNodes.length; i < len; ++i) {
            if (!dom.isAncestorOf(rangeNodes[0], rangeNodes[i])) {
                return false;
            }
        }
        return true;
    }

    function getSingleElementFromRange(range) {
        var nodes = range.getNodes();
        if (!rangeContainsSingleElement(nodes)) {
            throw module.createError("getSingleElementFromRange: range " + range.inspect() + " did not consist of a single element");
        }
        return nodes[0];
    }

    // Simple, quick test which only needs to distinguish between a TextRange and a ControlRange
    function isTextRange(range) {
        return !!range && typeof range.text != "undefined";
    }

    function updateFromTextRange(sel, range) {
        // Create a Range from the selected TextRange
        var wrappedRange = new WrappedRange(range);
        sel._ranges = [wrappedRange];

        updateAnchorAndFocusFromRange(sel, wrappedRange, false);
        sel.rangeCount = 1;
        sel.isCollapsed = wrappedRange.collapsed;
    }

    function updateControlSelection(sel) {
        // Update the wrapped selection based on what's now in the native selection
        sel._ranges.length = 0;
        if (sel.docSelection.type == "None") {
            updateEmptySelection(sel);
        } else {
            var controlRange = sel.docSelection.createRange();
            if (isTextRange(controlRange)) {
                // This case (where the selection type is "Control" and calling createRange() on the selection returns
                // a TextRange) can happen in IE 9. It happens, for example, when all elements in the selected
                // ControlRange have been removed from the ControlRange and removed from the document.
                updateFromTextRange(sel, controlRange);
            } else {
                sel.rangeCount = controlRange.length;
                var range, doc = getDocument(controlRange.item(0));
                for (var i = 0; i < sel.rangeCount; ++i) {
                    range = api.createRange(doc);
                    range.selectNode(controlRange.item(i));
                    sel._ranges.push(range);
                }
                sel.isCollapsed = sel.rangeCount == 1 && sel._ranges[0].collapsed;
                updateAnchorAndFocusFromRange(sel, sel._ranges[sel.rangeCount - 1], false);
            }
        }
    }

    function addRangeToControlSelection(sel, range) {
        var controlRange = sel.docSelection.createRange();
        var rangeElement = getSingleElementFromRange(range);

        // Create a new ControlRange containing all the elements in the selected ControlRange plus the element
        // contained by the supplied range
        var doc = getDocument(controlRange.item(0));
        var newControlRange = getBody(doc).createControlRange();
        for (var i = 0, len = controlRange.length; i < len; ++i) {
            newControlRange.add(controlRange.item(i));
        }
        try {
            newControlRange.add(rangeElement);
        } catch (ex) {
            throw module.createError("addRange(): Element within the specified Range could not be added to control selection (does it have layout?)");
        }
        newControlRange.select();

        // Update the wrapped selection based on what's now in the native selection
        updateControlSelection(sel);
    }

    var getSelectionRangeAt;

    if (isHostMethod(testSelection, "getRangeAt")) {
        // try/catch is present because getRangeAt() must have thrown an error in some browser and some situation.
        // Unfortunately, I didn't write a comment about the specifics and am now scared to take it out. Let that be a
        // lesson to us all, especially me.
        getSelectionRangeAt = function(sel, index) {
            try {
                return sel.getRangeAt(index);
            } catch (ex) {
                return null;
            }
        };
    } else if (selectionHasAnchorAndFocus) {
        getSelectionRangeAt = function(sel) {
            var doc = getDocument(sel.anchorNode);
            var range = api.createRange(doc);
            range.setStartAndEnd(sel.anchorNode, sel.anchorOffset, sel.focusNode, sel.focusOffset);

            // Handle the case when the selection was selected backwards (from the end to the start in the
            // document)
            if (range.collapsed !== this.isCollapsed) {
                range.setStartAndEnd(sel.focusNode, sel.focusOffset, sel.anchorNode, sel.anchorOffset);
            }

            return range;
        };
    }

    function WrappedSelection(selection, docSelection, win) {
        this.nativeSelection = selection;
        this.docSelection = docSelection;
        this._ranges = [];
        this.win = win;
        this.refresh();
    }

    WrappedSelection.prototype = api.selectionPrototype;

    function deleteProperties(sel) {
        sel.win = sel.anchorNode = sel.focusNode = sel._ranges = null;
        sel.rangeCount = sel.anchorOffset = sel.focusOffset = 0;
        sel.detached = true;
    }

    var cachedRangySelections = [];

    function actOnCachedSelection(win, action) {
        var i = cachedRangySelections.length, cached, sel;
        while (i--) {
            cached = cachedRangySelections[i];
            sel = cached.selection;
            if (action == "deleteAll") {
                deleteProperties(sel);
            } else if (cached.win == win) {
                if (action == "delete") {
                    cachedRangySelections.splice(i, 1);
                    return true;
                } else {
                    return sel;
                }
            }
        }
        if (action == "deleteAll") {
            cachedRangySelections.length = 0;
        }
        return null;
    }

    var getSelection = function(win) {
        // Check if the parameter is a Rangy Selection object
        if (win && win instanceof WrappedSelection) {
            win.refresh();
            return win;
        }

        win = getWindow(win, "getNativeSelection");

        var sel = actOnCachedSelection(win);
        var nativeSel = getNativeSelection(win), docSel = implementsDocSelection ? getDocSelection(win) : null;
        if (sel) {
            sel.nativeSelection = nativeSel;
            sel.docSelection = docSel;
            sel.refresh();
        } else {
            sel = new WrappedSelection(nativeSel, docSel, win);
            cachedRangySelections.push( { win: win, selection: sel } );
        }
        return sel;
    };

    api.getSelection = getSelection;

    api.getIframeSelection = function(iframeEl) {
        module.deprecationNotice("getIframeSelection()", "getSelection(iframeEl)");
        return api.getSelection(dom.getIframeWindow(iframeEl));
    };

    var selProto = WrappedSelection.prototype;

    function createControlSelection(sel, ranges) {
        // Ensure that the selection becomes of type "Control"
        var doc = getDocument(ranges[0].startContainer);
        var controlRange = getBody(doc).createControlRange();
        for (var i = 0, el, len = ranges.length; i < len; ++i) {
            el = getSingleElementFromRange(ranges[i]);
            try {
                controlRange.add(el);
            } catch (ex) {
                throw module.createError("setRanges(): Element within one of the specified Ranges could not be added to control selection (does it have layout?)");
            }
        }
        controlRange.select();

        // Update the wrapped selection based on what's now in the native selection
        updateControlSelection(sel);
    }

    // Selecting a range
    if (!useDocumentSelection && selectionHasAnchorAndFocus && util.areHostMethods(testSelection, ["removeAllRanges", "addRange"])) {
        selProto.removeAllRanges = function() {
            this.nativeSelection.removeAllRanges();
            updateEmptySelection(this);
        };

        var addRangeBackward = function(sel, range) {
            addRangeBackwardToNative(sel.nativeSelection, range);
            sel.refresh();
        };

        if (selectionHasRangeCount) {
            selProto.addRange = function(range, direction) {
                if (implementsControlRange && implementsDocSelection && this.docSelection.type == CONTROL) {
                    addRangeToControlSelection(this, range);
                } else {
                    if (isDirectionBackward(direction) && selectionHasExtend) {
                        addRangeBackward(this, range);
                    } else {
                        var previousRangeCount;
                        if (selectionSupportsMultipleRanges) {
                            previousRangeCount = this.rangeCount;
                        } else {
                            this.removeAllRanges();
                            previousRangeCount = 0;
                        }
                        // Clone the native range so that changing the selected range does not affect the selection.
                        // This is contrary to the spec but is the only way to achieve consistency between browsers. See
                        // issue 80.
                        this.nativeSelection.addRange(getNativeRange(range).cloneRange());

                        // Check whether adding the range was successful
                        this.rangeCount = this.nativeSelection.rangeCount;

                        if (this.rangeCount == previousRangeCount + 1) {
                            // The range was added successfully

                            // Check whether the range that we added to the selection is reflected in the last range extracted from
                            // the selection
                            if (api.config.checkSelectionRanges) {
                                var nativeRange = getSelectionRangeAt(this.nativeSelection, this.rangeCount - 1);
                                if (nativeRange && !rangesEqual(nativeRange, range)) {
                                    // Happens in WebKit with, for example, a selection placed at the start of a text node
                                    range = new WrappedRange(nativeRange);
                                }
                            }
                            this._ranges[this.rangeCount - 1] = range;
                            updateAnchorAndFocusFromRange(this, range, selectionIsBackward(this.nativeSelection));
                            this.isCollapsed = selectionIsCollapsed(this);
                        } else {
                            // The range was not added successfully. The simplest thing is to refresh
                            this.refresh();
                        }
                    }
                }
            };
        } else {
            selProto.addRange = function(range, direction) {
                if (isDirectionBackward(direction) && selectionHasExtend) {
                    addRangeBackward(this, range);
                } else {
                    this.nativeSelection.addRange(getNativeRange(range));
                    this.refresh();
                }
            };
        }

        selProto.setRanges = function(ranges) {
            if (implementsControlRange && ranges.length > 1) {
                createControlSelection(this, ranges);
            } else {
                this.removeAllRanges();
                for (var i = 0, len = ranges.length; i < len; ++i) {
                    this.addRange(ranges[i]);
                }
            }
        };
    } else if (isHostMethod(testSelection, "empty") && isHostMethod(testRange, "select") &&
               implementsControlRange && useDocumentSelection) {

        selProto.removeAllRanges = function() {
            // Added try/catch as fix for issue #21
            try {
                this.docSelection.empty();

                // Check for empty() not working (issue #24)
                if (this.docSelection.type != "None") {
                    // Work around failure to empty a control selection by instead selecting a TextRange and then
                    // calling empty()
                    var doc;
                    if (this.anchorNode) {
                        doc = getDocument(this.anchorNode);
                    } else if (this.docSelection.type == CONTROL) {
                        var controlRange = this.docSelection.createRange();
                        if (controlRange.length) {
                            doc = getDocument( controlRange.item(0) );
                        }
                    }
                    if (doc) {
                        var textRange = getBody(doc).createTextRange();
                        textRange.select();
                        this.docSelection.empty();
                    }
                }
            } catch(ex) {}
            updateEmptySelection(this);
        };

        selProto.addRange = function(range) {
            if (this.docSelection.type == CONTROL) {
                addRangeToControlSelection(this, range);
            } else {
                api.WrappedTextRange.rangeToTextRange(range).select();
                this._ranges[0] = range;
                this.rangeCount = 1;
                this.isCollapsed = this._ranges[0].collapsed;
                updateAnchorAndFocusFromRange(this, range, false);
            }
        };

        selProto.setRanges = function(ranges) {
            this.removeAllRanges();
            var rangeCount = ranges.length;
            if (rangeCount > 1) {
                createControlSelection(this, ranges);
            } else if (rangeCount) {
                this.addRange(ranges[0]);
            }
        };
    } else {
        module.fail("No means of selecting a Range or TextRange was found");
        return false;
    }

    selProto.getRangeAt = function(index) {
        if (index < 0 || index >= this.rangeCount) {
            throw new DOMException("INDEX_SIZE_ERR");
        } else {
            // Clone the range to preserve selection-range independence. See issue 80.
            return this._ranges[index].cloneRange();
        }
    };

    var refreshSelection;

    if (useDocumentSelection) {
        refreshSelection = function(sel) {
            var range;
            if (api.isSelectionValid(sel.win)) {
                range = sel.docSelection.createRange();
            } else {
                range = getBody(sel.win.document).createTextRange();
                range.collapse(true);
            }

            if (sel.docSelection.type == CONTROL) {
                updateControlSelection(sel);
            } else if (isTextRange(range)) {
                updateFromTextRange(sel, range);
            } else {
                updateEmptySelection(sel);
            }
        };
    } else if (isHostMethod(testSelection, "getRangeAt") && typeof testSelection.rangeCount == NUMBER) {
        refreshSelection = function(sel) {
            if (implementsControlRange && implementsDocSelection && sel.docSelection.type == CONTROL) {
                updateControlSelection(sel);
            } else {
                sel._ranges.length = sel.rangeCount = sel.nativeSelection.rangeCount;
                if (sel.rangeCount) {
                    for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                        sel._ranges[i] = new api.WrappedRange(sel.nativeSelection.getRangeAt(i));
                    }
                    updateAnchorAndFocusFromRange(sel, sel._ranges[sel.rangeCount - 1], selectionIsBackward(sel.nativeSelection));
                    sel.isCollapsed = selectionIsCollapsed(sel);
                } else {
                    updateEmptySelection(sel);
                }
            }
        };
    } else if (selectionHasAnchorAndFocus && typeof testSelection.isCollapsed == BOOLEAN && typeof testRange.collapsed == BOOLEAN && features.implementsDomRange) {
        refreshSelection = function(sel) {
            var range, nativeSel = sel.nativeSelection;
            if (nativeSel.anchorNode) {
                range = getSelectionRangeAt(nativeSel, 0);
                sel._ranges = [range];
                sel.rangeCount = 1;
                updateAnchorAndFocusFromNativeSelection(sel);
                sel.isCollapsed = selectionIsCollapsed(sel);
            } else {
                updateEmptySelection(sel);
            }
        };
    } else {
        module.fail("No means of obtaining a Range or TextRange from the user's selection was found");
        return false;
    }

    selProto.refresh = function(checkForChanges) {
        var oldRanges = checkForChanges ? this._ranges.slice(0) : null;
        var oldAnchorNode = this.anchorNode, oldAnchorOffset = this.anchorOffset;

        refreshSelection(this);
        if (checkForChanges) {
            // Check the range count first
            var i = oldRanges.length;
            if (i != this._ranges.length) {
                return true;
            }

            // Now check the direction. Checking the anchor position is the same is enough since we're checking all the
            // ranges after this
            if (this.anchorNode != oldAnchorNode || this.anchorOffset != oldAnchorOffset) {
                return true;
            }

            // Finally, compare each range in turn
            while (i--) {
                if (!rangesEqual(oldRanges[i], this._ranges[i])) {
                    return true;
                }
            }
            return false;
        }
    };

    // Removal of a single range
    var removeRangeManually = function(sel, range) {
        var ranges = sel.getAllRanges();
        sel.removeAllRanges();
        for (var i = 0, len = ranges.length; i < len; ++i) {
            if (!rangesEqual(range, ranges[i])) {
                sel.addRange(ranges[i]);
            }
        }
        if (!sel.rangeCount) {
            updateEmptySelection(sel);
        }
    };

    if (implementsControlRange) {
        selProto.removeRange = function(range) {
            if (this.docSelection.type == CONTROL) {
                var controlRange = this.docSelection.createRange();
                var rangeElement = getSingleElementFromRange(range);

                // Create a new ControlRange containing all the elements in the selected ControlRange minus the
                // element contained by the supplied range
                var doc = getDocument(controlRange.item(0));
                var newControlRange = getBody(doc).createControlRange();
                var el, removed = false;
                for (var i = 0, len = controlRange.length; i < len; ++i) {
                    el = controlRange.item(i);
                    if (el !== rangeElement || removed) {
                        newControlRange.add(controlRange.item(i));
                    } else {
                        removed = true;
                    }
                }
                newControlRange.select();

                // Update the wrapped selection based on what's now in the native selection
                updateControlSelection(this);
            } else {
                removeRangeManually(this, range);
            }
        };
    } else {
        selProto.removeRange = function(range) {
            removeRangeManually(this, range);
        };
    }

    // Detecting if a selection is backward
    var selectionIsBackward;
    if (!useDocumentSelection && selectionHasAnchorAndFocus && features.implementsDomRange) {
        selectionIsBackward = winSelectionIsBackward;

        selProto.isBackward = function() {
            return selectionIsBackward(this);
        };
    } else {
        selectionIsBackward = selProto.isBackward = function() {
            return false;
        };
    }

    // Create an alias for backwards compatibility. From 1.3, everything is "backward" rather than "backwards"
    selProto.isBackwards = selProto.isBackward;

    // Selection stringifier
    // This is conformant to the old HTML5 selections draft spec but differs from WebKit and Mozilla's implementation.
    // The current spec does not yet define this method.
    selProto.toString = function() {
        var rangeTexts = [];
        for (var i = 0, len = this.rangeCount; i < len; ++i) {
            rangeTexts[i] = "" + this._ranges[i];
        }
        return rangeTexts.join("");
    };

    function assertNodeInSameDocument(sel, node) {
        if (sel.win.document != getDocument(node)) {
            throw new DOMException("WRONG_DOCUMENT_ERR");
        }
    }

    // No current browser conforms fully to the spec for this method, so Rangy's own method is always used
    selProto.collapse = function(node, offset) {
        assertNodeInSameDocument(this, node);
        var range = api.createRange(node);
        range.collapseToPoint(node, offset);
        this.setSingleRange(range);
        this.isCollapsed = true;
    };

    selProto.collapseToStart = function() {
        if (this.rangeCount) {
            var range = this._ranges[0];
            this.collapse(range.startContainer, range.startOffset);
        } else {
            throw new DOMException("INVALID_STATE_ERR");
        }
    };

    selProto.collapseToEnd = function() {
        if (this.rangeCount) {
            var range = this._ranges[this.rangeCount - 1];
            this.collapse(range.endContainer, range.endOffset);
        } else {
            throw new DOMException("INVALID_STATE_ERR");
        }
    };

    // The spec is very specific on how selectAllChildren should be implemented so the native implementation is
    // never used by Rangy.
    selProto.selectAllChildren = function(node) {
        assertNodeInSameDocument(this, node);
        var range = api.createRange(node);
        range.selectNodeContents(node);
        this.setSingleRange(range);
    };

    selProto.deleteFromDocument = function() {
        // Sepcial behaviour required for IE's control selections
        if (implementsControlRange && implementsDocSelection && this.docSelection.type == CONTROL) {
            var controlRange = this.docSelection.createRange();
            var element;
            while (controlRange.length) {
                element = controlRange.item(0);
                controlRange.remove(element);
                element.parentNode.removeChild(element);
            }
            this.refresh();
        } else if (this.rangeCount) {
            var ranges = this.getAllRanges();
            if (ranges.length) {
                this.removeAllRanges();
                for (var i = 0, len = ranges.length; i < len; ++i) {
                    ranges[i].deleteContents();
                }
                // The spec says nothing about what the selection should contain after calling deleteContents on each
                // range. Firefox moves the selection to where the final selected range was, so we emulate that
                this.addRange(ranges[len - 1]);
            }
        }
    };

    // The following are non-standard extensions
    selProto.eachRange = function(func, returnValue) {
        for (var i = 0, len = this._ranges.length; i < len; ++i) {
            if ( func( this.getRangeAt(i) ) ) {
                return returnValue;
            }
        }
    };

    selProto.getAllRanges = function() {
        var ranges = [];
        this.eachRange(function(range) {
            ranges.push(range);
        });
        return ranges;
    };

    selProto.setSingleRange = function(range, direction) {
        this.removeAllRanges();
        this.addRange(range, direction);
    };

    selProto.callMethodOnEachRange = function(methodName, params) {
        var results = [];
        this.eachRange( function(range) {
            results.push( range[methodName].apply(range, params) );
        } );
        return results;
    };
    
    function createStartOrEndSetter(isStart) {
        return function(node, offset) {
            var range;
            if (this.rangeCount) {
                range = this.getRangeAt(0);
                range["set" + (isStart ? "Start" : "End")](node, offset);
            } else {
                range = api.createRange(this.win.document);
                range.setStartAndEnd(node, offset);
            }
            this.setSingleRange(range, this.isBackward());
        };
    }

    selProto.setStart = createStartOrEndSetter(true);
    selProto.setEnd = createStartOrEndSetter(false);
    
    // Add select() method to Range prototype. Any existing selection will be removed.
    api.rangePrototype.select = function(direction) {
        getSelection( this.getDocument() ).setSingleRange(this, direction);
    };

    selProto.changeEachRange = function(func) {
        var ranges = [];
        var backward = this.isBackward();

        this.eachRange(function(range) {
            func(range);
            ranges.push(range);
        });

        this.removeAllRanges();
        if (backward && ranges.length == 1) {
            this.addRange(ranges[0], "backward");
        } else {
            this.setRanges(ranges);
        }
    };

    selProto.containsNode = function(node, allowPartial) {
        return this.eachRange( function(range) {
            return range.containsNode(node, allowPartial);
        }, true );
    };

    selProto.getBookmark = function(containerNode) {
        return {
            backward: this.isBackward(),
            rangeBookmarks: this.callMethodOnEachRange("getBookmark", [containerNode])
        };
    };

    selProto.moveToBookmark = function(bookmark) {
        var selRanges = [];
        for (var i = 0, rangeBookmark, range; rangeBookmark = bookmark.rangeBookmarks[i++]; ) {
            range = api.createRange(this.win);
            range.moveToBookmark(rangeBookmark);
            selRanges.push(range);
        }
        if (bookmark.backward) {
            this.setSingleRange(selRanges[0], "backward");
        } else {
            this.setRanges(selRanges);
        }
    };

    selProto.toHtml = function() {
        return this.callMethodOnEachRange("toHtml").join("");
    };

    function inspect(sel) {
        var rangeInspects = [];
        var anchor = new DomPosition(sel.anchorNode, sel.anchorOffset);
        var focus = new DomPosition(sel.focusNode, sel.focusOffset);
        var name = (typeof sel.getName == "function") ? sel.getName() : "Selection";

        if (typeof sel.rangeCount != "undefined") {
            for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                rangeInspects[i] = DomRange.inspect(sel.getRangeAt(i));
            }
        }
        return "[" + name + "(Ranges: " + rangeInspects.join(", ") +
                ")(anchor: " + anchor.inspect() + ", focus: " + focus.inspect() + "]";
    }

    selProto.getName = function() {
        return "WrappedSelection";
    };

    selProto.inspect = function() {
        return inspect(this);
    };

    selProto.detach = function() {
        actOnCachedSelection(this.win, "delete");
        deleteProperties(this);
    };

    WrappedSelection.detachAll = function() {
        actOnCachedSelection(null, "deleteAll");
    };

    WrappedSelection.inspect = inspect;
    WrappedSelection.isDirectionBackward = isDirectionBackward;

    api.Selection = WrappedSelection;

    api.selectionPrototype = selProto;

    api.addCreateMissingNativeApiListener(function(win) {
        if (typeof win.getSelection == "undefined") {
            win.getSelection = function() {
                return getSelection(win);
            };
        }
        win = null;
    });
});


/**
 * Class Applier module for Rangy.
 * Adds, removes and toggles classes on Ranges and Selections
 *
 * Part of Rangy, a cross-browser JavaScript range and selection library
 * http://code.google.com/p/rangy/
 *
 * Depends on Rangy core.
 *
 * Copyright 2013, Tim Down
 * Licensed under the MIT license.
 * Version: 1.3alpha.804
 * Build date: 8 December 2013
 */
rangy.createModule("ClassApplier", ["WrappedSelection"], function(api, module) {
    var dom = api.dom;
    var DomPosition = dom.DomPosition;
    var contains = dom.arrayContains;


    var defaultTagName = "span";

    function each(obj, func) {
        for (var i in obj) {
            if (obj.hasOwnProperty(i)) {
                if (func(i, obj[i]) === false) {
                    return false;
                }
            }
        }
        return true;
    }
    
    function trim(str) {
        return str.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
    }

    function hasClass(el, cssClass) {
        return el.className && new RegExp("(?:^|\\s)" + cssClass + "(?:\\s|$)").test(el.className);
    }

    function addClass(el, cssClass) {
        if (el.className) {
            if (!hasClass(el, cssClass)) {
                el.className += " " + cssClass;
            }
        } else {
            el.className = cssClass;
        }
    }

    var removeClass = (function() {
        function replacer(matched, whiteSpaceBefore, whiteSpaceAfter) {
            return (whiteSpaceBefore && whiteSpaceAfter) ? " " : "";
        }

        return function(el, cssClass) {
            if (el.className) {
                el.className = el.className.replace(new RegExp("(^|\\s)" + cssClass + "(\\s|$)"), replacer);
            }
        };
    })();

    function sortClassName(className) {
        return className.split(/\s+/).sort().join(" ");
    }

    function getSortedClassName(el) {
        return sortClassName(el.className);
    }

    function haveSameClasses(el1, el2) {
        return getSortedClassName(el1) == getSortedClassName(el2);
    }

    function movePosition(position, oldParent, oldIndex, newParent, newIndex) {
        var node = position.node, offset = position.offset;
        var newNode = node, newOffset = offset;

        if (node == newParent && offset > newIndex) {
            ++newOffset;
        }

        if (node == oldParent && (offset == oldIndex  || offset == oldIndex + 1)) {
            newNode = newParent;
            newOffset += newIndex - oldIndex;
        }

        if (node == oldParent && offset > oldIndex + 1) {
            --newOffset;
        }

        position.node = newNode;
        position.offset = newOffset;
    }
    
    function movePositionWhenRemovingNode(position, parentNode, index) {
        if (position.node == parentNode && position.offset > index) {
            --position.offset;
        }
    }

    function movePreservingPositions(node, newParent, newIndex, positionsToPreserve) {
        // For convenience, allow newIndex to be -1 to mean "insert at the end".
        if (newIndex == -1) {
            newIndex = newParent.childNodes.length;
        }

        var oldParent = node.parentNode;
        var oldIndex = dom.getNodeIndex(node);

        for (var i = 0, position; position = positionsToPreserve[i++]; ) {
            movePosition(position, oldParent, oldIndex, newParent, newIndex);
        }

        // Now actually move the node.
        if (newParent.childNodes.length == newIndex) {
            newParent.appendChild(node);
        } else {
            newParent.insertBefore(node, newParent.childNodes[newIndex]);
        }
    }
    
    function removePreservingPositions(node, positionsToPreserve) {

        var oldParent = node.parentNode;
        var oldIndex = dom.getNodeIndex(node);

        for (var i = 0, position; position = positionsToPreserve[i++]; ) {
            movePositionWhenRemovingNode(position, oldParent, oldIndex);
        }

        node.parentNode.removeChild(node);
    }

    function moveChildrenPreservingPositions(node, newParent, newIndex, removeNode, positionsToPreserve) {
        var child, children = [];
        while ( (child = node.firstChild) ) {
            movePreservingPositions(child, newParent, newIndex++, positionsToPreserve);
            children.push(child);
        }
        if (removeNode) {
            node.parentNode.removeChild(node);
        }
        return children;
    }

    function replaceWithOwnChildrenPreservingPositions(element, positionsToPreserve) {
        return moveChildrenPreservingPositions(element, element.parentNode, dom.getNodeIndex(element), true, positionsToPreserve);
    }

    function rangeSelectsAnyText(range, textNode) {
        var textNodeRange = range.cloneRange();
        textNodeRange.selectNodeContents(textNode);

        var intersectionRange = textNodeRange.intersection(range);
        var text = intersectionRange ? intersectionRange.toString() : "";
        textNodeRange.detach();

        return text != "";
    }

    function getEffectiveTextNodes(range) {
        var nodes = range.getNodes([3]);
        
        // Optimization as per issue 145
        
        // Remove non-intersecting text nodes from the start of the range
        var start = 0, node;
        while ( (node = nodes[start]) && !rangeSelectsAnyText(range, node) ) {
            ++start;
        }

        // Remove non-intersecting text nodes from the start of the range
        var end = nodes.length - 1;
        while ( (node = nodes[end]) && !rangeSelectsAnyText(range, node) ) {
            --end;
        }
        
        return nodes.slice(start, end + 1);
    }

    function elementsHaveSameNonClassAttributes(el1, el2) {
        if (el1.attributes.length != el2.attributes.length) return false;
        for (var i = 0, len = el1.attributes.length, attr1, attr2, name; i < len; ++i) {
            attr1 = el1.attributes[i];
            name = attr1.name;
            if (name != "class") {
                attr2 = el2.attributes.getNamedItem(name);
                if ( (attr1 === null) != (attr2 === null) ) return false;
                if (attr1.specified != attr2.specified) return false;
                if (attr1.specified && attr1.nodeValue !== attr2.nodeValue) return false;
            }
        }
        return true;
    }

    function elementHasNonClassAttributes(el, exceptions) {
        for (var i = 0, len = el.attributes.length, attrName; i < len; ++i) {
            attrName = el.attributes[i].name;
            if ( !(exceptions && contains(exceptions, attrName)) && el.attributes[i].specified && attrName != "class") {
                return true;
            }
        }
        return false;
    }

    function elementHasProperties(el, props) {
        each(props, function(p, propValue) {
            if (typeof propValue == "object") {
                if (!elementHasProperties(el[p], propValue)) {
                    return false;
                }
            } else if (el[p] !== propValue) {
                return false;
            }
        });
        return true;
    }

    var getComputedStyleProperty = dom.getComputedStyleProperty;
    var isEditableElement = (function() {
        var testEl = document.createElement("div");
        return typeof testEl.isContentEditable == "boolean" ?
            function (node) {
                return node && node.nodeType == 1 && node.isContentEditable;
            } :
            function (node) {
                if (!node || node.nodeType != 1 || node.contentEditable == "false") {
                    return false;
                }
                return node.contentEditable == "true" || isEditableElement(node.parentNode);
            };
    })();

    function isEditingHost(node) {
        var parent;
        return node && node.nodeType == 1
            && (( (parent = node.parentNode) && parent.nodeType == 9 && parent.designMode == "on")
            || (isEditableElement(node) && !isEditableElement(node.parentNode)));
    }

    function isEditable(node) {
        return (isEditableElement(node) || (node.nodeType != 1 && isEditableElement(node.parentNode))) && !isEditingHost(node);
    }

    var inlineDisplayRegex = /^inline(-block|-table)?$/i;

    function isNonInlineElement(node) {
        return node && node.nodeType == 1 && !inlineDisplayRegex.test(getComputedStyleProperty(node, "display"));
    }

    // White space characters as defined by HTML 4 (http://www.w3.org/TR/html401/struct/text.html)
    var htmlNonWhiteSpaceRegex = /[^\r\n\t\f \u200B]/;

    function isUnrenderedWhiteSpaceNode(node) {
        if (node.data.length == 0) {
            return true;
        }
        if (htmlNonWhiteSpaceRegex.test(node.data)) {
            return false;
        }
        var cssWhiteSpace = getComputedStyleProperty(node.parentNode, "whiteSpace");
        switch (cssWhiteSpace) {
            case "pre":
            case "pre-wrap":
            case "-moz-pre-wrap":
                return false;
            case "pre-line":
                if (/[\r\n]/.test(node.data)) {
                    return false;
                }
        }

        // We now have a whitespace-only text node that may be rendered depending on its context. If it is adjacent to a
        // non-inline element, it will not be rendered. This seems to be a good enough definition.
        return isNonInlineElement(node.previousSibling) || isNonInlineElement(node.nextSibling);
    }

    function getRangeBoundaries(ranges) {
        var positions = [], i, range;
        for (i = 0; range = ranges[i++]; ) {
            positions.push(
                new DomPosition(range.startContainer, range.startOffset),
                new DomPosition(range.endContainer, range.endOffset)
            );
        }
        return positions;
    }

    function updateRangesFromBoundaries(ranges, positions) {
        for (var i = 0, range, start, end, len = ranges.length; i < len; ++i) {
            range = ranges[i];
            start = positions[i * 2];
            end = positions[i * 2 + 1];
            range.setStartAndEnd(start.node, start.offset, end.node, end.offset);
        }
    }

    function isSplitPoint(node, offset) {
        if (dom.isCharacterDataNode(node)) {
            if (offset == 0) {
                return !!node.previousSibling;
            } else if (offset == node.length) {
                return !!node.nextSibling;
            } else {
                return true;
            }
        }

        return offset > 0 && offset < node.childNodes.length;
    }

    function splitNodeAt(node, descendantNode, descendantOffset, positionsToPreserve) {
        var newNode, parentNode;
        var splitAtStart = (descendantOffset == 0);

        if (dom.isAncestorOf(descendantNode, node)) {
            return node;
        }

        if (dom.isCharacterDataNode(descendantNode)) {
            var descendantIndex = dom.getNodeIndex(descendantNode);
            if (descendantOffset == 0) {
                descendantOffset = descendantIndex;
            } else if (descendantOffset == descendantNode.length) {
                descendantOffset = descendantIndex + 1;
            } else {
                throw module.createError("splitNodeAt() should not be called with offset in the middle of a data node ("
                    + descendantOffset + " in " + descendantNode.data);
            }
            descendantNode = descendantNode.parentNode;
        }

        if (isSplitPoint(descendantNode, descendantOffset)) {
            // descendantNode is now guaranteed not to be a text or other character node
            newNode = descendantNode.cloneNode(false);
            parentNode = descendantNode.parentNode;
            if (newNode.id) {
                newNode.removeAttribute("id");
            }
            var child, newChildIndex = 0;

            while ( (child = descendantNode.childNodes[descendantOffset]) ) {
                movePreservingPositions(child, newNode, newChildIndex++, positionsToPreserve);
            }
            movePreservingPositions(newNode, parentNode, dom.getNodeIndex(descendantNode) + 1, positionsToPreserve);
            return (descendantNode == node) ? newNode : splitNodeAt(node, parentNode, dom.getNodeIndex(newNode), positionsToPreserve);
        } else if (node != descendantNode) {
            newNode = descendantNode.parentNode;

            // Work out a new split point in the parent node
            var newNodeIndex = dom.getNodeIndex(descendantNode);

            if (!splitAtStart) {
                newNodeIndex++;
            }
            return splitNodeAt(node, newNode, newNodeIndex, positionsToPreserve);
        }
        return node;
    }

    function areElementsMergeable(el1, el2) {
        return el1.tagName == el2.tagName
            && haveSameClasses(el1, el2)
            && elementsHaveSameNonClassAttributes(el1, el2)
            && getComputedStyleProperty(el1, "display") == "inline"
            && getComputedStyleProperty(el2, "display") == "inline";
    }

    function createAdjacentMergeableTextNodeGetter(forward) {
        var siblingPropName = forward ? "nextSibling" : "previousSibling";

        return function(textNode, checkParentElement) {
            var el = textNode.parentNode;
            var adjacentNode = textNode[siblingPropName];
            if (adjacentNode) {
                // Can merge if the node's previous/next sibling is a text node
                if (adjacentNode && adjacentNode.nodeType == 3) {
                    return adjacentNode;
                }
            } else if (checkParentElement) {
                // Compare text node parent element with its sibling
                adjacentNode = el[siblingPropName];
                if (adjacentNode && adjacentNode.nodeType == 1 && areElementsMergeable(el, adjacentNode)) {
                    var adjacentNodeChild = adjacentNode[forward ? "firstChild" : "lastChild"];
                    if (adjacentNodeChild && adjacentNodeChild.nodeType == 3) {
                        return adjacentNodeChild;
                    }
                }
            }
            return null;
        };
    }

    var getPreviousMergeableTextNode = createAdjacentMergeableTextNodeGetter(false),
        getNextMergeableTextNode = createAdjacentMergeableTextNodeGetter(true);


    function Merge(firstNode) {
        this.isElementMerge = (firstNode.nodeType == 1);
        this.textNodes = [];
        var firstTextNode = this.isElementMerge ? firstNode.lastChild : firstNode;
        if (firstTextNode) {
            this.textNodes[0] = firstTextNode;
        }
    }

    Merge.prototype = {
        doMerge: function(positionsToPreserve) {
            var textNodes = this.textNodes;
            var firstTextNode = textNodes[0];
            if (textNodes.length > 1) {
                var textParts = [], combinedTextLength = 0, textNode, parent;
                for (var i = 0, len = textNodes.length, j, position; i < len; ++i) {
                    textNode = textNodes[i];
                    parent = textNode.parentNode;
                    if (i > 0) {
                        parent.removeChild(textNode);
                        if (!parent.hasChildNodes()) {
                            parent.parentNode.removeChild(parent);
                        }
                        if (positionsToPreserve) {
                            for (j = 0; position = positionsToPreserve[j++]; ) {
                                // Handle case where position is inside the text node being merged into a preceding node
                                if (position.node == textNode) {
                                    position.node = firstTextNode;
                                    position.offset += combinedTextLength;
                                }
                            }
                        }
                    }
                    textParts[i] = textNode.data;
                    combinedTextLength += textNode.data.length;
                }
                firstTextNode.data = textParts.join("");
            }
            return firstTextNode.data;
        },

        getLength: function() {
            var i = this.textNodes.length, len = 0;
            while (i--) {
                len += this.textNodes[i].length;
            }
            return len;
        },

        toString: function() {
            var textParts = [];
            for (var i = 0, len = this.textNodes.length; i < len; ++i) {
                textParts[i] = "'" + this.textNodes[i].data + "'";
            }
            return "[Merge(" + textParts.join(",") + ")]";
        }
    };

    var optionProperties = ["elementTagName", "ignoreWhiteSpace", "applyToEditableOnly", "useExistingElements",
        "removeEmptyElements", "onElementCreate"];

    // TODO: Populate this with every attribute name that corresponds to a property with a different name. Really??
    var attrNamesForProperties = {};

    function ClassApplier(cssClass, options, tagNames) {
        var normalize, i, len, propName, applier = this;
        applier.cssClass = cssClass;

        var elementPropertiesFromOptions = null, elementAttributes = {};

        // Initialize from options object
        if (typeof options == "object" && options !== null) {
            tagNames = options.tagNames;
            elementPropertiesFromOptions = options.elementProperties;
            elementAttributes = options.elementAttributes;

            for (i = 0; propName = optionProperties[i++]; ) {
                if (options.hasOwnProperty(propName)) {
                    applier[propName] = options[propName];
                }
            }
            normalize = options.normalize;
        } else {
            normalize = options;
        }

        // Backward compatibility: the second parameter can also be a Boolean indicating to normalize after unapplying
        applier.normalize = (typeof normalize == "undefined") ? true : normalize;

        // Initialize element properties and attribute exceptions
        applier.attrExceptions = [];
        var el = document.createElement(applier.elementTagName);
        applier.elementProperties = applier.copyPropertiesToElement(elementPropertiesFromOptions, el, true);
        each(elementAttributes, function(attrName) {
            applier.attrExceptions.push(attrName);
        });
        applier.elementAttributes = elementAttributes;

        applier.elementSortedClassName = applier.elementProperties.hasOwnProperty("className") ?
            applier.elementProperties.className : cssClass;

        // Initialize tag names
        applier.applyToAnyTagName = false;
        var type = typeof tagNames;
        if (type == "string") {
            if (tagNames == "*") {
                applier.applyToAnyTagName = true;
            } else {
                applier.tagNames = trim(tagNames.toLowerCase()).split(/\s*,\s*/);
            }
        } else if (type == "object" && typeof tagNames.length == "number") {
            applier.tagNames = [];
            for (i = 0, len = tagNames.length; i < len; ++i) {
                if (tagNames[i] == "*") {
                    applier.applyToAnyTagName = true;
                } else {
                    applier.tagNames.push(tagNames[i].toLowerCase());
                }
            }
        } else {
            applier.tagNames = [applier.elementTagName];
        }
    }

    ClassApplier.prototype = {
        elementTagName: defaultTagName,
        elementProperties: {},
        elementAttributes: {},
        ignoreWhiteSpace: true,
        applyToEditableOnly: false,
        useExistingElements: true,
        removeEmptyElements: true,
        onElementCreate: null,

        copyPropertiesToElement: function(props, el, createCopy) {
            var s, elStyle, elProps = {}, elPropsStyle, propValue, elPropValue, attrName;

            for (var p in props) {
                if (props.hasOwnProperty(p)) {
                    propValue = props[p];
                    elPropValue = el[p];

                    // Special case for class. The copied properties object has the applier's CSS class as well as its
                    // own to simplify checks when removing styling elements
                    if (p == "className") {
                        addClass(el, propValue);
                        addClass(el, this.cssClass);
                        el[p] = sortClassName(el[p]);
                        if (createCopy) {
                            elProps[p] = el[p];
                        }
                    }

                    // Special case for style
                    else if (p == "style") {
                        elStyle = elPropValue;
                        if (createCopy) {
                            elProps[p] = elPropsStyle = {};
                        }
                        for (s in props[p]) {
                            elStyle[s] = propValue[s];
                            if (createCopy) {
                                elPropsStyle[s] = elStyle[s];
                            }
                        }
                        this.attrExceptions.push(p);
                    } else {
                        el[p] = propValue;
                        // Copy the property back from the dummy element so that later comparisons to check whether
                        // elements may be removed are checking against the right value. For example, the href property
                        // of an element returns a fully qualified URL even if it was previously assigned a relative
                        // URL.
                        if (createCopy) {
                            elProps[p] = el[p];

                            // Not all properties map to identically-named attributes
                            attrName = attrNamesForProperties.hasOwnProperty(p) ? attrNamesForProperties[p] : p;
                            this.attrExceptions.push(attrName);
                        }
                    }
                }
            }

            return createCopy ? elProps : "";
        },
        
        copyAttributesToElement: function(attrs, el) {
            for (var attrName in attrs) {
                if (attrs.hasOwnProperty(attrName)) {
                    el.setAttribute(attrName, attrs[attrName]);
                }
            }
        },

        hasClass: function(node) {
            return node.nodeType == 1 &&
                contains(this.tagNames, node.tagName.toLowerCase()) &&
                hasClass(node, this.cssClass);
        },

        getSelfOrAncestorWithClass: function(node) {
            while (node) {
                if (this.hasClass(node)) {
                    return node;
                }
                node = node.parentNode;
            }
            return null;
        },

        isModifiable: function(node) {
            return !this.applyToEditableOnly || isEditable(node);
        },

        // White space adjacent to an unwrappable node can be ignored for wrapping
        isIgnorableWhiteSpaceNode: function(node) {
            return this.ignoreWhiteSpace && node && node.nodeType == 3 && isUnrenderedWhiteSpaceNode(node);
        },

        // Normalizes nodes after applying a CSS class to a Range.
        postApply: function(textNodes, range, positionsToPreserve, isUndo) {
            var firstNode = textNodes[0], lastNode = textNodes[textNodes.length - 1];

            var merges = [], currentMerge;

            var rangeStartNode = firstNode, rangeEndNode = lastNode;
            var rangeStartOffset = 0, rangeEndOffset = lastNode.length;

            var textNode, precedingTextNode;

            // Check for every required merge and create a Merge object for each
            for (var i = 0, len = textNodes.length; i < len; ++i) {
                textNode = textNodes[i];
                precedingTextNode = getPreviousMergeableTextNode(textNode, !isUndo);
                if (precedingTextNode) {
                    if (!currentMerge) {
                        currentMerge = new Merge(precedingTextNode);
                        merges.push(currentMerge);
                    }
                    currentMerge.textNodes.push(textNode);
                    if (textNode === firstNode) {
                        rangeStartNode = currentMerge.textNodes[0];
                        rangeStartOffset = rangeStartNode.length;
                    }
                    if (textNode === lastNode) {
                        rangeEndNode = currentMerge.textNodes[0];
                        rangeEndOffset = currentMerge.getLength();
                    }
                } else {
                    currentMerge = null;
                }
            }

            // Test whether the first node after the range needs merging
            var nextTextNode = getNextMergeableTextNode(lastNode, !isUndo);

            if (nextTextNode) {
                if (!currentMerge) {
                    currentMerge = new Merge(lastNode);
                    merges.push(currentMerge);
                }
                currentMerge.textNodes.push(nextTextNode);
            }

            // Apply the merges
            if (merges.length) {
                for (i = 0, len = merges.length; i < len; ++i) {
                    merges[i].doMerge(positionsToPreserve);
                }

                // Set the range boundaries
                range.setStartAndEnd(rangeStartNode, rangeStartOffset, rangeEndNode, rangeEndOffset);
            }
        },

        createContainer: function(doc) {
            var el = doc.createElement(this.elementTagName);
            this.copyPropertiesToElement(this.elementProperties, el, false);
            this.copyAttributesToElement(this.elementAttributes, el);
            addClass(el, this.cssClass);
            if (this.onElementCreate) {
                this.onElementCreate(el, this);
            }
            return el;
        },

        applyToTextNode: function(textNode, positionsToPreserve) {
            var parent = textNode.parentNode;
            if (parent.childNodes.length == 1 &&
                    this.useExistingElements &&
                    contains(this.tagNames, parent.tagName.toLowerCase()) &&
                    elementHasProperties(parent, this.elementProperties)) {

                addClass(parent, this.cssClass);
            } else {
                var el = this.createContainer(dom.getDocument(textNode));
                textNode.parentNode.insertBefore(el, textNode);
                el.appendChild(textNode);
            }
        },

        isRemovable: function(el) {
            return el.tagName.toLowerCase() == this.elementTagName
                && getSortedClassName(el) == this.elementSortedClassName
                && elementHasProperties(el, this.elementProperties)
                && !elementHasNonClassAttributes(el, this.attrExceptions)
                && this.isModifiable(el);
        },

        isEmptyContainer: function(el) {
            var childNodeCount = el.childNodes.length;
            return el.nodeType == 1
                && this.isRemovable(el)
                && (childNodeCount == 0 || (childNodeCount == 1 && this.isEmptyContainer(el.firstChild)));
        },
        
        removeEmptyContainers: function(range) {
            var applier = this;
            var nodesToRemove = range.getNodes([1], function(el) {
                return applier.isEmptyContainer(el);
            });
            
            var rangesToPreserve = [range]
            var positionsToPreserve = getRangeBoundaries(rangesToPreserve);
            
            for (var i = 0, node; node = nodesToRemove[i++]; ) {
                removePreservingPositions(node, positionsToPreserve);
            }

            // Update the range from the preserved boundary positions
            updateRangesFromBoundaries(rangesToPreserve, positionsToPreserve);
        },

        undoToTextNode: function(textNode, range, ancestorWithClass, positionsToPreserve) {
            if (!range.containsNode(ancestorWithClass)) {
                // Split out the portion of the ancestor from which we can remove the CSS class
                //var parent = ancestorWithClass.parentNode, index = dom.getNodeIndex(ancestorWithClass);
                var ancestorRange = range.cloneRange();
                ancestorRange.selectNode(ancestorWithClass);
                if (ancestorRange.isPointInRange(range.endContainer, range.endOffset)) {
                    splitNodeAt(ancestorWithClass, range.endContainer, range.endOffset, positionsToPreserve);
                    range.setEndAfter(ancestorWithClass);
                }
                if (ancestorRange.isPointInRange(range.startContainer, range.startOffset)) {
                    ancestorWithClass = splitNodeAt(ancestorWithClass, range.startContainer, range.startOffset, positionsToPreserve);
                }
            }
            if (this.isRemovable(ancestorWithClass)) {
                replaceWithOwnChildrenPreservingPositions(ancestorWithClass, positionsToPreserve);
            } else {
                removeClass(ancestorWithClass, this.cssClass);
            }
        },

        applyToRange: function(range, rangesToPreserve) {
            rangesToPreserve = rangesToPreserve || [];

            // Create an array of range boundaries to preserve
            var positionsToPreserve = getRangeBoundaries(rangesToPreserve || []);
            
            range.splitBoundariesPreservingPositions(positionsToPreserve);

            // Tidy up the DOM by removing empty containers 
            if (this.removeEmptyElements) {
                this.removeEmptyContainers(range);
            }

            var textNodes = getEffectiveTextNodes(range);

            if (textNodes.length) {
                for (var i = 0, textNode; textNode = textNodes[i++]; ) {
                    if (!this.isIgnorableWhiteSpaceNode(textNode) && !this.getSelfOrAncestorWithClass(textNode)
                            && this.isModifiable(textNode)) {
                        this.applyToTextNode(textNode, positionsToPreserve);
                    }
                }
                textNode = textNodes[textNodes.length - 1];
                range.setStartAndEnd(textNodes[0], 0, textNode, textNode.length);
                if (this.normalize) {
                    this.postApply(textNodes, range, positionsToPreserve, false);
                }

                // Update the ranges from the preserved boundary positions
                updateRangesFromBoundaries(rangesToPreserve, positionsToPreserve);
            }
        },

        applyToRanges: function(ranges) {

            var i = ranges.length;
            while (i--) {
                this.applyToRange(ranges[i], ranges);
            }


            return ranges;
        },

        applyToSelection: function(win) {
            var sel = api.getSelection(win);
            sel.setRanges( this.applyToRanges(sel.getAllRanges()) );
        },

        undoToRange: function(range, rangesToPreserve) {
            // Create an array of range boundaries to preserve
            rangesToPreserve = rangesToPreserve || [];
            var positionsToPreserve = getRangeBoundaries(rangesToPreserve);


            range.splitBoundariesPreservingPositions(positionsToPreserve);

            // Tidy up the DOM by removing empty containers 
            if (this.removeEmptyElements) {
                this.removeEmptyContainers(range, positionsToPreserve);
            }

            var textNodes = getEffectiveTextNodes(range);
            var textNode, ancestorWithClass;
            var lastTextNode = textNodes[textNodes.length - 1];

            if (textNodes.length) {
                for (var i = 0, len = textNodes.length; i < len; ++i) {
                    textNode = textNodes[i];
                    ancestorWithClass = this.getSelfOrAncestorWithClass(textNode);
                    if (ancestorWithClass && this.isModifiable(textNode)) {
                        this.undoToTextNode(textNode, range, ancestorWithClass, positionsToPreserve);
                    }

                    // Ensure the range is still valid
                    range.setStartAndEnd(textNodes[0], 0, lastTextNode, lastTextNode.length);
                }


                if (this.normalize) {
                    this.postApply(textNodes, range, positionsToPreserve, true);
                }

                // Update the ranges from the preserved boundary positions
                updateRangesFromBoundaries(rangesToPreserve, positionsToPreserve);
            }
        },

        undoToRanges: function(ranges) {
            // Get ranges returned in document order
            var i = ranges.length;

            while (i--) {
                this.undoToRange(ranges[i], ranges);
            }

            return ranges;
        },

        undoToSelection: function(win) {
            var sel = api.getSelection(win);
            var ranges = api.getSelection(win).getAllRanges();
            this.undoToRanges(ranges);
            sel.setRanges(ranges);
        },

/*
        getTextSelectedByRange: function(textNode, range) {
            var textRange = range.cloneRange();
            textRange.selectNodeContents(textNode);

            var intersectionRange = textRange.intersection(range);
            var text = intersectionRange ? intersectionRange.toString() : "";
            textRange.detach();

            return text;
        },
*/

        isAppliedToRange: function(range) {
            if (range.collapsed || range.toString() == "") {
                return !!this.getSelfOrAncestorWithClass(range.commonAncestorContainer);
            } else {
                var textNodes = range.getNodes( [3] );
                if (textNodes.length)
                for (var i = 0, textNode; textNode = textNodes[i++]; ) {
                    if (!this.isIgnorableWhiteSpaceNode(textNode) && rangeSelectsAnyText(range, textNode)
                            && this.isModifiable(textNode) && !this.getSelfOrAncestorWithClass(textNode)) {
                        return false;
                    }
                }
                return true;
            }
        },

        isAppliedToRanges: function(ranges) {
            var i = ranges.length;
            if (i == 0) {
                return false;
            }
            while (i--) {
                if (!this.isAppliedToRange(ranges[i])) {
                    return false;
                }
            }
            return true;
        },

        isAppliedToSelection: function(win) {
            var sel = api.getSelection(win);
            return this.isAppliedToRanges(sel.getAllRanges());
        },

        toggleRange: function(range) {
            if (this.isAppliedToRange(range)) {
                this.undoToRange(range);
            } else {
                this.applyToRange(range);
            }
        },

/*
        toggleRanges: function(ranges) {
            if (this.isAppliedToRanges(ranges)) {
                this.undoToRanges(ranges);
            } else {
                this.applyToRanges(ranges);
            }
        },
*/

        toggleSelection: function(win) {
            if (this.isAppliedToSelection(win)) {
                this.undoToSelection(win);
            } else {
                this.applyToSelection(win);
            }
        },
        
        getElementsWithClassIntersectingRange: function(range) {
            var elements = [];
            var applier = this;
            range.getNodes([3], function(textNode) {
                var el = applier.getSelfOrAncestorWithClass(textNode);
                if (el && !contains(elements, el)) {
                    elements.push(el);
                }
            });
            return elements;
        },

/*
        getElementsWithClassIntersectingSelection: function(win) {
            var sel = api.getSelection(win);
            var elements = [];
            var applier = this;
            sel.eachRange(function(range) {
                var rangeElements = applier.getElementsWithClassIntersectingRange(range);
                for (var i = 0, el; el = rangeElements[i++]; ) {
                    if (!contains(elements, el)) {
                        elements.push(el);
                    }
                }
            });
            return elements;
        },
*/

        detach: function() {}
    };

    function createClassApplier(cssClass, options, tagNames) {
        return new ClassApplier(cssClass, options, tagNames);
    }

    ClassApplier.util = {
        hasClass: hasClass,
        addClass: addClass,
        removeClass: removeClass,
        hasSameClasses: haveSameClasses,
        replaceWithOwnChildren: replaceWithOwnChildrenPreservingPositions,
        elementsHaveSameNonClassAttributes: elementsHaveSameNonClassAttributes,
        elementHasNonClassAttributes: elementHasNonClassAttributes,
        splitNodeAt: splitNodeAt,
        isEditableElement: isEditableElement,
        isEditingHost: isEditingHost,
        isEditable: isEditable
    };

    api.CssClassApplier = api.ClassApplier = ClassApplier;
    api.createCssClassApplier = api.createClassApplier = createClassApplier;
});


// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {

    function encode(bytearr, encoder) {
        var chars = String.fromCharCode.apply(null, bytearr);
        
        if(!rayson.util.isUndefined(window.btoa))
            return window.btoa(chars);

        if(rayson.util.isFunction(encoder))
            return encoder(chars);
    
        throw new Error('There is no built-in encoder for b64, please provide one');
    }

    function decode(str, decoder) {
        var atobed;
        
        if(!rayson.util.isUndefined(window.atob))
            atobed = window.atob(str);
        else if(rayson.util.isFunction(decoder))
            atobed = decoder(str);
        else
            throw new Error('There is no built-in decoder for b64, please provide one');
        
        return atobed.split('').map(function(char) {
            return char.charCodeAt(0);        
        });
    }
    
    bundle.b64 = {
        encode: encode,
        decode: decode
    };
    
})(rayson);




;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {

    // CRC-16-CCITT
    // starts from: 0xFFFF, poly: 0x1021

    var crc_xors = [
        0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
        0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
        0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
        0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
        0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
        0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
        0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
        0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
        0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
        0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
        0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
        0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
        0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
        0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
        0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
        0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
        0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
        0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
        0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
        0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
        0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
        0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
        0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
        0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
        0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
        0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
        0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
        0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
        0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
        0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
        0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
        0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
    ];

    bundle.crc16 = function(bytearr) {
        var reg = 0xFFFF,
            idx;
        
        for(var b = 0; b < bytearr.length; b++) {
            idx = ((reg >>> 8) ^ bytearr[b]) & 0xFF;
            reg = (reg << 8) & 0xFFFF;
            reg ^= crc_xors[idx];
        }

        return reg;
    };

})(rayson);;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {

    var NODE_TYPE_OBJ = 'obj';
    var NODE_TYPE_ARRAY = 'array';
    var NODE_TYPE_VAL = 'val';
    var NODE_TYPE_INTERNAL = 'internal';
    var NODE_ROOT_KEY = 'root';

    function newNode(type, stack_obj, init) {
        var result = rayson.util.setNodeFlag(new Node(
                type, 
                stack_obj.node.length, 
                stack_obj.node, 
                stack_obj.level, 
                stack_obj.position, 
                stack_obj.parent,
                stack_obj.key
        ));

        for(var def in init) 
            result[def] = init[def];
        
        return result;
    }

    function Node(type, length, value, lvl, pos, parent, key) {
        this.type = type;
        this.length = length;
        this.value = value;
        this.level = lvl;
        this.position = pos;
        this.parent = parent;
        
        if(!rayson.util.isUndefined(key))
            this.key = key;
    }

    // dfs json traversal
    function iterate(tree_data, keymap, concat_keys) {
        var stack = [ { level: 0, position: 0, key: NODE_ROOT_KEY, node: tree_data } ],
            current,
            result = [],
            new_instance,
            concat_key = null,
            not_parent = true,
            arr_as_value = false;
      
        while(stack.length !== 0) {
            current = stack.pop();  
            
            if(rayson.util.inArray(current.key, concat_keys))
                concat_key = current.key;
           
            if(rayson.util.isNode(current.node)) {
                result.push(current.node);

                if(current.key === concat_key)
                    concat_key = null;
            
            } else if(rayson.util.isArray(current.node)) {

                not_parent = true;
                for(var i = 0; i < current.node.length; 
                    not_parent = (not_parent && !rayson.util.isParent(current.node[i])),
                    i++
                );

                arr_as_value = not_parent && concat_key !== null;
               
                if(arr_as_value)
                    new_instance = newNode(NODE_TYPE_VAL, current);
                else 
                    new_instance = newNode(NODE_TYPE_ARRAY, current, { value: '' });
                
                stack.push({ 
                    node: new_instance                
                });
                   
                if(!arr_as_value) {
                    for(var i = 0; i < current.node.length; i++) {
                        stack.push({ 
                            node: current.node[i], 
                            level: current.level + 1,
                            position: i,
                            parent: new_instance
                        });
                    }
                }
                
            } else if(rayson.util.isType(current.node)) {
                stack.push({
                    node: newNode(NODE_TYPE_INTERNAL, current, { length: 0 }) 
                });  
                
            } else if(rayson.util.isObject(current.node)) {
                new_instance = newNode(NODE_TYPE_OBJ, current, { value: '', length: 0 });
                
                stack.push({
                    node: new_instance
                });

                function push_child(child) {
                    if(current.node.hasOwnProperty(child)) {
                        stack.push({
                            key: child,
                            node: current.node[child],
                            level: current.level + 1,
                            position: new_instance.length,
                            parent: new_instance
                        });    
                        new_instance.length++;
                    }
                }

                var with_key = current;
                while(rayson.util.isUndefined(with_key.key)
                        && !rayson.util.isUndefined(with_key.parent)) {
                    with_key = with_key.parent;     
                }
                
                if(rayson.util.isObject(keymap) 
                    && rayson.util.isArray(keymap[with_key.key])) {
                
                    for(var k = 0; k < keymap[with_key.key].length; k++)
                        push_child(keymap[with_key.key][k]);

                } else {
                    for(var child in current.node)
                        push_child(child);
                }

            } else {
                if(!rayson.util.isUndefined(current.node))
                    result.push(newNode(NODE_TYPE_VAL, current));
            }
        }
        
        return result.reverse();
    };

    bundle.node = {
        iterate: iterate,
        TYPE_OBJ: NODE_TYPE_OBJ,
        TYPE_ARRAY: NODE_TYPE_ARRAY,
        TYPE_VAL: NODE_TYPE_VAL,
        TYPE_INTERNAL: NODE_TYPE_INTERNAL,
        ROOT_KEY: NODE_ROOT_KEY
    };
    
})(rayson);;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {
    
    bundle.serialize = function(tree_data, types, keymap) {
        var nodes,
            node_cnt = 0,
            result = [],
            current,
            encoded_length = [],
            encoded_value = [],
            isUndefined = rayson.util.isUndefined,
            key_type = null,
            checksum,
            raw_keys = []; 
        
        for(var t in types) {
            if(types.hasOwnProperty(t) && types[t].raw)
                raw_keys.push(t);
        }
        nodes = rayson.node.iterate(tree_data, keymap, raw_keys);
        
        for(; node_cnt < nodes.length; node_cnt++) {
            encoded_value = [];
            current = nodes[node_cnt];
            
            if(rayson.util.isParentNode(current)) {
                encoded_length = rayson.uleb128.encode(current.length);
                encoded_length[0] |= 0x80;  
                
            } else {
                if(!isUndefined(current.value)) {
                    key_type = current;
                    
                    while(
                          (isUndefined(key_type.key) || isUndefined(types[key_type.key]))
                        && !isUndefined(key_type.parent) 
                        && key_type.value !== rayson.node.ROOT_KEY
                    ) {
                        key_type = key_type.parent;
                    }
                    
                    if(!isUndefined(key_type.key) && rayson.util.isType(types[key_type.key]))
                        encoded_value = types[key_type.key].encode(current.value); 
                    else
                        encoded_value = rayson.type.raw.encode(current.value);
                }
                
                encoded_length = rayson.uleb128.encode(encoded_value.length);
            }
            
            result.push.apply(result, encoded_length);
            result.push.apply(result, encoded_value);
        }

        checksum = rayson.crc16(result);
        
        result.push.apply(result, [(checksum >>> 8) & 0xFF, checksum & 0xFF]);
        
        return result;
    };
    
})(rayson);
;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {
    
    var stream = function(data) {
        this.data = data;
        this.cursor = 0;
    };

    stream.prototype.empty = function() {
        return this.cursor >= this.data.length;
    };

    stream.prototype.readByte = function(n) {
        var result = this.getByte(n);
        this.cursor += rayson.util.isNumeric(n) ? n : 1; 
        
        return result;
    };

    stream.prototype.getByte = function(n) {
        if(rayson.util.isNumeric(n)) 
            return this.data.slice(this.cursor, this.cursor + n);
            
        return this.data[this.cursor];    
    }

    stream.prototype.getArray = function() {
        return this.data;    
    };

    stream.prototype.splice = function(idx, len) {
        return this.data.splice(idx, len);    
    };
  
    stream.prototype.size = function() {
        return this.data.length;
    };

    bundle.stream = stream;

})(rayson);

;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {

    var ULEB_MAX_SIZE = ulebSize(bitSize(Number.MAX_VALUE));

    // right bit shift >>
    function rsh(val, bits) {
        return Math.floor(val / Math.pow(2, bits));            
    }

    // left bit shift <<   
    function lsh(val, bits) {
        return val * Math.pow(2, bits);
    }

    // same as |, assumes that matching bits are 0's in result
    function bitor(a, b) {
        return a + b;       
    }

    function ulebSize(bitsize) {
        return Math.ceil((bitsize - 6) / 7) + 1;
    }
    
    function bitSize(number) {
        return Math.ceil(Math.log(number + 1)/Math.log(2));
    }

    function encode(val) {
        var output = [],
            output_size = ulebSize(bitSize(val)),
            part;
        
        for(var i = 0; i < output_size; i++) {
            part = val & 0x7F;
            val = rsh(val, 7);
           
            if(i !== 0) {
                if(i === output_size - 1)
                    part |= 0x40; 
                else
                    part |= 0x80;
            }
            
            output.push(part);
        }

        return output.reverse();
    }

    function decode(data) {
        var cnter = 0,
            byte,
            queue = [],
            result = 0;
        
        if(rayson.util.isArray(data))
            data = new rayson.stream(data);
        
        if(rayson.util.isStream(data)) {
            byte = data.readByte();
            queue.push(byte & 0x3F);
            
            if((byte & 0x40) === 0x40) {
                
                do {
                    cnter++; 
                    byte = data.readByte();
                    queue.push(byte & 0x7F);
                } while((byte & 0x80) === 0x80 && cnter < ULEB_MAX_SIZE);
            }

            result = queue.shift();
            
            while(queue.length > 0) {
                result = lsh(result, 7);
                result = bitor(result, queue.shift());
            }
        }
        
        return result;
    }

    bundle.uleb128 = {
        encode: encode,
        decode: decode,
        lsh: lsh,
        rsh: rsh
    };
    
})(rayson);

;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {
        
    var defaults = {
        // true when input should match template 1:1
        strict: false
    };

    bundle.unserialize = function(data, template, keymap, params) {
        if(rayson.util.isArray(data)) {
            data = new rayson.stream(data);
        } else if(!rayson.util.isStream(data))
            throw new Error('Expected array of bytes or stream'); 
        
        var checksum = data.splice(-2, 2);
        
        if(rayson.crc16(data.getArray()) !== ((checksum[0] << 8) | checksum[1]))
            throw new Error('rayson: Data corrupted, computed checksum does not match'); 

        if(rayson.util.isUndefined(params)) 
            params = {};
        
        for(var def in defaults) {
            params[def] = params[def] || defaults[def];
        }
   
        template = rayson.node.iterate(template, keymap);
            
            // stack for refrences to result tree,
            // last element is parent of current node
        var stack = [],
            
            // holds pointer to template of elements of
            // current array, and its level in the tree
            template_stack = [],
            
            // holds size of current level and position 
            // of cursor
            levels_stack = [],                        
            
            // info about current node from stream
            node_content = null,
            node_size = -1,
            node_is_array = false,
            
            // tracks level in stream's tree
            stream_level = 0,
            
            // holds reference to current template node
            template_cnt = 0,
            template_node,
            template_defined = false,

            // indicates which cursor is futher
            stream_further = true,
            template_further = true,
            
            // holds result tree
            result,
            
            // true whenever template and stream trees are on the same level
            level_conforms = false,
                   
            // array mode is on when there was specified array template in any of parent nodes 
            array_mode = false;
    
        while(!data.empty()) {
            array_mode = false;

            // when next object from templated array apply same template
            if(template_stack.length > 0) {
                var current_template = template_stack[template_stack.length - 1];
                
                array_mode = (current_template.type === rayson.node.TYPE_INTERNAL);
                
                /** @todo add protection from inifinitive loops */
                if(stream_level <= current_template.level 
                    || array_mode) {
                    template_cnt = current_template.template_ptr;
                }
            }
            
            template_node = template[template_cnt];
            template_defined = !rayson.util.isUndefined(template_node);
           
            level_conforms = template_defined && (stream_level === template_node.level);
            
            stream_further = 
                        !template_defined 
                        // is template cursor deeper (or at same level) in tree 
                        || (stream_level <= template_node.level) 
                        || (levels_stack > 0 
                                && template_node.position <= levels_stack[levels_stack.length - 1].position);
                
            template_further = 
                        !template_defined 
                        // is stream cursor deeper (or at same level) in tree 
                        || (stream_level >= template_node.level)
                        || (levels_stack > 0 
                                && template_node.position >= levels_stack[levels_stack.length - 1].position);
            
            // template cursor iterated further or is equal to stream's one
            if(template_further) { 
                node_is_array = (data.getByte() & 0x80) === 0x80;
                
                node_size = rayson.uleb128.decode(data);

                // strict mode check
                if((rayson.util.isParentNode(template_node) !== node_is_array) && params.strict) {
                    var strict_msg;
                    
                    if(node_is_array)
                        strict_msg = 'array structure from stream corresponds to `' + template_node.key + '` key in template';
                    else
                        strict_msg = 'template key `' + template_node.key + '` corresponds to array structure in stream';
                    
                    throw new Error('Strict: ' + strict_msg);
                }

                if(!node_is_array) {
                    node_content = data.readByte(node_size);
                    
                    if(level_conforms || array_mode) {
                        if(rayson.util.isType(template_node.value))
                            node_content = template_node.value.decode(node_content);
                        else
                            node_content = template_node.value;
                    }
                    
                } else if(level_conforms || array_mode) {
                    
                    if(rayson.util.isArrayNode(template_node) 
                        || rayson.util.isType(template_node.value))
                        node_content = [];
                    else
                        node_content = {};
                }

                // move position in top level
                if(levels_stack.length > 0)
                    levels_stack[levels_stack.length - 1].position++;
                
                if(stack.length > 0 && (level_conforms || array_mode)) {
                    if(rayson.util.isArray(stack[stack.length - 1]))
                        stack[stack.length - 1].push(node_content);
                    else
                        stack[stack.length - 1][template_node.key] = node_content;
                }
                  
                if(level_conforms) {
                    // save template position for next items in array
                    if(node_is_array && rayson.util.isArrayNode(template_node)) {
                        var template_next = template[template_cnt + 1];
                        
                        if(rayson.util.isObjectNode(template_next)
                            || rayson.util.isType(template_next.value)) {
                    
                            template_stack.push({   
                                level: template_next.level,
                                type: template_next.type, 
                                template_ptr: template_cnt + 1
                            });
                        }
                    }
                }
                
                if(node_is_array) {
                    stack.push(node_content);
                   
                    // saves current level params
                    levels_stack.push({ size: node_size, position: 0 });

                    stream_level++;
                }
               
                // pop all filled levels from top of the stack 
                while(levels_stack.length > 0 
                        && levels_stack[levels_stack.length - 1].position >= levels_stack[levels_stack.length - 1].size) {
                    result = stack.pop();
                    levels_stack.pop();
                    
                    stream_level--;
                    
                    // when poped level used template for its elements pop it from stack as well
                    if(template_stack.length > 0 
                            && stream_level < template_stack[template_stack.length - 1].level) {
                        template_stack.pop();
                    }
                }
            }
            
            // go through template tree until level and position of cursor match those from stream
            if(stream_further)
                template_cnt++;
        }
        
        return result;
    };

})(rayson);;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};

(function(bundle) {

    // some random value, uniquely indetifies Type objects
    var TYPE_FLAG = (new Date()).getTime() - 100;
    var TYPE_FLAG_KEY = 'typeflag';

    var NODE_FLAG = (new Date()).getTime();
    var NODE_FLAG_KEY = 'nodeflag';

    function isSpecialObject(obj, special_key, special_flag) {
        return (typeof obj[special_key] !== 'undefined') 
                && (obj[special_key] === special_flag); 
    }
    
    function isInstance(obj, type) {
        return {}.toString.call(obj) === '[object ' + type + ']';
    }

    bundle.util = {
        isNumeric: function(val) {
            return !isNaN(parseFloat(val)) && isFinite(val);           
        },
        isStream: function(obj) {
            return this.isObject(obj) && (typeof obj.readByte === 'function');
        },
        isArray: function(val) {
            return isInstance(val, 'Array');           
        },
        isObject: function(val) {
            return isInstance(val, 'Object');           
        },
        isParent: function(val) {
            return (this.isArray(val) || this.isObject(val)) && val.length > 0;    
        },
        isFunction: function(val) {
            return isInstance(val, 'Function');    
        },
        isUndefined: function(val) {
            return typeof val === 'undefined';    
        },
        isNode: function(val) {
            return this.isObject(val) && isSpecialObject(val, NODE_FLAG_KEY, NODE_FLAG); 
        },
        isParentNode: function(val) {
            return this.isArrayNode(val) || this.isObjectNode(val);        
        },
        isArrayNode: function(val) {
            return this.isNode(val) && val.type === rayson.node.TYPE_ARRAY;
        },
        isObjectNode: function(val) {
            return this.isNode(val) && val.type === rayson.node.TYPE_OBJ;
        },
        size: function(val) {
            if(this.isArray(val))
                return val.length;

            var key, size = 0;
            for(key in val)
                if(val.hasOwnProperty(key)) size++;

            return size;
        },
        setNodeFlag: function(obj) {
            if(this.isObject(obj))
                obj[NODE_FLAG_KEY] = NODE_FLAG;
            
            return obj;
        },
        isType: function(val) {
            return this.isObject(val) && isSpecialObject(val, TYPE_FLAG_KEY, TYPE_FLAG);
        },
        setTypeFlag: function(obj) {
            if(this.isObject(obj))
                obj[TYPE_FLAG_KEY] = TYPE_FLAG;
            
            return obj;
        },
        inArray: function(elem, arr) {
            if(this.isArray(arr)) {
                if(Array.prototype.indexOf)
                    return arr.indexOf(elem) >= 0;

                for(var i = 0; i < arr.length; i++) {
                    if(arr[i] === elem)
                        return true;
                }
            }
            return false;
        }
    };

})(rayson);;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};
rayson.type = rayson.type || {};

(function(bundle) {
    
    bundle.bool = rayson.util.setTypeFlag({
        encode: function(boo) {
            if(boo === true)
                return [ 0xFF ];
            return [ 0x00 ];
        },
        decode: function(bytearr) {
            return bytearr[0] === 0xFF;
        }
    });
    
})(rayson.type);
;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};
rayson.type = rayson.type || {};

(function(bundle) {
    var INT_BYTE_SIZE = 4;
    
    bundle.int32 = rayson.util.setTypeFlag({
        encode: function(int32) {
            var result = [],
                i;    
            
            for(i = (INT_BYTE_SIZE - 1); i >= 0; i--)
                result.push((int32 >>> (i * 8)) & 0xFF);
           
            return result;
        },
        decode: function(bytearr) {
            if(bytearr.length !== INT_BYTE_SIZE)
                return 0;
            
            var result = 0x00;

            for(i = 0; i < INT_BYTE_SIZE; i++)
                result |= (bytearr[INT_BYTE_SIZE - i - 1] << (i * 8));

            return result;
        }
    });
    
})(rayson.type);;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};
rayson.type = rayson.type || {};

(function(bundle) {
    // signed from -128 to 127
    bundle.int8 = rayson.util.setTypeFlag({
        encode: function(int8) {
            return [ ((int8 % 129 + 128) % 256) ];
        },
        decode: function(bytearr) {
            return bytearr[0] - 128;
        }
    });
    
})(rayson.type);

;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};
rayson.type = rayson.type || {};

(function(bundle) {
    
    bundle.raw = rayson.util.setTypeFlag({
        encode: function(bytearr) {
            if(!rayson.util.isArray(bytearr))
                return [];
            
            return bytearr;
        },
        decode: function(bytearr) {
            return bytearr;
        },
        raw: true
    });
    
})(rayson.type);
;// Rayson package   (c) Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Please view the LICENSE file distributed with this code.

var rayson = rayson || {};
rayson.type = rayson.type || {};

(function(bundle) {
    
    bundle.str = rayson.util.setTypeFlag({
        encode: function(str) {
            return unescape(encodeURIComponent(str)).split('').map(function(ch) {
                return ch.charCodeAt(0);
            });
        },
        decode: function(bytearr) {
            return decodeURIComponent(escape(String.fromCharCode.apply(null, bytearr)));
        }
    });
    
})(rayson.type);    
        




/*
 * $Id: base64.js,v 2.15 2014/04/05 12:58:57 dankogai Exp dankogai $
 *
 *  Licensed under the MIT license.
 *    http://opensource.org/licenses/mit-license
 *
 *  References:
 *    http://en.wikipedia.org/wiki/Base64
 */

(function(global) {
    'use strict';
    // existing version for noConflict()
    var _Base64 = global.Base64;
    var version = "2.1.5";
    // if node.js, we use Buffer
    var buffer;
    if (typeof module !== 'undefined' && module.exports) {
        buffer = require('buffer').Buffer;
    }
    // constants
    var b64chars
        = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var b64tab = function(bin) {
        var t = {};
        for (var i = 0, l = bin.length; i < l; i++) t[bin.charAt(i)] = i;
        return t;
    }(b64chars);
    var fromCharCode = String.fromCharCode;
    // encoder stuff
    var cb_utob = function(c) {
        if (c.length < 2) {
            var cc = c.charCodeAt(0);
            return cc < 0x80 ? c
                : cc < 0x800 ? (fromCharCode(0xc0 | (cc >>> 6))
                                + fromCharCode(0x80 | (cc & 0x3f)))
                : (fromCharCode(0xe0 | ((cc >>> 12) & 0x0f))
                   + fromCharCode(0x80 | ((cc >>>  6) & 0x3f))
                   + fromCharCode(0x80 | ( cc         & 0x3f)));
        } else {
            var cc = 0x10000
                + (c.charCodeAt(0) - 0xD800) * 0x400
                + (c.charCodeAt(1) - 0xDC00);
            return (fromCharCode(0xf0 | ((cc >>> 18) & 0x07))
                    + fromCharCode(0x80 | ((cc >>> 12) & 0x3f))
                    + fromCharCode(0x80 | ((cc >>>  6) & 0x3f))
                    + fromCharCode(0x80 | ( cc         & 0x3f)));
        }
    };
    var re_utob = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;
    var utob = function(u) {
        return u.replace(re_utob, cb_utob);
    };
    var cb_encode = function(ccc) {
        var padlen = [0, 2, 1][ccc.length % 3],
        ord = ccc.charCodeAt(0) << 16
            | ((ccc.length > 1 ? ccc.charCodeAt(1) : 0) << 8)
            | ((ccc.length > 2 ? ccc.charCodeAt(2) : 0)),
        chars = [
            b64chars.charAt( ord >>> 18),
            b64chars.charAt((ord >>> 12) & 63),
            padlen >= 2 ? '=' : b64chars.charAt((ord >>> 6) & 63),
            padlen >= 1 ? '=' : b64chars.charAt(ord & 63)
        ];
        return chars.join('');
    };
    var btoa = global.btoa ? function(b) {
        return global.btoa(b);
    } : function(b) {
        return b.replace(/[\s\S]{1,3}/g, cb_encode);
    };
    var _encode = buffer
        ? function (u) { return (new buffer(u)).toString('base64') } 
    : function (u) { return btoa(utob(u)) }
    ;
    var encode = function(u, urisafe) {
        return !urisafe 
            ? _encode(u)
            : _encode(u).replace(/[+\/]/g, function(m0) {
                return m0 == '+' ? '-' : '_';
            }).replace(/=/g, '');
    };
    var encodeURI = function(u) { return encode(u, true) };
    // decoder stuff
    var re_btou = new RegExp([
        '[\xC0-\xDF][\x80-\xBF]',
        '[\xE0-\xEF][\x80-\xBF]{2}',
        '[\xF0-\xF7][\x80-\xBF]{3}'
    ].join('|'), 'g');
    var cb_btou = function(cccc) {
        switch(cccc.length) {
        case 4:
            var cp = ((0x07 & cccc.charCodeAt(0)) << 18)
                |    ((0x3f & cccc.charCodeAt(1)) << 12)
                |    ((0x3f & cccc.charCodeAt(2)) <<  6)
                |     (0x3f & cccc.charCodeAt(3)),
            offset = cp - 0x10000;
            return (fromCharCode((offset  >>> 10) + 0xD800)
                    + fromCharCode((offset & 0x3FF) + 0xDC00));
        case 3:
            return fromCharCode(
                ((0x0f & cccc.charCodeAt(0)) << 12)
                    | ((0x3f & cccc.charCodeAt(1)) << 6)
                    |  (0x3f & cccc.charCodeAt(2))
            );
        default:
            return  fromCharCode(
                ((0x1f & cccc.charCodeAt(0)) << 6)
                    |  (0x3f & cccc.charCodeAt(1))
            );
        }
    };
    var btou = function(b) {
        return b.replace(re_btou, cb_btou);
    };
    var cb_decode = function(cccc) {
        var len = cccc.length,
        padlen = len % 4,
        n = (len > 0 ? b64tab[cccc.charAt(0)] << 18 : 0)
            | (len > 1 ? b64tab[cccc.charAt(1)] << 12 : 0)
            | (len > 2 ? b64tab[cccc.charAt(2)] <<  6 : 0)
            | (len > 3 ? b64tab[cccc.charAt(3)]       : 0),
        chars = [
            fromCharCode( n >>> 16),
            fromCharCode((n >>>  8) & 0xff),
            fromCharCode( n         & 0xff)
        ];
        chars.length -= [0, 0, 2, 1][padlen];
        return chars.join('');
    };
    var atob = global.atob ? function(a) {
        return global.atob(a);
    } : function(a){
        return a.replace(/[\s\S]{1,4}/g, cb_decode);
    };
    var _decode = buffer
        ? function(a) { return (new buffer(a, 'base64')).toString() }
    : function(a) { return btou(atob(a)) };
    var decode = function(a){
        return _decode(
            a.replace(/[-_]/g, function(m0) { return m0 == '-' ? '+' : '/' })
                .replace(/[^A-Za-z0-9\+\/]/g, '')
        );
    };
    var noConflict = function() {
        var Base64 = global.Base64;
        global.Base64 = _Base64;
        return Base64;
    };
    // export Base64
    global.Base64 = {
        VERSION: version,
        atob: atob,
        btoa: btoa,
        fromBase64: decode,
        toBase64: encode,
        utob: utob,
        encode: encode,
        encodeURI: encodeURI,
        btou: btou,
        decode: decode,
        noConflict: noConflict
    };
    // if ES5 is available, make Base64.extendString() available
    if (typeof Object.defineProperty === 'function') {
        var noEnum = function(v){
            return {value:v,enumerable:false,writable:true,configurable:true};
        };
        global.Base64.extendString = function () {
            Object.defineProperty(
                String.prototype, 'fromBase64', noEnum(function () {
                    return decode(this)
                }));
            Object.defineProperty(
                String.prototype, 'toBase64', noEnum(function (urisafe) {
                    return encode(this, urisafe)
                }));
            Object.defineProperty(
                String.prototype, 'toBase64URI', noEnum(function () {
                    return encode(this, true)
                }));
        };
    }
    // that's it!
})(this);

if (this['Meteor']) {
    Base64 = global.Base64; // for normal export in Meteor.js
}


/* Nano Templates (Tomasz Mazur, Jacek Becela) */

function nano(template, data) {
  return template.replace(/\{([\w\.]*)\}/g, function(str, key) {
    var keys = key.split("."), v = data[keys.shift()];
    for (var i = 0, l = keys.length; i < l; i++) v = v[keys[i]];
    return (typeof v !== "undefined" && v !== null) ? v : "";
  });
}


// jNottery library 
// Copyright (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org> 
// Released under the MIT license. 
        
(function() { 
var main_view = '<div class="tt-tooltip"> <div class="tt-header"> <div class="tt-info"> <span class="tt-title">{title}</span> <a href="http://jnottery.com/" target="_blank">read more</a> </div> <div class="tt-close">{btn.close}</div> </div> <div class="tt-main"> <div class="tt-btns"> <div class="tt-btn tt-facebook"> <div class="tt-hint"> <div>{btn.facebook.label}</div> </div> <div class="tt-notready"> <div>{btn.disabled}</div> </div> </div> <div class="tt-btn tt-twitter"> <div class="tt-hint"> <div>{btn.twitter.label}</div> </div> <div class="tt-notready"> <div>{btn.disabled}</div> </div> </div> <div class="tt-btn tt-link"> <div class="tt-hint"> <div>{btn.link.label}</div> </div> <div class="tt-notready"> <div>{btn.disabled}</div> </div> </div> <div class="tt-btn tt-save"> <div class="tt-hint"> <div>{btn.save.label}</div> </div> <div class="tt-notready"> <div>{btn.disabled}</div> </div> </div> </div> <div class="tt-form"> <div class="tt-content"> <textarea class="tt-input" placeholder="{txt.placeholder}" autocomplete="off"></textarea> <input class="tt-submit tt-add" type="submit" value="{btn.submit.label}"/> <input class="tt-submit tt-edit" type="submit" value="{btn.edit.label}"/> <input class="tt-submit tt-del" type="submit" value="{btn.del.label}"/> </div> </div> </div> <div class="tt-arrow"></div> </div> ';;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function($) {
    var OBJ_NOTE = 0,
        OBJ_SELECTION = 1,
        OBJ_ELEMENT = 2;

    var last_range = null;
    
    window.tt = function(obj, context) {
        var $obj,
            target,
            obj_type;
       
        if(!obj) {
            return $();
        } else if(obj instanceof tt.core.Note) {
            if(obj instanceof tt.core.SelectionNote) {
                !obj.range.isValid() && obj.range.refresh();
                $obj = tt.range.getElements(obj.range, obj.id);
            } else
                $obj = obj.element;
                
            target = obj;
            obj_type = OBJ_NOTE;
        } else if(obj.tt_selection && obj.tt_selection instanceof tt.core.Selection) {
            $obj = obj;
            target = obj.tt_selection;
            obj_type = OBJ_SELECTION;
        } else {
            $obj = new $.fn.init(obj, context);
            obj_type = OBJ_ELEMENT;
        }

        return $.extend({}, $obj, {
            arrowPosition: function(options) {
                return tt.tooltip.arrowPosition($.extend({}, { root: $(this) }, options)); 
            },
            tooltip: function(options) {
                var first_note,
                    tooltip,
                    add_note_to = $(this),
                    note_factory = function(content) {
                        return new tt.core.ElementNote(add_note_to, content); 
                    };
                
                last_range && tt.range.clear(last_range);
               
                // stick to one note per element
                switch(obj_type) {
                    case OBJ_NOTE: {
                        add_note_to = target.element;
                        first_note = target;
                        break;    
                    }
                    case OBJ_SELECTION: {
                        add_note_to = target.element;
                        last_range = target.range;
            
                        note_factory = function(content) {
                            last_range = null;
                            return new tt.core.SelectionNote(add_note_to, target.range, content); 
                        };
                        
                        break;    
                    }
                    default: { 
                        $.each(tt.core.getNotes($(this)), function(id, note) {
                            if(note instanceof tt.core.ElementNote) {
                                first_note = note; 
                                return false;
                            }
                        });
                    }
                }
                        
                tooltip = tt.tooltip.open($.extend({}, { 
                    root: $(this),
                    edit: (first_note ? first_note.id : false),
                    content: (first_note ? first_note.getContent() : ''),
                    init: function(tooltip) {

                        tooltip.on({
                            'btn.edit.click.tt': function() {
                                tt.tooltip.switchEditMode(false);    
                            },
                            'btn.facebook.click.tt': function() {
                                tt.vendor.facebook(document.URL);
                            },
                            'btn.twitter.click.tt': function() {
                                tt.vendor.bitly(document.URL, function(short_url) {
                                    tt.vendor.twitter(short_url);    
                                });
                            },
                            'btn.link.click.tt': function() {
                                tt.vendor.bitly(document.URL, function(short_url) {
                                    window.prompt('Here is link to this page containing your notes (Ctrl + C to save in clipboard)', short_url);  
                                });
                            },
                            'btn.save.click.tt': function() {
                                var agent = navigator.userAgent.toLowerCase(),
                                    letter = 'D';

                                if(window.opera && window.opera.version() < 9)
                                    letter = 'T';
                                else if(agent.indexOf('konqueror') !== -1)
                                    letter = 'B'; 

                                alert('Your notes are currently encoded in URL. Press ' + (agent.indexOf('mac') !== -1 ? 'Cmd' : 'Ctrl') + ' + ' + letter + ' to bookmark this page and all of your notes at once.');
                            }
                        });
                    }
                }, options));
               
                tooltip.off('submit.tt').on('submit.tt', function(e, tooltip_obj) {
                    var note_id = tooltip_obj.edit(),
                        content = tooltip_obj.content(),
                        note;
                   
                    if(!content)
                        return false;
                    
                    if(!note_id) {
                        note = note_factory(content);
                        var asd = tt.core.addNote(note);
                        tooltip_obj.edit(asd);
                        
                        if(note.range && note.range.isValid()) {
                            tt.range.clear(note.range);
                            tt.range.apply(note.range, asd);
                        }
                    } else {
                        note = tt.core.getNote(add_note_to, note_id);
                        note.setContent(content);
                    }
                   
                    tt.tooltip.switchEditMode(true);    
                    tt.core.updateHash();
                    
                    tooltip.trigger((note_id ? 'edit.note.tt' : 'new.note.tt'), [ tooltip_obj, note ]);
                });

                tooltip.off('delete.tt').on('delete.tt', function(e, tooltip_obj) {
                    var note_id = tooltip_obj.edit(),
                        note;
                    
                    if(note_id) {
                        note = tt.core.getNote(add_note_to, note_id);
                        
                        if(note.range)
                            tt.range.clear(note.range, note.id);
                        
                        note.remove();
                        tooltip.trigger('deleted.note.tt', [ tooltip_obj, note_id ]);
                        
                        tt.tooltip.close();
                        
                        tt.core.updateHash();
                    }
                });

                tooltip.off('close.tt');
                
                if(obj_type === OBJ_SELECTION) {
                    tooltip.on('close.tt', function(e, tooltip) {
                        if(!tooltip.edit() && target.range && target.range.isValid()) {
                            tt.range.clear(target.range);
                            last_range = null;
                        }  
                    });
                }

                return tooltip;
            },
            init: function(options) {
                if(!rangy.initialized)
                    rangy.init();
                
                tt.core.init($.extend({}, { root: $(this) }, options));

                if(options && options.vendor)
                    tt.vendor.init(options.vendor);

                return this;
            },
            selection: function() {
                var range = tt.range.getFrom($(this)),
                    result;

                if(range) {
                    tt.range.apply(range);
                    result = tt.range.getElements(range); 
                    
                    result.tt_selection = new tt.core.Selection($(this), range);
                    
                    return result;
                }

                return $();
            }
        });
    };

})(window.jQuery);;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $, rayson, rangy) {
    rangy.config = {
        alertOnFail: false,
        alertOnWarn: false,
        checkSelectionRanges: true,
        preferTextRange: false
    };
    
    var str = rayson.type.str,
        raw = rayson.type.raw;

    var rootOrder = [ 'version', 'selectors', 'element_notes', 'selection_notes' ];

    var element_selectors = {};

    tt.core = $.extend(tt.core || {}, {
        version: '0.1.0-pa',

        root: null,
        
        // internals
        ID_PREFIX: 'ttid',

        Selection: function(element, range) {
            $.extend(this, {
                element: element,
                range: range
            });
        },    
        
        pendingNotes: {},

        getElementById: function(element_id) {
            return $('.' + this.ID_PREFIX + '-' + element_id); 
        },
        getElementId: function(element) {
            return element.data(this.ID_PREFIX);
        },
        getUniqueId: function(n) {
            return Array.apply(null, Array(n)).map(function() {
                return (Math.random() * 16 | 0).toString(16);
            }).join('');
        },
       
        // public
        addNote: function(note) {
            if(note instanceof this.Note)
                return note.save();
            
            return null;
        },
        getNote: function(element, note_id) {
            var element_notes = this.getNotes(element);

            if($.type(element_notes[note_id]) === 'object')
                return element_notes[note_id];

            return null;
        },
        getNotes: function(element) {
            var unique_id = this.getElementId(element);
            
            if($.type(this.pendingNotes[unique_id]) === 'object')
                return this.pendingNotes[unique_id];
            
            return {}; 
        },
        clear: function() {
            this.pendingNotes = {};    
        },
        init: function(options) {
            var hash_decoded,
                elements = [];
           
            options = $.extend({
                hash: window.location.hash.slice(1) 
            }, options);

            this.root = options.root;
           
            try {
                if(options.hash !== '') {
                    hash_decoded = rayson.b64.decode(options.hash, Base64.decode);
                    
                    hash_decoded = rayson.unserialize(hash_decoded, {
                        // version of encoded data
                        version: str,
                        // encoded selectors
                        selectors: [ raw ],
                        // encoded notes
                        element_notes: [ this.ElementNote.template ],
                        selection_notes: [ this.SelectionNote.template ]
                    }, {
                        root: rootOrder,
                        element_notes: this.ElementNote.templateOrder,
                        selection_notes: this.SelectionNote.templateOrder
                    });

                    function getSignificantNum(version) {
                        return version.substr(0, version.indexOf('.'));
                    }

                    if(getSignificantNum(hash_decoded.version) !== getSignificantNum(tt.core.version)) {
                        throw new Error('jNottery: Data was encoded with ' 
                            + hash_decoded.version + ' version of the library which is not compatible with current ' 
                            + tt.core.version);
                    }
                    
                    $.each(hash_decoded.selectors, function(i, selector) {
                        elements.push($.xJQ(selector, {
                            root: tt.core.root
                        }));
                    });
                    
                    $.each(hash_decoded.element_notes, function(i, note) {
                        var note_obj = new tt.core.ElementNote(
                            elements[note.selector],
                            note.content,
                            note.params
                        );
                        note_obj.save();

                        options.onElementNote && options.onElementNote(note_obj);
                    });
                    
                    $.each(hash_decoded.selection_notes, function(i, note) {
                        var range = tt.range.unserialize(elements[note.selector], {
                            start: note.selection[0],
                            end: note.selection[1]
                        });
                        
                        var note_obj = new tt.core.SelectionNote(
                            elements[note.selector],
                            range,
                            note.content,
                            note.params
                        );
                        tt.range.apply(range, note_obj.save());

                        options.onSelectionNote && options.onSelectionNote(note_obj);
                    });
                }
            } catch(err) {
                this.clear();
                options.onError && options.onError(err);
                return;
            }

            options.onReady && options.onReady();
        },
        merge: function() {
            var selectors = [],
                current_selector,
                element_notes = [],
                selection_notes = [],
                element_ref,
                class_blacklist = [];
            
            if(!$.isEmptyObject(this.pendingNotes)) {
                $.each(this.pendingNotes, function(element_id, notes) {
                    // calculate selector only once
                    if(!element_selectors[element_id]) {
                        element_ref = tt.core.getElementById(element_id);
                       
                        class_blacklist = [];
                        $.each($(element_ref).attr('class').trim().split(/\s+/), function(index, clas) {
                            // ignore internal binding classes
                            if(clas.substr(0, tt.core.ID_PREFIX.length) === tt.core.ID_PREFIX) {
                                class_blacklist.push(clas);        
                            }
                        });

                        element_selectors[element_id] = element_ref.xJQ({
                            classBlacklist: class_blacklist,
                            root: tt.core.root
                        });
                    }

                    current_selector = selectors.push(element_selectors[element_id]) - 1;
                    
                    $.each(notes, function(note_id, note) {
                        if(note instanceof tt.core.ElementNote)
                            element_notes.push($.extend({}, note.values(), { selector: current_selector })); 
                        else if(note instanceof tt.core.SelectionNote)
                            selection_notes.push($.extend({}, note.values(), { selector: current_selector }));
                    });
                });
                
                return rayson.b64.encode(rayson.serialize({
                    version: tt.core.version,
                    selectors: selectors,
                    element_notes: element_notes,
                    selection_notes: selection_notes
                }, $.extend({
                        version: str,
                        selectors: raw
                    }, 
                    this.valuesTypes(this.ElementNote),
                    this.valuesTypes(this.SelectionNote)
                ), {
                    root: rootOrder,
                    element_notes: this.ElementNote.templateOrder,
                    selection_notes: this.SelectionNote.templateOrder

                }), Base64.encode);
            }

            return '';
        },
        updateHash: function() {
            var hash = this.merge();
            ($.type(hash) === 'string') && (window.location.hash = hash);
        }
    });

})(window.tt, window.jQuery, window.rayson, window.rangy);;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) { 

    var TT_TOOLTIP_WIDTH = 280,
        TT_TOOLTIP_HEIGHT = 180,
        TT_ARROW_SIZE = 20,
        TT_ARROW_MARGIN = 30,
        $tooltip;

    // default parameters passed to tooltip's view
    var view_defaults = {
        title: 'Add note',
        btn: {
            close: '&#10006;',
            disabled: 'Add note first!',
            facebook: {
                label: 'Share on facebook'
            },
            twitter: {
                label: 'Share on twitter'
            },
            link: {
                label: 'Get direct link to your notes'    
            },
            save: {
                label: 'Save notes in browser'
            },
            submit: {
                label: 'Add'
            },
            edit: {
                label: 'Edit'
            },
            del: {
                label: 'Delete'
            }
        },
        txt: {
            placeholder: 'Type your note here...',
            attr: '',
            content: ''
        }
    };

    var events = {
        click: {
            'btn.facebook': '.tt-facebook.tt-active',
            'btn.twitter': '.tt-twitter.tt-active',
            'btn.link': '.tt-link.tt-active',
            'btn.save': '.tt-save.tt-active',
            'btn.submit': '.tt-add',
            'btn.edit': '.tt-edit',
            'btn.close': '.tt-close',
            'btn.delete': '.tt-del'
        }    
    };

    var events_propagate = {
        'btn.close.click': 'close',
        'btn.submit.click': 'submit',
        'btn.delete.click': 'delete'
    };

    var edit = false,
        opened = false;

    var defaults = {
        // show tooltip on the right or top
        // left/top/right/bottom/auto
        position: 'auto',

        // position (floating) of arrow pointing on current element
        // plus/minus/center/5px
        arrow: 'center',

        // position (floating) of main tooltip window
        // plus/minus/center/5px
        align: 'center',
        
        // ractangular container which limits size and position of tooltip
        // none/$element/'5px 10 5px 100px'
        container: 'none',

        fitToViewport: true,

        // dimensions of tooltip's window
        width: TT_TOOLTIP_WIDTH,
        height: TT_TOOLTIP_HEIGHT,
        
        // initial content of textarea
        content: '',

        title: false,
        
        edit: false,

        // callbacks
        init: false
    };

    var fading_change = 8,
        fading_speed = 200;

    function find(class_suffix) {
        return $tooltip.find('.tt-' + class_suffix);
    }

    function fadeIn($element) {
        $element
            .css('width', '-=' + fading_change)
            .css('height', '-=' + fading_change)
            .css('top', '+=' + (fading_change/2))
            .css('left', '+=' + (fading_change/2))
            .css('display', 'block')
        .stop()
        .animate({
            width: '+=' + fading_change,
            height: '+=' + fading_change,
            top: '-=' + (fading_change/2),
            left: '-=' + (fading_change/2),
            opacity: 1.0
        }, fading_speed);
    }

    function fadeOut($element) {
        $element.stop().animate({
            width: '-=' + fading_change,
            height: '-=' + fading_change,
            top: '+=' + (fading_change/2),
            left: '+=' + (fading_change/2),
            opacity: 0.0
        }, fading_speed, function() {
            $(this).css('display', 'none');    
        });        
    }

    function attachEvents($tooltip, params) {
        $.each(events_propagate, function(src, dest) {
            $tooltip.on(src + '.tt', function() {
                $(this).trigger(dest + '.tt', [ params ]);
            });
        });

        $.each(events, function(type, names) {
            $.each(names, function(name, elem_id) {
                (function(name, type) {
                    $tooltip.on(type, elem_id, function() {
                        $tooltip.trigger(name + '.' + type + '.tt', [ params ]);    
                    });
                })(name, type); 
            });    
        });

        $tooltip.on('btn.close.click.tt', tt.tooltip.close);
    }

    function outerBoundary(collection) {
        var result = {};

        collection.each(function() {
            var width = $(this).outerWidth(),
                height = $(this).outerHeight(),
                offset = $(this).offset();

            if(typeof result.left === 'undefined' || offset.left < result.left)
                result.left = offset.left;

            if(typeof result.top === 'undefined' || offset.top < result.top)
                result.top = offset.top;

            if(typeof result.right === 'undefined' || (offset.left + width) > result.right)
                result.right = offset.left + width;

            if(typeof result.bottom === 'undefined' || (offset.top + height) > result.bottom)
                result.bottom = offset.top + height;
        });

        result.width = result.right - result.left;
        result.height = result.bottom - result.top;
        return result;
    }

    function windowBoundary() {
        var result = {
            width: $(window).width(),
            height: $(window).height(),
            top: $(window).scrollTop(),
            left: $(window).scrollLeft(),
        };
        
        result.bottom = result.top + result.height;
        result.right = result.left + result.width;
        return result;
    }

    function containerBoundary($container, target) {
        var cont_offset = $container.offset(),
            result = {
                width: $container.outerWidth(),
                height: $container.outerHeight(),
                top: cont_offset.top,
                left: cont_offset.left
            };
        
        result.bottom = result.top + result.height,
        result.right = result.left + result.width;

        if(result.right < target.left)
            result.tooltip_pos = 'left';
        else if(result.left > (target.left + target.width))
            result.tooltip_pos = 'right';
        else if(result.bottom < (target.top + (target.height / 2)))
            result.tooltip_pos = 'top';
        else
            result.tooltip_pos = 'bottom';

        return result;
    }

    function calcPosition(tooltip, target, win) {
            // position where minimum of tooltip is out of the screen
        var min_cutting,
            // min space where tooltip is fully visible
            min_extra_space;
        
        $.each({
            top: (target.top - win.top) - tooltip.height,
            left: (target.left - win.left) - tooltip.width,
            bottom: (win.bottom - (target.top + target.height)) - tooltip.height,
            right: (win.right - (target.left + target.width)) - tooltip.width
        }, function(pos, space) {
            if(typeof min_cutting === 'undefined' || space > min_cutting.space)
                min_cutting = { name: pos, space: space };
                
            if((space - TT_ARROW_SIZE) > 0
                && (typeof min_extra_space === 'undefined' || space < min_extra_space.space))
                min_extra_space = { name: pos, space: space }; 
        });
    
        if(typeof min_extra_space !== 'undefined')
            min_cutting = min_extra_space;

        return min_cutting.name;
    }

    function arrowOffset(tooltip_pos, arrow_pos, target, win, fit_viewport) {
        var arrow_offset = { top: target.top, left: target.left };
    
        if(tooltip_pos === 'top' || tooltip_pos === 'bottom') {
            if(tooltip_pos === 'bottom')
                arrow_offset.top += target.height;
                    
            switch(arrow_pos) {
                case 'plus': {
                    if(fit_viewport)
                        arrow_offset.left += Math.min(target.width, win.right - target.left - TT_ARROW_MARGIN);
                    else
                        arrow_offset.left += target.width;
                    break;
                }
                case 'minus': {
                    if(fit_viewport)
                        arrow_offset.left += Math.max(0, win.left - target.left + TT_ARROW_MARGIN); 
                    break;
                }
                case 'center': {
                    arrow_offset.left += Math.floor(target.width / 2);
                    
                    if(fit_viewport) {
                        arrow_offset.left = Math.max(
                                Math.min(arrow_offset.left, win.right - TT_ARROW_MARGIN), 
                                win.left + TT_ARROW_MARGIN
                        );
                    }
                    break;
                }
                default: {
                    arrow_offset.left += Math.max(parseInt(arrow_pos), 0);
                }
            }
        } else {
            if(tooltip_pos === 'right') 
                arrow_offset.left += target.width;

            switch(arrow_pos) {
                case 'plus': {
                    if(fit_viewport)
                        arrow_offset.top += Math.min(target.height, win.bottom - target.top - TT_ARROW_MARGIN);
                    else
                        arrow_offset.top += target.height;
                    break;
                }
                case 'minus': {
                    if(fit_viewport)
                        arrow_offset.top += Math.max(0, win.top - target.top + TT_ARROW_MARGIN); 
                    break;
                }
                case 'center': {
                    arrow_offset.top += Math.floor(target.height / 2);
                    
                    if(fit_viewport) {
                        arrow_offset.top = Math.max(
                                Math.min(arrow_offset.top, win.bottom - TT_ARROW_MARGIN), 
                                win.top + TT_ARROW_MARGIN
                        );
                    }
                    break;
                }
                default: {
                    arrow_offset.top += Math.max(parseInt(arrow_pos), 0);
                }
            }
        }
        return arrow_offset;
    }

    function arrowToContainer(arrow_offset, tooltip_pos, container) {

        switch(tooltip_pos) {
            case 'right': {
                arrow_offset.left = container.left;        
                break;
            }
            case 'left': {
                arrow_offset.left = container.right;            
                break;
            }
            case 'top': {
                arrow_offset.top = container.bottom;        
                break;
            }
            case 'bottom': {
                arrow_offset.top = container.top;
                break;
            }
        }

        if(tooltip_pos === 'right' || tooltip_pos === 'left') {
            arrow_offset.top = Math.max(
                Math.min(arrow_offset.top, container.bottom - TT_ARROW_MARGIN), 
                container.top + TT_ARROW_MARGIN
            );
        } else {
            arrow_offset.left = Math.max(
                Math.min(arrow_offset.left, container.right - TT_ARROW_MARGIN), 
                container.left + TT_ARROW_MARGIN
            );
        }
    }

    function calcTooltip(tooltip_align, arrow_offset, tooltip_pos, tooltip, win, container, fit_viewport) {
        var tooltip_offset = { top: arrow_offset.top, left: arrow_offset.left },
            arrow_adjust = {};
        
        if(tooltip_pos === 'top' || tooltip_pos === 'bottom') {
            if(tooltip_pos === 'top')
                tooltip_offset.top -= tooltip.height + TT_ARROW_SIZE;
            else
                tooltip_offset.top += TT_ARROW_SIZE;

            switch(tooltip_align) {
                case 'plus': {
                    if(fit_viewport)
                        tooltip_offset.left = Math.min(tooltip_offset.left, win.right - tooltip.width);
                    break;
                }
                case 'minus': {
                    tooltip_offset.left -= tooltip.width;
                    if(fit_viewport)
                        tooltip_offset.left = Math.max(tooltip_offset.left, win.left); 
                    break;
                }
                case 'center': {
                    tooltip_offset.left -= Math.floor(tooltip.width / 2);
                    
                    if(fit_viewport) {
                        tooltip_offset.left = Math.max(
                                Math.min(tooltip_offset.left, win.right - tooltip.width), 
                                win.left
                        );
                    }
                    break;
                }
                default: {
                    tooltip_offset.left -= Math.max(parseInt(tooltip_align), 0);
                }
            }

            if(container) {
                tooltip_offset.left = Math.max(
                        Math.min(tooltip_offset.left, container.right - tooltip.width), 
                        container.left
                );                        
            }
            
            var arrow_inner_left = arrow_offset.left - tooltip_offset.left,
                left_margin = TT_ARROW_MARGIN - arrow_inner_left,
                right_margin = arrow_inner_left - (tooltip.width - TT_ARROW_MARGIN);

            if(left_margin > 0) {
                tooltip_offset.left -= left_margin;
                arrow_inner_left = TT_ARROW_MARGIN;
            } else if(right_margin > 0) {
                tooltip_offset.left += right_margin;
                arrow_inner_left = tooltip.width - TT_ARROW_MARGIN;
            }
            
            arrow_adjust = { left: arrow_inner_left, top: '' };
            
        } else {
            if(tooltip_pos === 'left') 
                tooltip_offset.left -= tooltip.width + TT_ARROW_SIZE;
            else
                tooltip_offset.left += TT_ARROW_SIZE;
            
            switch(tooltip_align) {
                case 'plus': {
                    if(fit_viewport)
                        tooltip_offset.top = Math.min(tooltip_offset.top, win.bottom - tooltip.height);
                    break;
                }
                case 'minus': {
                    tooltip_offset.top -= tooltip.height;
                    if(fit_viewport)
                        tooltip_offset.top = Math.max(tooltip_offset.top, win.top); 
                    break;
                }
                case 'center': {
                    tooltip_offset.top -= Math.floor(tooltip.height / 2);
                    
                    if(fit_viewport) {
                        tooltip_offset.top = Math.max(
                                Math.min(tooltip_offset.top, win.bottom - tooltip.height), 
                                win.top
                        );
                    }
                    break;
                }
                default: {
                    tooltip_offset.top -= Math.max(parseInt(tooltip_align), 0);
                }
            }

            if(container) {
                tooltip_offset.top = Math.max(
                        Math.min(tooltip_offset.top, container.bottom - tooltip.height), 
                        container.top
                );                        
            }

            var arrow_inner_top = arrow_offset.top - tooltip_offset.top,
                top_margin = TT_ARROW_MARGIN - arrow_inner_top,
                bottom_margin = arrow_inner_top - (tooltip.height - TT_ARROW_MARGIN);

            if(top_margin > 0) {
                tooltip_offset.top -= top_margin;
                arrow_inner_top = TT_ARROW_MARGIN;
            } else if(bottom_margin > 0) {
                tooltip_offset.top += bottom_margin;
                arrow_inner_top = tooltip.height - TT_ARROW_MARGIN;
            }
            
            arrow_adjust = { top: arrow_inner_top, left: '' };
        }

        return {
            offset: tooltip_offset,
            arrow_adjust: arrow_adjust
        };
    }

    function processOptions(options) {
        var result = {
            target: outerBoundary(options.root),
            win: windowBoundary(),
            tooltip: {
                width: Math.max(options.width, TT_TOOLTIP_WIDTH),
                height: Math.max(options.height, TT_TOOLTIP_HEIGHT)
            },
            tooltip_pos: options.position,
            arrow_offset: null,
            container: null
        };

        if(document.doctype === null || screen.height < parseInt(result.win.height)) {
            // @todo checking doctype in chrome
            //throw new Error('jNottery: Please specify doctype for your document, it\'s required for height calculation');
        } 

        if(options.container instanceof $) {
            result.container = containerBoundary(options.container, result.target);
            result.tooltip_pos = result.container.tooltip_pos;
        }
        
        if(result.tooltip_pos === 'auto' && !result.container)
            result.tooltip_pos = calcPosition(result.tooltip, result.target, result.win);
        
        result.arrow_offset = arrowOffset(result.tooltip_pos, options.arrow, result.target, result.win, options.fitToViewport);
        
        if(result.container)
            arrowToContainer(result.arrow_offset, result.tooltip_pos, result.container);

        return result;
    }
    
    function isActive() {
        return typeof $tooltip !== 'undefined';
    }

    tt.tooltip = $.extend(tt.tooltip || {}, {
        close: function() {
            if(isActive() && opened) {
                opened = false;
                fadeOut($tooltip);
                $tooltip.trigger('close.tt', [ tt.tooltip ]); 
            }
        },
        open: function(options) {
            this.close();

            if(typeof main_view !== 'undefined') {
                options = $.extend({}, defaults, options);

                var $arrow,
                    params = processOptions(options),
                    view_options = $.extend({}, view_defaults, options.view);
               
                if(typeof $tooltip === 'undefined') {
                    $tooltip = $(nano(main_view, view_options));
                    $(document.body).append($tooltip);   
                    
                    // event handlers for tooltip's components
                    attachEvents($tooltip, this);

                    if($.type(options.init) === 'function') 
                        options.init($tooltip);

                // only title is reupdated!
                } else if(view_options.title) {
                    this.title(view_options.title);
                }
               
                find('input').val(options.content);
                this.switchEditMode(this.edit(options.edit ? options.edit : false));
                 
                $arrow = find('arrow');

                var tooltip_calculations = calcTooltip(
                        options.align, 
                        params.arrow_offset, 
                        params.tooltip_pos, 
                        params.tooltip, 
                        params.win, 
                        params.container,
                        options.fitToViewport
                );
                
                // adjust arrow position inside tooltip's window 
                $arrow.css(tooltip_calculations.arrow_adjust);
                
                // set arrow direction
                $arrow.removeClass().addClass('tt-arrow').addClass('tt-arrow-' + params.tooltip_pos);
                
                // set tooltip position 
                $tooltip.css(tooltip_calculations.offset);

                // set tootip size
                $tooltip.outerWidth(params.tooltip.width).outerHeight(params.tooltip.height);

                // show tooltip
                fadeIn($tooltip);

                opened = true;

                return $tooltip;
            }
        },
        // when invoked without params, simply returns currently edited note
        edit: function(id) {
            if(id === false) {
                edit = false;
            } else if(typeof id !== 'undefined') {
                edit = id;
            }

            return edit;
        },
        switchEditMode: function(on) {
            var btn_modifier;

            if(!on) {
                find('input').removeProp('readonly');
                
                btn_modifier = function(key, val) {
                    find(val).removeClass('tt-active');    
                };

                find('add').show();
                find('edit').add(find('del')).hide();
            } else {
                find('input').prop('readonly', true); 
                
                btn_modifier = function(key, val) {
                    find(val).addClass('tt-active');    
                };
                
                find('add').hide();
                find('edit').add(find('del')).show();
            }

            if($.type(btn_modifier) === 'function')
                $.each(['facebook', 'twitter', 'link', 'save'], btn_modifier);
        },
        content: function(val) {
            var $input;

            if(isActive()) {
                $input = find('input');
                if(typeof val === 'undefined')
                    return $input.val();

                $input.val(val);
            }
            return val;
        },
        arrowPosition: function(options) {
            return processOptions($.extend({}, defaults, options)).arrow_offset;
        },
        title: function(txt) {
            find('title').text(txt);    
        }
    });
})(window.tt, window.jQuery);;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) { 
    var TT_APPLIER_CLASS = 'tt-selection',
        TT_DEFAULT_ID = 'default',
        TT_NODE_TEXT = 3;
   
    var appliers = {};

    function getApplierClass(id) {
        return TT_APPLIER_CLASS + '-' + (id ? id : TT_DEFAULT_ID);
    }

    function getApplier(id) {
        !id && (id = TT_DEFAULT_ID);

        !appliers[id] && (appliers[id] = rangy.createCssClassApplier(
            getApplierClass(id) + ' tt-selection', 
            { normalize: true }
        ));
        return appliers[id];      
    }

    tt.range = $.extend(tt.range || {}, {
        serialize: function(element, range) {
            (element instanceof $) && (element = element[0]);

            var params = { idx: 0, start: null };

            if(!element.nodeType || !range)
                return { start: 0, end: 0 };

            return (function traverse(element, range, params) {
                var result = false,
                    started = false;

                if (element.nodeType === TT_NODE_TEXT) {
                    started = $.type(params.start) !== 'null';
                    
                    if(!started && element === range.startContainer) { 
                        params.start = params.idx + range.startOffset;
                        started = true;
                    }
                    
                    if(started && element === range.endContainer) {
                        return {
                            start: params.start,
                            end: params.idx + range.endOffset
                        };
                    }

                    params.idx += element.length;
                } else {
                    $(element).contents().each(function(i, child) {
                        return !(result = traverse(child, range, params));
                    });
                }
                
                return result;
            })(element, range, params);
        },
        unserialize: function(element, serial) {
            (element instanceof $) && (element = element[0]);

            var params = { idx: 0, range: null };

            return (function traverse(element, serial, params) {
                var result = false,
                    started = false,
                    next_idx = 0;

                if (element.nodeType === TT_NODE_TEXT) {
                    started = $.type(params.range) !== 'null';
                    next_idx = params.idx + element.length;
                    
                    if(!started && params.idx <= serial.start && serial.start <= next_idx) {
                        params.range = rangy.createRange();
                        params.range.setStart(element, serial.start - params.idx);
                        started = true;
                    }            
            
                    if(started && params.idx <= serial.end && serial.end <= next_idx) {
                        params.range.setEnd(element, serial.end - params.idx);
                        return params.range;
                    }

                    params.idx = next_idx;
                } else {
                    $(element).contents().each(function(i, child) {
                        return !(result = traverse(child, serial, params));
                    });
                }
                
                return result;
            })(element, serial, params);
        },
        getFrom: function(element) {
            (element instanceof $) && (element = element[0]);
            
            var result = null,
                selection = rangy.getSelection(),
                element_range = rangy.createRange();
            
            element_range.selectNodeContents(element);
            
            if (selection.rangeCount)
                result = selection.getRangeAt(0).intersection(element_range);
            
            element_range.detach();

            return result;    
        },
        getElements: function(range, id) {
            var result = $(),
                nodes = range.getNodes(false, function (element) {
                    return $(element.parentNode).hasClass(getApplierClass(id));
                });
            
            for(var i = 0; i < nodes.length; i++) 
                result = result.add(nodes[i].parentNode);
            
            return result;
        },
        apply: function(range, id) {
            getApplier(id).applyToRange(range);
        },
        clear: function(range, id) {
            getApplier(id).undoToRange(range); 
        },
        equals: function(r1, r2) {
            return (
                r1.startContainer === r2.startContainer
             && r1.endContainer === r2.endContainer
             && r1.startOffset === r2.startOffset
             && r1.endOffset === r2.endOffset
            ); 
        }
    });
    
})(window.tt, window.jQuery);

;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) {

    tt.vendor = $.extend(tt.vendor || {}, {
        config: undefined,
        init: function(options) {
            this.config = $.extend({
                bitly: {
                    access_token: false    
                },
                twitter: {
                    text: 'Check my notes on ' + document.title 
                }
            }, options);
        }
    });
    
})(window.tt, window.jQuery);;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) {
    var str = rayson.type.str,
        int8 = rayson.type.int8,
        int32 = rayson.type.int32;

    function extend(parent, child) {
        var pty = function() {};
        pty.prototype = parent.prototype;
        child.prototype = new pty();
        child.prototype.constructor = child;
        return child;
    }

    function Note(element, content, params) {
        $.extend(this, {
            element: element,
            content: content,
            params: (typeof params === 'undefined' ? [] : params),
            id: null
        });
    }

    Note.prototype = {
        save: function() {
            if(this.id === null) {
                var unique_id = tt.core.getElementId(this.element),
                    note_id = tt.core.getUniqueId(8);
                
                if(typeof unique_id === 'undefined') {
                    unique_id = tt.core.getUniqueId(8);
                    this.element.data(tt.core.ID_PREFIX, unique_id);
                    this.element.addClass(tt.core.ID_PREFIX + '-' + unique_id);
                }

                if($.type(tt.core.pendingNotes[unique_id]) !== 'object')
                    tt.core.pendingNotes[unique_id] = {};
              
                this.id = note_id;
                tt.core.pendingNotes[unique_id][note_id] = this;
            }

            return this.id;
        },
        remove: function() {
            var element_id = tt.core.getElementId(this.element);
            
            if(this.id !== null && typeof element_id !== 'undefined') {
                delete tt.core.pendingNotes[element_id][this.id];

                if($.isEmptyObject(tt.core.pendingNotes[element_id]))
                    delete tt.core.pendingNotes[element_id];
            }
        },
        values: function() {
            return {
                content: this.content,
                params: this.params
            };    
        },
        setContent: function(txt) {
            this.content = txt;
        },
        getContent: function() {
            return this.content;
        }
    };
       
    Note.template = {
        selector: int8,
        content: str,
        params: [ str ]
    };

    Note.templateOrder = [ 'selector', 'content', 'params' ];

    var ElementNote = extend(Note, function(element, content, params) {
        Note.call(this, element, content, params);        
    });

    ElementNote.template = Note.template;
    ElementNote.templateOrder = Note.templateOrder;

    var SelectionNote = extend(Note, function(element, range, content, params) {
        Note.call(this, element, content, params); 
        this.range = range;
    });

    SelectionNote.prototype.values = function() {
        var selection = tt.range.serialize(this.element, this.range);
        return {
            selection: (selection ? [ selection.start, selection.end ] : []),
            content: this.content,
            params: this.params
        };    
    };
    
    SelectionNote.template = $.extend(Note.template, {
        selection: [ int32 ]        
    });            
    
    SelectionNote.templateOrder = Note.templateOrder.concat([ 'selection' ]);
    
    tt.core = $.extend(tt.core || {}, {
        Note: Note,
        ElementNote: ElementNote,
        SelectionNote: SelectionNote,

        valuesTypes: function(note_class) {
            var result = {};
            
            note_class.template && $.each(note_class.template, function(n, val) {
                result[n] = val;

                if($.isArray(result[n])) 
                    result[n] = result[n][0];
            });
            
            return result;
        }
    });
    
})(window.tt, window.jQuery);;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) {

    tt.vendor = $.extend(tt.vendor || {}, {
        bitly: function(long_url, callback) {
            if(this.bitlyReady()) {
                $.getJSON(
                    'https://api-ssl.bitly.com/v3/shorten',
                    {
                        format: 'json',
                        access_token: this.config.bitly.access_token,
                        longUrl: long_url 
                    },
                    function(response) {
                        if(response.status_code === 200)
                            callback(decodeURIComponent(response.data.url));
                    }
                );
            }    
        },
        bitlyReady: function() {
            return (typeof this.config !== 'undefined') && !!this.config.bitly.access_token;
        }
    });
    
})(window.tt, window.jQuery);;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) {

    tt.vendor = $.extend(tt.vendor || {}, {
        facebook: function(url) {
            window.open('https://www.facebook.com/sharer.php'
                + '?u=' + encodeURIComponent(url));
        }
    });
    
})(window.tt, window.jQuery);
;// jNottery (c) 2014, Tomasz Zduńczyk <tomasz@zdunczyk.org>
// Released under the MIT license.

(function(tt, $) {

    tt.vendor = $.extend(tt.vendor || {}, {
        twitter: function(url) {
            var text = (typeof this.config !== 'undefined') ? this.config.twitter.text : '';

            window.open('https://twitter.com/share'
                + '?url=' + encodeURIComponent(url)
                + '&text=' + encodeURIComponent(text));      
        }
    });
    
})(window.tt, window.jQuery);
 })();